export interface Creator {
  id: number;
  userId: number;
  displayName: string;
  bio?: string;
  profileImage?: string;
  coverImage?: string;
  tokenSymbol: string;
  tokenSupply: string;
  currentPrice: string;
  totalVolume: string;
  holderCount: number;
  chatMemberCount: number;
  isOnline: boolean;
  socialLinks?: any;
  ranking: number;
  createdAt: string;
}

export interface User {
  id: number;
  username: string;
  email: string;
  avatar?: string;
  isCreator: boolean;
  socialId?: string;
  provider?: string;
  createdAt: string;
}

export interface Token {
  id: number;
  creatorId: number;
  holderId: number;
  amount: string;
  purchasePrice: string;
  createdAt: string;
}

export interface Trade {
  id: number;
  creatorId: number;
  traderId: number;
  type: 'buy' | 'sell';
  amount: string;
  price: string;
  totalValue: string;
  createdAt: string;
}

export interface ChatMessage {
  id: number;
  roomId: number;
  senderId: number;
  content: string;
  createdAt: string;
  sender?: User;
}

export interface ChatRoom {
  id: number;
  creatorId: number;
  name: string;
  description?: string;
  minTokens: string;
  memberCount: number;
  createdAt: string;
  creator?: Creator;
}

export interface Wallet {
  id: number;
  userId: number;
  ethBalance: string;
  usdBalance: string;
  createdAt: string;
}

export interface Portfolio {
  totalValue: string;
  dayChange: string;
  keysOwned: number;
  holdings: {
    creator: Creator;
    tokens: string;
    value: string;
    change: string;
  }[];
}
