import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { 
  DollarSign, 
  TrendingUp, 
  Shield, 
  Zap, 
  Clock, 
  Users, 
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Wallet,
  PieChart,
  BarChart3,
  Target,
  Smartphone,
  Globe,
  Lock,
  X,
  ChevronDown,
  Search
} from "lucide-react";
import { FansIcon, EthereumIcon, BitcoinIcon, UsdcIcon } from "@/components/ui/crypto-icons";

// Teller Widget Component
function TellerWidget() {
  const [activeTab, setActiveTab] = useState("borrow");
  const [selectedCollateral, setSelectedCollateral] = useState("1INCH");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedNetwork, setSelectedNetwork] = useState("ethereum");
  const [showNetworkDropdown, setShowNetworkDropdown] = useState(false);
  
  const networks = [
    { id: "ethereum", name: "Ethereum", color: "bg-blue-600" },
    { id: "base", name: "Base", color: "bg-blue-500" },
    { id: "polygon", name: "Polygon", color: "bg-purple-600" },
    { id: "arbitrum", name: "Arbitrum", color: "bg-blue-700" },
    { id: "optimism", name: "Optimism", color: "bg-red-500" },
    { id: "avalanche", name: "Avalanche", color: "bg-red-600" }
  ];
  
  const allCollateralOptions = [
    // Ethereum tokens
    { 
      symbol: "1INCH", 
      name: "1INCH", 
      balance: "0.000 1INCH",
      network: "ethereum",
      bgColor: "bg-purple-600",
      textColor: "text-white"
    },
    { 
      symbol: "AAVE", 
      name: "AAVE", 
      balance: "0.000 AAVE",
      network: "ethereum",
      bgColor: "bg-purple-500",
      textColor: "text-white"
    },
    { 
      symbol: "APE", 
      name: "APE", 
      balance: "0.000 APE",
      network: "ethereum",
      bgColor: "bg-blue-600",
      textColor: "text-white"
    },
    { 
      symbol: "APU", 
      name: "APU", 
      balance: "0.000 APU",
      network: "ethereum",
      bgColor: "bg-green-600",
      textColor: "text-white"
    },
    { 
      symbol: "ARKM", 
      name: "ARKM", 
      balance: "0.000 ARKM",
      network: "ethereum",
      bgColor: "bg-black",
      textColor: "text-white"
    },
    { 
      symbol: "ASF", 
      name: "ASF", 
      balance: "0.000 ASF",
      network: "ethereum",
      bgColor: "bg-cyan-500",
      textColor: "text-white"
    },
    // Base tokens
    { 
      symbol: "AERO", 
      name: "AERO", 
      balance: "0.000 AERO",
      network: "base",
      bgColor: "bg-blue-500",
      textColor: "text-white"
    },
    { 
      symbol: "CBETH", 
      name: "CBETH", 
      balance: "0.000 CBETH",
      network: "base",
      bgColor: "bg-blue-600",
      textColor: "text-white"
    },
    // Polygon tokens
    { 
      symbol: "MATIC", 
      name: "MATIC", 
      balance: "0.000 MATIC",
      network: "polygon",
      bgColor: "bg-purple-600",
      textColor: "text-white"
    },
    { 
      symbol: "WMATIC", 
      name: "WMATIC", 
      balance: "0.000 WMATIC",
      network: "polygon",
      bgColor: "bg-purple-500",
      textColor: "text-white"
    },
    // Arbitrum tokens
    { 
      symbol: "ARB", 
      name: "ARB", 
      balance: "0.000 ARB",
      network: "arbitrum",
      bgColor: "bg-blue-700",
      textColor: "text-white"
    }
  ];

  // Filter options by selected network and search term
  const collateralOptions = allCollateralOptions.filter(option => option.network === selectedNetwork);
  
  const filteredOptions = collateralOptions.filter(option =>
    option.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    option.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm mx-auto">
      {/* Widget Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">Borrow</h2>
        <div className="flex items-center gap-2">
          <div className="relative">
            <button 
              className="flex items-center gap-1 px-2 py-1 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
              onClick={() => setShowNetworkDropdown(!showNetworkDropdown)}
            >
              <div className={`w-4 h-4 rounded-sm ${networks.find(n => n.id === selectedNetwork)?.color || 'bg-blue-600'}`}></div>
              <ChevronDown className="w-4 h-4 text-gray-600" />
            </button>
            
            {showNetworkDropdown && (
              <div className="absolute top-full right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg z-10 min-w-32">
                {networks.map((network) => (
                  <button
                    key={network.id}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 first:rounded-t-md last:rounded-b-md"
                    onClick={() => {
                      setSelectedNetwork(network.id);
                      setShowNetworkDropdown(false);
                      // Reset selected collateral when changing networks
                      const networkTokens = allCollateralOptions.filter(option => option.network === network.id);
                      if (networkTokens.length > 0) {
                        setSelectedCollateral(networkTokens[0].symbol);
                      }
                    }}
                  >
                    <div className={`w-3 h-3 rounded-sm ${network.color}`}></div>
                    {network.name}
                  </button>
                ))}
              </div>
            )}
          </div>
          <button className="p-1 hover:bg-gray-100 rounded">
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 pt-4">
        <div className="flex bg-gray-100 rounded-lg p-1">
          <button 
            className={`flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors ${
              activeTab === "borrow" 
                ? 'bg-white text-gray-900 shadow-sm border-b-2 border-orange-400' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
            onClick={() => setActiveTab("borrow")}
          >
            Borrow
          </button>
          <button 
            className={`flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors ${
              activeTab === "my-loans" 
                ? 'bg-white text-gray-900 shadow-sm border-b-2 border-orange-400' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
            onClick={() => setActiveTab("my-loans")}
          >
            My Loans
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Collateral for loan"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Collateral Options */}
      <div className="px-4 pb-6">
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {filteredOptions.map((option, index) => (
            <div
              key={index}
              className={`p-3 rounded-lg border cursor-pointer transition-all ${
                selectedCollateral === option.symbol
                  ? 'border-orange-500 bg-orange-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => setSelectedCollateral(option.symbol)}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${option.bgColor}`}>
                  <span className={`font-bold text-xs ${option.textColor}`}>
                    {option.symbol.charAt(0)}
                  </span>
                </div>
                <div className="flex-1">
                  <div className="text-gray-900 font-medium">{option.symbol}</div>
                  <div className="text-gray-500 text-sm flex items-center gap-1">
                    {networks.find(n => n.id === option.network)?.name || option.network}
                    <span className="w-1 h-1 bg-gray-400 rounded-full"></span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Powered By */}
      <div className="px-4 pb-4 text-center border-t border-gray-100 pt-4">
        <div className="text-gray-500 text-xs">
          Powered by <span className="text-teal-600 font-medium">Fans.tech</span>
        </div>
      </div>
    </div>
  );
}

export default function Loans() {
  const [activeTab, setActiveTab] = useState("borrow");

  const loanFeatures = [
    {
      icon: Clock,
      title: "Instant loan terms",
      description: "Get approved within minutes and receive funds instantly to your $FANS wallet."
    },
    {
      icon: Shield,
      title: "No liquidity risk",
      description: "Secure loans backed by your creator token holdings with transparent terms."
    },
    {
      icon: Target,
      title: "Fixed APR protection",
      description: "Lock in competitive rates and protect yourself from market volatility."
    },
    {
      icon: Users,
      title: "Monthly interest payments",
      description: "Flexible payment schedules that work with your creator income streams."
    }
  ];

  const workflowSteps = [
    {
      step: 1,
      title: "Supply your assets",
      description: "Deposit $FANS tokens or creator keys as collateral"
    },
    {
      step: 2,
      title: "Setup APR",
      description: "Choose your preferred interest rate and loan terms"
    },
    {
      step: 3,
      title: "Crypto Lending",
      description: "Automated lending powered by smart contracts"
    },
    {
      step: 4,
      title: "Borrowers",
      description: "Connect with verified creators and influencers"
    }
  ];

  const benefits = [
    "Collateral backed loans for peace of mind",
    "Ultra competitive rates starting at 4.5% APR",
    "Option to hold collateral",
    "Flexible repayment schedules aligned with creator earnings",
    "No hidden fees or surprise charges",
    "Full DeFi transparency via blockchain verification",
    "Instant liquidity without selling your creator tokens"
  ];

  const supportedTokens = [
    { symbol: "FANS", name: "Fans Token", icon: FansIcon, apy: "8.5%" },
    { symbol: "ETH", name: "Ethereum", icon: EthereumIcon, apy: "5.2%" },
    { symbol: "BTC", name: "Bitcoin", icon: BitcoinIcon, apy: "4.8%" },
    { symbol: "USDC", name: "USD Coin", icon: UsdcIcon, apy: "12.3%" }
  ];

  return (
    <div className="min-h-screen glass p-6">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto mb-12">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">

              <h1 className="text-5xl font-bold text-white leading-tight">
                Borrow Crypto Instantly:
                <br />
                <span className="bg-gradient-to-r from-teal-400 to-purple-500 bg-clip-text text-transparent">
                  Fixed Rates, No Liquidation Risk
                </span>
              </h1>

            </div>

            <div className="space-y-6 mt-8">
              <p className="text-xl text-white/90 leading-relaxed">
                Need cash but don't want to sell your crypto? Our platform lets you borrow crypto by using your own tokens as collateral—keep your assets and access liquidity with zero risk of losing your crypto!
              </p>
              <p className="text-xl text-white/90 leading-relaxed">
                Fans Tech platform is built for crypto holders who want to borrow money without stress. Borrow what you need, keep your investments, and repay at your pace—all with clear terms and a fixed rate that will never change!
              </p>
              <p className="text-xl text-white/90 leading-relaxed font-semibold">
                Decentralized & Secure: Loans are trustless—your crypto never leaves your wallet!
              </p>
            </div>


          </div>

          {/* Teller Widget */}
          <div className="relative">
            <TellerWidget />
          </div>
        </div>
      </div>



      {/* Loan Features */}
      <div className="max-w-7xl mx-auto mb-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* DeFi cash advance */}
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-teal-400 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-6">
              <DollarSign className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">DeFi cash advance</h3>
            <p className="text-white/70 text-sm leading-relaxed">
              Access time-based loans for 1-30 days, with any token as collateral & no margin liquidations.
            </p>
          </div>

          {/* Time-based repayment */}
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-teal-400 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Clock className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Time-based repayment</h3>
            <p className="text-white/70 text-sm leading-relaxed">
              Our loans do not use a price oracle. Borrowers can only be liquidated if they don't repay their loan on time.
            </p>
          </div>

          {/* Safety from liquidation */}
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-teal-400 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-6">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Safety from liquidation</h3>
            <p className="text-white/70 text-sm leading-relaxed">
              Our loans help DeFi users pay down bad health ratios & save at-risk positions when the market is volatile.
            </p>
          </div>

          {/* Loan extensions */}
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-teal-400 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-6">
              <ArrowRight className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Loan extensions</h3>
            <p className="text-white/70 text-sm leading-relaxed">
              Existing loans can be extended indefinitely based on the best loan offer at time of repayment.
            </p>
          </div>

          {/* Audited & Insured */}
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-teal-400 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Audited & Insured</h3>
            <p className="text-white/70 text-sm leading-relaxed">
              Our protocol smart contracts are audited and insured for up to $2.2m by Sherlock.
            </p>
          </div>
        </div>
      </div>






    </div>
  );
}