import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  CreditCard, 
  CheckCircle, 
  Star, 
  Users, 
  TrendingUp, 
  Shield, 
  Zap,
  Instagram,
  Twitter,
  Youtube,
  Heart,
  Eye,
  MessageCircle,
  Share2,
  Crown,
  Target,
  Sparkles
} from "lucide-react";

export default function Brands() {
  const [selectedTier, setSelectedTier] = useState<string>("");
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedCreator, setSelectedCreator] = useState<any>(null);

  // Fee structure tiers
  const pricingTiers = [
    {
      name: "Starter Access",
      price: "0.05 ETH",
      usdPrice: "$125",
      features: [
        "Access to 5 creators per month",
        "Basic analytics dashboard",
        "Email support",
        "Standard partnership templates",
        "7-day response time"
      ],
      popular: false
    },
    {
      name: "Professional",
      price: "0.15 ETH",
      usdPrice: "$375",
      features: [
        "Access to 15 creators per month",
        "Advanced analytics & insights",
        "Priority support (24h response)",
        "Custom partnership agreements",
        "Campaign performance tracking",
        "Dedicated account manager"
      ],
      popular: true
    },
    {
      name: "Enterprise",
      price: "0.5 ETH",
      usdPrice: "$1,250",
      features: [
        "Unlimited creator access",
        "White-label solutions",
        "API access for integrations",
        "Real-time campaign analytics",
        "Multi-brand management",
        "Custom onboarding & training"
      ],
      popular: false
    }
  ];

  // Top creators data
  const topCreators = [
    {
      id: 1,
      name: "Bella Thorne",
      username: "@bellathorne",
      bio: "Actress & OnlyFans Pioneer",
      followers: "24.8M",
      engagement: "4.2%",
      avgViews: "2.1M",
      platforms: ["Instagram", "OnlyFans", "TikTok"],
      categories: ["Entertainment", "Fashion", "Lifestyle"],
      image: "https://images.unsplash.com/photo-1494790108755-2616b332446c?w=100&h=100&fit=crop",
      rating: 4.7,
      campaigns: 45,
      successRate: "94%"
    },
    {
      id: 2,
      name: "Charli D'Amelio",
      username: "@charlidamelio",
      bio: "TikTok Queen & Dancer",
      followers: "199M",
      engagement: "3.8%",
      avgViews: "12.4M",
      platforms: ["TikTok", "Instagram", "YouTube"],
      categories: ["Dance", "Gen Z", "Lifestyle"],
      image: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=100&h=100&fit=crop",
      rating: 4.9,
      campaigns: 73,
      successRate: "98%"
    },
    {
      id: 3,
      name: "Addison Rae",
      username: "@addisonraee",
      bio: "TikTok Star & Brand Ambassador",
      followers: "128M",
      engagement: "4.1%",
      avgViews: "8.7M",
      platforms: ["TikTok", "Instagram", "YouTube"],
      categories: ["Fashion", "Beauty", "Lifestyle"],
      image: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=100&h=100&fit=crop",
      rating: 4.6,
      campaigns: 62,
      successRate: "96%"
    },
    {
      id: 4,
      name: "Kylie Jenner",
      username: "@kyliejenner",
      bio: "Beauty Mogul & Influencer",
      followers: "398M",
      engagement: "2.9%",
      avgViews: "15.2M",
      platforms: ["Instagram", "TikTok", "Snapchat"],
      categories: ["Beauty", "Fashion", "Business"],
      image: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=100&h=100&fit=crop",
      rating: 4.8,
      campaigns: 89,
      successRate: "97%"
    }
  ];

  const handleSelectTier = (tier: string) => {
    setSelectedTier(tier);
    setShowPaymentModal(true);
  };

  const handleCreatorSelect = (creator: any) => {
    setSelectedCreator(creator);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-gray-900 to-teal-900/20 py-20">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <div className="inline-block w-1 h-16 bg-gradient-to-b from-purple-500 to-teal-500 rounded-full mb-8"></div>
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            Web3 Brand<br />Marketplace
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Revolutionize your Web3 user onboarding by partnering with top creators from OnlyFans, Instagram, and TikTok. 
            Transparent fees, quality partnerships, and rapid growth acceleration.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600 text-lg px-8 py-4"
              onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <CreditCard className="mr-2 h-5 w-5" />
              View Pricing
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-gray-600 text-gray-300 hover:bg-gray-700 text-lg px-8 py-4"
              onClick={() => document.getElementById('creators')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <Users className="mr-2 h-5 w-5" />
              Browse Creators
            </Button>
          </div>
        </div>
      </div>

      {/* Value Proposition */}
      <div className="py-20 bg-gray-900/50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Why Choose Our Creator Marketplace?</h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              The catalyst Web3 brands need to achieve rapid growth and sustained success through quality creator partnerships.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-gray-800/50 border-gray-700 p-8 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Accelerated Onboarding</h3>
              <p className="text-gray-400">
                Leverage creator influence to rapidly onboard your initial users and build engaged communities.
              </p>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 p-8 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Transparent Marketplace</h3>
              <p className="text-gray-400">
                Clear fee structure and performance metrics ensure fair compensation and quality partnerships.
              </p>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 p-8 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Proven Results</h3>
              <p className="text-gray-400">
                Access creators with 1.2B+ combined followers and 96% average campaign success rate.
              </p>
            </Card>
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div id="pricing" className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Transparent Fee Structure</h2>
            <p className="text-gray-400 text-lg">
              Choose the perfect tier for your brand's creator partnership needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pricingTiers.map((tier, index) => (
              <Card key={index} className={`bg-gray-800/50 border-gray-700 p-8 relative ${tier.popular ? 'border-purple-500 border-2' : ''}`}>
                {tier.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-purple-500 to-teal-500 text-white px-4 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <h3 className="text-xl font-semibold mb-4">{tier.name}</h3>
                  <div className="mb-2">
                    <span className="text-3xl font-bold">{tier.price}</span>
                    <span className="text-gray-400 ml-2">({tier.usdPrice})</span>
                  </div>
                  <p className="text-gray-400 text-sm">per month</p>
                </div>

                <ul className="space-y-4 mb-8">
                  {tier.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button 
                  className={`w-full ${tier.popular 
                    ? 'bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600' 
                    : 'bg-gray-700 hover:bg-gray-600'
                  }`}
                  onClick={() => handleSelectTier(tier.name)}
                >
                  Select {tier.name}
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Featured Creators */}
      <div id="creators" className="py-20 bg-gray-900/50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Featured Creators</h2>
            <p className="text-gray-400 text-lg">
              Partner with top-tier creators who drive real engagement and conversions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {topCreators.map((creator) => (
              <Card key={creator.id} className="bg-gray-800/50 border-gray-700 p-6 hover:border-purple-500/50 transition-all cursor-pointer"
                    onClick={() => handleCreatorSelect(creator)}>
                <div className="flex items-center gap-3 mb-4">
                  <img 
                    src={creator.image} 
                    alt={creator.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-semibold">{creator.name}</h3>
                    <p className="text-sm text-gray-400">{creator.username}</p>
                  </div>
                </div>

                <p className="text-sm text-gray-300 mb-4">{creator.bio}</p>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Followers</span>
                    <span className="font-semibold">{creator.followers}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Engagement</span>
                    <span className="font-semibold">{creator.engagement}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Success Rate</span>
                    <span className="font-semibold text-green-400">{creator.successRate}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mb-4">
                  {creator.categories.map((category) => (
                    <Badge key={category} variant="outline" className="border-gray-600 text-gray-300 text-xs">
                      {category}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-3 w-3 ${
                          i < Math.floor(creator.rating)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-600"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-400">{creator.rating}</span>
                  <span className="text-sm text-gray-400">({creator.campaigns} campaigns)</span>
                </div>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600"
              onClick={() => handleSelectTier("Professional")}
            >
              <Crown className="mr-2 h-5 w-5" />
              Get Access to All Creators
            </Button>
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      <Dialog open={showPaymentModal} onOpenChange={setShowPaymentModal}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-center">
              Complete Your Purchase
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-2">{selectedTier}</h3>
              <p className="text-gray-400">Get instant access to our creator marketplace</p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="your@company.com"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="company">Company Name</Label>
                <Input 
                  id="company" 
                  placeholder="Your Company"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="wallet">Wallet Address</Label>
                <Input 
                  id="wallet" 
                  placeholder="0x..."
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="goals">Campaign Goals</Label>
                <Textarea 
                  id="goals" 
                  placeholder="Describe your Web3 user onboarding goals..."
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button 
                variant="outline" 
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                onClick={() => setShowPaymentModal(false)}
              >
                Cancel
              </Button>
              <Button 
                className="flex-1 bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600"
                onClick={() => {
                  // Handle payment logic here
                  setShowPaymentModal(false);
                }}
              >
                <CreditCard className="mr-2 h-4 w-4" />
                Pay with Crypto
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}