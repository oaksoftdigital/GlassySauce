import { useMemo } from "react";
import { LiFiWidget, WidgetConfig } from '@lifi/widget';

export default function Bridge() {

  // Li.Fi Widget Configuration with clean theme and ETH/USDT default
  const widgetConfig: WidgetConfig = useMemo(() => ({
    appearance: 'dark',
    fromChain: 1, // Ethereum
    fromToken: '0x0000000000000000000000000000000000000000', // ETH
    toChain: 1, // Ethereum  
    toToken: '0xdAC17F958D2ee523a2206206994597C13D831ec7', // USDT
    theme: {
      palette: {
        primary: { 
          main: '#14B8A6'
        },
        secondary: { 
          main: '#8B5CF6'
        },
        background: {
          default: 'rgba(15, 23, 42, 0.95)',
          paper: 'rgba(30, 41, 59, 0.8)',
        },
        text: {
          primary: '#ffffff',
          secondary: 'rgba(255, 255, 255, 0.7)',
        },
        grey: {
          200: 'rgba(255, 255, 255, 0.1)',
          300: 'rgba(255, 255, 255, 0.2)',
          700: 'rgba(255, 255, 255, 0.4)',
          800: 'rgba(255, 255, 255, 0.6)',
        },
      },
      shape: {
        borderRadius: 16,
        borderRadiusSecondary: 12,
        borderRadiusTertiary: 24,
      },
      container: {
        background: 'rgba(15, 23, 42, 0.8)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRadius: '24px',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
        maxHeight: 800,
      },
      components: {
        MuiCard: {
          defaultProps: { variant: 'outlined' },
          styleOverrides: {
            root: {
              background: 'rgba(30, 41, 59, 0.6)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
            },
          },
        },
        MuiButton: {
          styleOverrides: {
            root: {
              background: 'linear-gradient(135deg, #14B8A6 0%, #06B6D4 25%, #8B5CF6 75%, #A855F7 100%)',
              color: '#ffffff',
              fontWeight: '600',
              textTransform: 'none',
              '&:hover': {
                opacity: 0.9,
                transform: 'translateY(-1px)',
              },
            },
          },
        },
        MuiInputCard: {
          styleOverrides: {
            root: {
              background: 'rgba(30, 41, 59, 0.6)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
            },
          },
        },
      },
    },
    buildUrl: true,
    integrator: 'fans-tech',
    fee: 0.005,
    // Remove Li.Fi branding
    hiddenUI: ['poweredBy'],
  }), []);

  // Professional Chart Component
  const TradingChart = ({ onClose }: { onClose?: () => void }) => {
    return (
      <GlassCard className="p-6">
        <div className="space-y-4">
          {/* Chart Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-r from-teal-500 to-purple-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">E</span>
                </div>
                <div className="flex items-center gap-2 text-white">
                  <span className="font-bold">ETH / USDT</span>
                  <span className="text-white/40">⚡</span>
                  <span className="text-white/60">25/07/02 14:07</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">15m</Badge>
                <div className="flex items-center gap-1 text-white/60">
                  <BarChart3 className="w-4 h-4" />
                  <span className="text-sm">Indicators</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="w-8 h-8 glass rounded flex items-center justify-center text-white/60 hover:text-white transition-colors">
                <RotateCcw className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 glass rounded flex items-center justify-center text-white/60 hover:text-white transition-colors">
                <Layers className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 glass rounded flex items-center justify-center text-white/60 hover:text-white transition-colors">
                <Maximize2 className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 glass rounded flex items-center justify-center text-white/60 hover:text-white transition-colors">
                <Camera className="w-4 h-4" />
              </button>
              {onClose && (
                <button 
                  onClick={onClose}
                  className="w-8 h-8 glass rounded flex items-center justify-center text-white/60 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Price Information */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <span className="text-teal-400 font-mono">O0.01373</span>
              <span className="text-teal-400 font-mono">H0.01373</span>
              <span className="text-teal-400 font-mono">L0.01373</span>
              <span className="text-teal-400 font-mono">C0.01373</span>
              <span className="text-teal-400 font-mono">0 (0.00%)</span>
            </div>
            <div className="text-right text-white/60 text-sm">
              <div>High <span className="text-white">0.01947</span></div>
              <div className="text-right">Low <span className="text-white">0.01465</span></div>
            </div>
          </div>

          {/* Professional Candlestick Chart */}
          <div className="relative h-96 bg-slate-900/30 rounded-lg overflow-hidden">
            <svg width="100%" height="100%" viewBox="0 0 900 384">
              <defs>
                <linearGradient id="chartBg" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="rgba(71, 85, 105, 0.1)" />
                  <stop offset="100%" stopColor="rgba(15, 23, 42, 0.1)" />
                </linearGradient>
              </defs>

              {/* Grid Lines - Matching TradingView style */}
              {[...Array(15)].map((_, i) => (
                <line key={`v-${i}`} x1={80 + (i * 55)} y1="20" x2={80 + (i * 55)} y2="320" stroke="rgba(71, 85, 105, 0.3)" strokeWidth="1" />
              ))}
              {[...Array(10)].map((_, i) => (
                <line key={`h-${i}`} x1="80" y1={40 + (i * 28)} x2="850" y2={40 + (i * 28)} stroke="rgba(71, 85, 105, 0.3)" strokeWidth="1" />
              ))}

              {/* Candlesticks with proper TradingView styling */}
              {[
                // Dense beginning section
                { x: 100, open: 180, close: 200, high: 170, low: 190, bull: true },
                { x: 115, open: 200, close: 185, high: 210, low: 195, bull: false },
                { x: 130, open: 185, close: 205, high: 175, low: 195, bull: true },
                { x: 145, open: 205, close: 190, high: 215, low: 200, bull: false },
                { x: 160, open: 190, close: 210, high: 180, low: 200, bull: true },
                { x: 175, open: 210, close: 195, high: 220, low: 205, bull: false },
                { x: 190, open: 195, close: 215, high: 185, low: 205, bull: true },
                { x: 205, open: 215, close: 200, high: 225, low: 210, bull: false },
                { x: 220, open: 200, close: 220, high: 190, low: 210, bull: true },
                { x: 235, open: 220, close: 205, high: 230, low: 215, bull: false },
                { x: 250, open: 205, close: 225, high: 195, low: 215, bull: true },
                { x: 265, open: 225, close: 210, high: 235, low: 220, bull: false },
                
                // Dip section (matching the chart's pattern)
                { x: 280, open: 210, close: 185, high: 220, low: 175, bull: false },
                { x: 295, open: 185, close: 160, high: 195, low: 150, bull: false },
                { x: 310, open: 160, close: 135, high: 170, low: 125, bull: false },
                { x: 325, open: 135, close: 110, high: 145, low: 100, bull: false },
                { x: 340, open: 110, close: 140, high: 100, low: 120, bull: true },
                { x: 355, open: 140, close: 165, high: 130, low: 145, bull: true },
                { x: 370, open: 165, close: 145, high: 175, low: 155, bull: false },
                { x: 385, open: 145, close: 120, high: 155, low: 110, bull: false },
                { x: 400, open: 120, close: 95, high: 130, low: 85, bull: false },
                { x: 415, open: 95, close: 70, high: 105, low: 60, bull: false },
                
                // Recovery section
                { x: 430, open: 70, close: 105, high: 60, low: 85, bull: true },
                { x: 445, open: 105, close: 130, high: 95, low: 115, bull: true },
                { x: 460, open: 130, close: 155, high: 120, low: 140, bull: true },
                { x: 475, open: 155, close: 180, high: 145, low: 165, bull: true },
                { x: 490, open: 180, close: 205, high: 170, low: 190, bull: true },
                { x: 505, open: 205, close: 185, high: 215, low: 195, bull: false },
                { x: 520, open: 185, close: 210, high: 175, low: 195, bull: true },
                
                // Final section with more consolidation
                { x: 535, open: 210, close: 195, high: 220, low: 205, bull: false },
                { x: 550, open: 195, close: 215, high: 185, low: 205, bull: true },
                { x: 565, open: 215, close: 200, high: 225, low: 210, bull: false },
                { x: 580, open: 200, close: 220, high: 190, low: 210, bull: true },
                { x: 595, open: 220, close: 205, high: 230, low: 215, bull: false },
                { x: 610, open: 205, close: 225, high: 195, low: 215, bull: true },
                { x: 625, open: 225, close: 210, high: 235, low: 220, bull: false },
                { x: 640, open: 210, close: 230, high: 200, low: 220, bull: true },
                { x: 655, open: 230, close: 215, high: 240, low: 225, bull: false },
                { x: 670, open: 215, close: 235, high: 205, low: 225, bull: true },
                { x: 685, open: 235, close: 220, high: 245, low: 230, bull: false },
                { x: 700, open: 220, close: 240, high: 210, low: 230, bull: true },
                { x: 715, open: 240, close: 225, high: 250, low: 235, bull: false },
                { x: 730, open: 225, close: 245, high: 215, low: 235, bull: true },
                { x: 745, open: 245, close: 230, high: 255, low: 240, bull: false },
                { x: 760, open: 230, close: 250, high: 220, low: 240, bull: true },
                { x: 775, open: 250, close: 235, high: 260, low: 245, bull: false },
                { x: 790, open: 235, close: 255, high: 225, low: 245, bull: true },
                { x: 805, open: 255, close: 240, high: 265, low: 250, bull: false },
                { x: 820, open: 240, close: 260, high: 230, low: 250, bull: true }
              ].map((candle, i) => {
                const bullColor = "#14B8A6"; // Teal for bullish
                const bearColor = "#EF4444"; // Red for bearish
                const color = candle.bull ? bullColor : bearColor;
                const bodyHeight = Math.abs(candle.close - candle.open);
                
                return (
                  <g key={i}>
                    {/* Wick - thin line from high to low */}
                    <line 
                      x1={candle.x} 
                      y1={candle.high} 
                      x2={candle.x} 
                      y2={candle.low} 
                      stroke={color} 
                      strokeWidth="1"
                    />
                    {/* Body - filled rectangle */}
                    <rect 
                      x={candle.x - 3} 
                      y={Math.min(candle.open, candle.close)} 
                      width="6" 
                      height={bodyHeight || 1} 
                      fill={color}
                      stroke={color}
                      strokeWidth="1"
                    />
                  </g>
                );
              })}

              {/* Volume bars at bottom */}
              {[...Array(40)].map((_, i) => {
                const height = Math.random() * 15 + 5;
                const isBull = Math.random() > 0.5;
                return (
                  <rect
                    key={i}
                    x={98 + (i * 18)}
                    y={340 - height}
                    width="12"
                    height={height}
                    fill={isBull ? "rgba(20, 184, 166, 0.3)" : "rgba(239, 68, 68, 0.3)"}
                  />
                );
              })}

              {/* Price labels on right - matching the screenshot */}
              <text x="860" y="50" fill="#64748B" fontSize="11">0.01947</text>
              <text x="860" y="78" fill="#64748B" fontSize="11">0.0139</text>
              <text x="860" y="106" fill="#64748B" fontSize="11">0.01385</text>
              <text x="860" y="134" fill="#64748B" fontSize="11">0.0138</text>
              <text x="860" y="162" fill="#64748B" fontSize="11">0.01375</text>
              
              {/* Current price highlight */}
              <rect x="850" y="185" width="60" height="20" fill="#14B8A6" rx="3" />
              <text x="860" y="198" fill="#000000" fontSize="11" fontWeight="bold">0.01373</text>
              
              <text x="860" y="218" fill="#64748B" fontSize="11">0.0137</text>
              <text x="860" y="246" fill="#64748B" fontSize="11">0.01365</text>
              <text x="860" y="274" fill="#64748B" fontSize="11">0.0136</text>
              <text x="860" y="302" fill="#64748B" fontSize="11">0.01355</text>
              <text x="860" y="330" fill="#64748B" fontSize="11">0.01465</text>

              {/* Time labels at bottom */}
              <text x="150" y="375" fill="#64748B" fontSize="11">18:00</text>
              <text x="350" y="375" fill="#64748B" fontSize="11">2</text>
              <text x="550" y="375" fill="#64748B" fontSize="11">06:00</text>
              <text x="750" y="375" fill="#64748B" fontSize="11">12:00</text>
            </svg>

            {/* Chart controls overlay */}
            <div className="absolute bottom-4 left-4 flex items-center gap-2">
              <div className="bg-slate-800 rounded-full w-8 h-8 flex items-center justify-center">
                <span className="text-white text-xs font-bold">TV</span>
              </div>
            </div>

            <div className="absolute bottom-4 right-4 flex items-center gap-2 text-white/60 text-xs">
              <span>10:06:09 (UTC-4)</span>
              <span>%</span>
              <span>log</span>
              <span>auto</span>
            </div>
          </div>
        </div>
      </GlassCard>
    );
  };

  return (
    <div className="min-h-screen p-6">
      {/* Simple Clean Header */}
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Cross Chain Exchange</h1>
      </div>

      {/* Main Layout Container */}
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col items-center space-y-8">
          
          {/* Centered Trading Widget */}
          <div className="w-[420px]">
            {/* Clean Li.Fi Widget */}
            <div className="relative">
              <LiFiWidget 
                integrator="fans-tech" 
                config={widgetConfig}
              />
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}