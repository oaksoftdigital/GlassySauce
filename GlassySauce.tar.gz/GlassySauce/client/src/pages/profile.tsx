import { useState } from "react";
import { useParams } from "wouter";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart,
  MessageCircle,
  Repeat2,
  Bookmark,
  Share,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  Copy,
  ExternalLink,
  Filter,
  MoreHorizontal,
  Shield,
  Calendar,
  Globe,
  Twitter,
  Instagram
} from "lucide-react";
import { 
  EthereumIcon, 
  UsdtIcon, 
  UsdcIcon, 
  FansIcon,
  BitcoinIcon
} from "@/components/ui/crypto-icons";

interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  isVerified: boolean;
  following: number;
  followers: number;
  joinedDate: string;
  website?: string;
  social: {
    twitter?: string;
    instagram?: string;
  };
  wallet: {
    netWorth: string;
    dayChange: string;
    dayChangePercent: string;
    isPositive: boolean;
  };
}

interface Post {
  id: string;
  content: string;
  timestamp: string;
  likes: number;
  comments: number;
  reposts: number;
  isLiked: boolean;
  isReposted: boolean;
  isSaved: boolean;
  transaction?: {
    type: "received" | "sent";
    token: string;
    symbol: string;
    amount: string;
    usdValue: string;
    from?: string;
    to?: string;
    icon: any;
    color: string;
  };
}

interface PortfolioItem {
  token: string;
  symbol: string;
  balance: string;
  usdValue: string;
  change24h: string;
  changePercent: string;
  isPositive: boolean;
  icon: any;
}

interface WalletItem {
  address: string;
  name: string;
  balance: string;
  type: "hot" | "cold" | "hardware";
}

export default function Profile() {
  const { userId } = useParams();
  const [activeTab, setActiveTab] = useState("activity");
  const [activeSubTab, setActiveSubTab] = useState("posts");

  // Mock user data - would come from API
  const userProfile: UserProfile = {
    id: userId || "1",
    username: "vitalik.buterin",
    displayName: "Vitalik Buterin",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    bio: "co-founder, ethereum. blog.ethereum.org. fable balance: First level balance. (in phon: n crew fund) https://etherscancom/2019/08/23/is-the-balance/",
    isVerified: true,
    following: 5,
    followers: 3276,
    joinedDate: "Sep 2015",
    website: "ethereum.org",
    social: {
      twitter: "@VitalikButerin",
      instagram: "@vitalik.buterin"
    },
    wallet: {
      netWorth: "$194B",
      dayChange: "+$18.9M",
      dayChangePercent: "+2.4%",
      isPositive: true
    }
  };

  const posts: Post[] = [
    {
      id: "1",
      content: "Received 🌿 ETH from 🌱 0x0f...d395",
      timestamp: "2h",
      likes: 42,
      comments: 12,
      reposts: 8,
      isLiked: false,
      isReposted: false,
      isSaved: false,
      transaction: {
        type: "received",
        token: "Ethereum",
        symbol: "ETH",
        amount: "1.789",
        usdValue: "$2.49M",
        from: "0x0f...d395",
        icon: EthereumIcon,
        color: "#627EEA"
      }
    },
    {
      id: "2", 
      content: "Received 🌱 $ALUM from 🌱 0xc6...4ESE",
      timestamp: "4h",
      likes: 128,
      comments: 34,
      reposts: 21,
      isLiked: true,
      isReposted: false,
      isSaved: true,
      transaction: {
        type: "received",
        token: "ALUM",
        symbol: "ALUM",
        amount: "1,250",
        usdValue: "$24.9K",
        from: "0xc6...4ESE",
        icon: FansIcon,
        color: "#14B8A6"
      }
    },
    {
      id: "3",
      content: "Sent 🌿 USDC to 🌱 0x73...589%",
      timestamp: "1d",
      likes: 89,
      comments: 15,
      reposts: 6,
      isLiked: false,
      isReposted: true,
      isSaved: false,
      transaction: {
        type: "sent",
        token: "USD Coin",
        symbol: "USDC",
        amount: "50,000",
        usdValue: "$50K",
        to: "0x73...589%",
        icon: UsdcIcon,
        color: "#2775CA"
      }
    },
    {
      id: "4",
      content: "Received 🌱 MEME from 🌱 0x44...999",
      timestamp: "2d",
      likes: 156,
      comments: 67,
      reposts: 43,
      isLiked: false,
      isReposted: false,
      isSaved: false,
      transaction: {
        type: "received",
        token: "MEME",
        symbol: "MEME",
        amount: "1M",
        usdValue: "$8.85K",
        from: "0x44...999",
        icon: FansIcon,
        color: "#8B5CF6"
      }
    }
  ];

  const portfolioItems: PortfolioItem[] = [
    {
      token: "Ethereum",
      symbol: "ETH",
      balance: "1,205.67",
      usdValue: "$2.89M",
      change24h: "+$45.2K",
      changePercent: "+1.58%",
      isPositive: true,
      icon: EthereumIcon
    },
    {
      token: "Bitcoin",
      symbol: "BTC",
      balance: "45.23",
      usdValue: "$1.67M",
      change24h: "-$12.1K",
      changePercent: "-0.72%",
      isPositive: false,
      icon: BitcoinIcon
    },
    {
      token: "USD Coin",
      symbol: "USDC",
      balance: "890,450",
      usdValue: "$890.45K",
      change24h: "+$1.2K",
      changePercent: "+0.13%",
      isPositive: true,
      icon: UsdcIcon
    },
    {
      token: "Tether USD",
      symbol: "USDT",
      balance: "456,789",
      usdValue: "$456.79K",
      change24h: "-$890",
      changePercent: "-0.19%",
      isPositive: false,
      icon: UsdtIcon
    }
  ];

  const walletAddresses: WalletItem[] = [
    {
      address: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
      name: "Main Wallet",
      balance: "$4.2M",
      type: "hot"
    },
    {
      address: "0x742637b2F91c1Aa3B46C1C11bA473cF0b8CA45E2", 
      name: "Trading Wallet",
      balance: "$890K",
      type: "hot"
    },
    {
      address: "0x123456789abcdef123456789abcdef123456789a",
      name: "Cold Storage", 
      balance: "$1.8M",
      type: "cold"
    }
  ];

  const handleLike = (postId: string) => {
    // Handle like functionality
    console.log("Liked post:", postId);
  };

  const handleComment = (postId: string) => {
    // Handle comment functionality
    console.log("Comment on post:", postId);
  };

  const handleRepost = (postId: string) => {
    // Handle repost functionality
    console.log("Reposted:", postId);
  };

  const handleSave = (postId: string) => {
    // Handle save functionality
    console.log("Saved post:", postId);
  };

  const handleShare = (postId: string) => {
    // Handle share functionality
    console.log("Shared post:", postId);
  };

  const PostCard = ({ post }: { post: Post }) => (
    <GlassCard className="p-6 space-y-4">
      <div className="flex items-start gap-4">
        <Avatar className="w-12 h-12">
          <AvatarImage src={userProfile.avatar} />
          <AvatarFallback>{userProfile.displayName[0]}</AvatarFallback>
        </Avatar>
        
        <div className="flex-1 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-white">{userProfile.displayName}</span>
              {userProfile.isVerified && (
                <Shield className="w-4 h-4 text-blue-400" />
              )}
              <span className="text-white/60">@{userProfile.username}</span>
              <span className="text-white/40">·</span>
              <span className="text-white/60">{post.timestamp}</span>
            </div>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="w-4 h-4 text-white/60" />
            </Button>
          </div>

          <p className="text-white">{post.content}</p>

          {post.transaction && (
            <div className="bg-slate-800/30 rounded-2xl p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center`} style={{backgroundColor: `${post.transaction.color}20`}}>
                    <post.transaction.icon size={20} style={{color: post.transaction.color}} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">{post.transaction.amount} {post.transaction.symbol}</span>
                      {post.transaction.type === "received" ? (
                        <ArrowDownRight className="w-4 h-4 text-green-400" />
                      ) : (
                        <ArrowUpRight className="w-4 h-4 text-red-400" />
                      )}
                    </div>
                    <div className="text-white/60 text-sm">
                      {post.transaction.type === "received" ? "from" : "to"} {post.transaction.from || post.transaction.to}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-white">{post.transaction.usdValue}</div>
                </div>
              </div>
            </div>
          )}

          {/* Post Interactions */}
          <div className="flex items-center justify-between pt-2 border-t border-white/10">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleComment(post.id)}
              className="text-white/60 hover:text-white"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              {post.comments}
            </Button>

            <Button
              variant="ghost" 
              size="sm"
              onClick={() => handleRepost(post.id)}
              className={`${post.isReposted ? 'text-green-400' : 'text-white/60'} hover:text-green-400`}
            >
              <Repeat2 className="w-4 h-4 mr-2" />
              {post.reposts}
            </Button>

            <Button
              variant="ghost"
              size="sm" 
              onClick={() => handleLike(post.id)}
              className={`${post.isLiked ? 'text-red-400' : 'text-white/60'} hover:text-red-400`}
            >
              <Heart className={`w-4 h-4 mr-2 ${post.isLiked ? 'fill-current' : ''}`} />
              {post.likes}
            </Button>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSave(post.id)}
                className={`${post.isSaved ? 'text-yellow-400' : 'text-white/60'} hover:text-yellow-400`}
              >
                <Bookmark className={`w-4 h-4 ${post.isSaved ? 'fill-current' : ''}`} />
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleShare(post.id)}
                className="text-white/60 hover:text-white"
              >
                <Share className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </GlassCard>
  );

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Profile Header */}
        <GlassCard className="p-8">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Profile Info */}
            <div className="flex-1 space-y-6">
              <div className="flex items-start gap-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={userProfile.avatar} />
                  <AvatarFallback>{userProfile.displayName[0]}</AvatarFallback>
                </Avatar>
                
                <div className="flex-1 space-y-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h1 className="text-2xl font-bold text-white">{userProfile.displayName}</h1>
                      {userProfile.isVerified && (
                        <Shield className="w-5 h-5 text-blue-400" />
                      )}
                    </div>
                    <p className="text-white/60">@{userProfile.username}</p>
                  </div>

                  <p className="text-white">{userProfile.bio}</p>

                  <div className="flex flex-wrap items-center gap-4 text-sm text-white/60">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>Joined {userProfile.joinedDate}</span>
                    </div>
                    {userProfile.website && (
                      <div className="flex items-center gap-1">
                        <Globe className="w-4 h-4" />
                        <span className="text-teal-400">{userProfile.website}</span>
                      </div>
                    )}
                    {userProfile.social.twitter && (
                      <div className="flex items-center gap-1">
                        <Twitter className="w-4 h-4" />
                        <span className="text-blue-400">{userProfile.social.twitter}</span>
                      </div>
                    )}
                    {userProfile.social.instagram && (
                      <div className="flex items-center gap-1">
                        <Instagram className="w-4 h-4" />
                        <span className="text-pink-400">{userProfile.social.instagram}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-6">
                    <div>
                      <span className="font-semibold text-white">{userProfile.following}</span>
                      <span className="text-white/60 ml-1">Following</span>
                    </div>
                    <div>
                      <span className="font-semibold text-white">{userProfile.followers}</span>
                      <span className="text-white/60 ml-1">Followers</span>
                    </div>
                  </div>

                  <GradientButton variant="saucy" className="w-fit">
                    Following
                  </GradientButton>
                </div>
              </div>
            </div>

            {/* Wallet Summary */}
            <div className="md:w-80">
              <GlassCard className="p-6 bg-gradient-to-br from-teal-500/10 to-purple-500/10">
                <div className="text-center space-y-4">
                  <div>
                    <div className="text-sm text-white/60 mb-1">NET WORTH</div>
                    <div className="text-3xl font-bold text-white">{userProfile.wallet.netWorth}</div>
                  </div>
                  
                  <div className="flex items-center justify-center gap-2">
                    {userProfile.wallet.isPositive ? (
                      <TrendingUp className="w-4 h-4 text-green-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    )}
                    <span className={`font-semibold ${userProfile.wallet.isPositive ? 'text-green-400' : 'text-red-400'}`}>
                      {userProfile.wallet.dayChange} ({userProfile.wallet.dayChangePercent})
                    </span>
                  </div>

                  <div className="text-xs text-white/40">DAILY CHANGE</div>
                </div>
              </GlassCard>
            </div>
          </div>
        </GlassCard>

        {/* Profile Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="flex items-center justify-between">
            <TabsList className="bg-slate-800/50">
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
              <TabsTrigger value="wallets">Wallets</TabsTrigger>
              <TabsTrigger value="contracts">Deployed Contracts</TabsTrigger>
            </TabsList>
            
            <Button variant="ghost" className="text-white/60">
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Button>
          </div>

          <TabsContent value="activity" className="space-y-6">
            {/* Sub Tabs */}
            <Tabs value={activeSubTab} onValueChange={setActiveSubTab}>
              <TabsList className="bg-slate-800/50">
                <TabsTrigger value="posts">Posts</TabsTrigger>
                <TabsTrigger value="transactions">Transactions</TabsTrigger>
                <TabsTrigger value="replies">Replies</TabsTrigger>
              </TabsList>

              <TabsContent value="posts" className="space-y-4">
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </TabsContent>

              <TabsContent value="transactions" className="space-y-4">
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </TabsContent>

              <TabsContent value="replies" className="space-y-4">
                <div className="text-center py-12">
                  <p className="text-white/60">No replies yet</p>
                </div>
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="portfolio" className="space-y-4">
            {portfolioItems.map((item, index) => (
              <GlassCard key={index} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-slate-800/50 flex items-center justify-center">
                      <item.icon size={24} />
                    </div>
                    <div>
                      <div className="font-semibold text-white">{item.token}</div>
                      <div className="text-white/60 text-sm">{item.balance} {item.symbol}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-white">{item.usdValue}</div>
                    <div className={`text-sm ${item.isPositive ? 'text-green-400' : 'text-red-400'}`}>
                      {item.change24h} ({item.changePercent})
                    </div>
                  </div>
                </div>
              </GlassCard>
            ))}
          </TabsContent>

          <TabsContent value="wallets" className="space-y-4">
            {walletAddresses.map((wallet, index) => (
              <GlassCard key={index} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">{wallet.name}</span>
                      <Badge variant="outline" className={`text-xs ${
                        wallet.type === 'cold' ? 'text-blue-400 border-blue-400' :
                        wallet.type === 'hardware' ? 'text-purple-400 border-purple-400' :
                        'text-green-400 border-green-400'
                      }`}>
                        {wallet.type}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-white/60 text-sm">
                      <span className="font-mono">{wallet.address}</span>
                      <Button variant="ghost" size="sm" className="p-1">
                        <Copy className="w-3 h-3" />
                      </Button>
                      <Button variant="ghost" size="sm" className="p-1">
                        <ExternalLink className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-white">{wallet.balance}</div>
                  </div>
                </div>
              </GlassCard>
            ))}
          </TabsContent>

          <TabsContent value="contracts" className="space-y-4">
            <div className="text-center py-12">
              <p className="text-white/60">No deployed contracts</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}