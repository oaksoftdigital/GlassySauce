import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Search, RefreshCw } from "lucide-react";
import { OnlyFansIcon, InstagramIcon, TwitterIcon } from "@/components/ui/crypto-icons";

interface SocialPlatform {
  id: string;
  name: string;
  value: string;
  gradient: string;
  logo: string;
}

export default function SocialPosting() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("platforms");

  const platforms: SocialPlatform[] = [
    {
      id: "onlyfans",
      name: "OnlyFans",
      value: "$124.89",
      gradient: "from-blue-500 to-blue-600",
      logo: "OF"
    },
    {
      id: "instagram", 
      name: "Instagram",
      value: "$89.34",
      gradient: "from-pink-500 to-purple-600",
      logo: "IG"
    },
    {
      id: "twitter",
      name: "X (Twitter)", 
      value: "$45.67",
      gradient: "from-gray-700 to-black",
      logo: "X"
    }
  ];

  const filteredPlatforms = platforms.filter(platform =>
    platform.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-white">Social Posting</h1>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
            <input
              type="text"
              placeholder="Find platforms..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-80 pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-pink-500/50"
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-8 mb-6">
          <button
            onClick={() => setActiveTab("platforms")}
            className={`text-lg font-medium pb-2 border-b-2 transition-colors ${
              activeTab === "platforms"
                ? "text-white border-cyan-400"
                : "text-white/60 border-transparent hover:text-white"
            }`}
          >
            Platforms
          </button>
          <button
            onClick={() => setActiveTab("scheduled")}
            className={`text-lg font-medium pb-2 border-b-2 transition-colors ${
              activeTab === "scheduled"
                ? "text-white border-cyan-400"
                : "text-white/60 border-transparent hover:text-white"
            }`}
          >
            Scheduled
          </button>
          <button className="ml-auto text-white/60 hover:text-white transition-colors">
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>

        {/* Platform Cards */}
        <div className="space-y-1">
          {filteredPlatforms.map((platform, index) => (
            <div
              key={platform.id}
              className="flex items-center gap-4 p-4 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
            >
              {/* Platform Logo */}
              <div className="relative">
                <div className="w-12 h-12 rounded-lg flex items-center justify-center">
                  {platform.id === "onlyfans" && <OnlyFansIcon size={48} />}
                  {platform.id === "instagram" && <InstagramIcon size={48} />}
                  {platform.id === "twitter" && <TwitterIcon size={48} />}
                </div>
              </div>

              {/* Platform Info */}
              <div className="flex-1">
                <div className="text-white font-medium text-lg mb-1">
                  {platform.name}
                </div>
                <div className="text-white/60 text-sm">
                  Connected • Last post: 2h ago
                </div>
              </div>

              {/* Value */}
              <div className="text-right">
                <div className="text-white font-medium text-lg">
                  {platform.value}
                </div>
                <div className="text-green-400 text-sm">
                  +5.2%
                </div>
              </div>

              {/* Post Button */}
              <div className="ml-4">
                <GradientButton
                  variant="glass"
                  size="sm"
                  onClick={() => {
                    alert(`Opening post composer for ${platform.name}`);
                  }}
                >
                  Post
                </GradientButton>
              </div>
            </div>
          ))}

          {filteredPlatforms.length === 0 && (
            <div className="text-center py-16">
              <div className="text-white/60 text-lg">No platforms found</div>
              <div className="text-white/40 text-sm mt-2">
                {searchQuery ? "Try a different search term" : "Connect your social accounts to get started"}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}