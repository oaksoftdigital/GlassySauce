import { useState, useEffect } from "react";
import { Search, Bell, RotateCcw, MessageCircle, Plus, ArrowLeft, MoreHorizontal, Image, Send } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { wsManager } from "@/lib/websocket";
import { NewClubModal } from "@/components/chat/new-club-modal";
import type { ChatRoom, ChatMessage } from "@/types";

// Mock chat messages for individual rooms
const chatMessages: Record<number, Array<{
  id: number;
  user: string;
  avatar: string;
  message: string;
  time: string;
  isCreator: boolean;
  reactions?: Record<string, number>;
}>> = {
  1: [
    {
      id: 1,
      user: "VM",
      avatar: "https://i.pravatar.cc/40?img=1",
      message: "🫧 Replying to 🫧 MATSO\nVanadiii 🫧",
      time: "4:23 AM",
      isCreator: true
    },
    {
      id: 2,
      user: "VM",
      avatar: "https://i.pravatar.cc/40?img=1", 
      message: "Jajajaj, aún no llega al X3.\n🥹 🤩 la espero para grabar vídeo, los 117=X3 🫧",
      time: "5:00 AM",
      isCreator: true,
      reactions: { "🫧": 3, "⚡": 2, "👍": 4 }
    },
    {
      id: 3,
      user: "Mugatu",
      avatar: "https://i.pravatar.cc/40?img=7",
      message: "Vanadi airdrop 🫧 🤩\nhttps://www.eleconomista.es/cripto/noticias/13440198/06/25/vanadi-pagara-un-bonus-2-millones-de-euros-al-consejo-si-dispara-su-cotizacion-con-el-bitcoin.html",
      time: "9:44 AM",
      isCreator: false,
      reactions: { "🚀": 1 }
    }
  ]
};

// Mock chat data to match friend.tech interface
const chatRooms = [
  {
    id: 1,
    name: "VM CLUB",
    avatar: "https://i.pravatar.cc/150?img=1",
    lastMessage: "🫧 VM: 🥹 🤩 y los murciélagos h...",
    time: "3h",
    price: "$85.72",
    hasUnread: false
  },
  {
    id: 2,
    name: "TXICOCRYPTO",
    avatar: "https://i.pravatar.cc/150?img=2",
    lastMessage: "🫧 markus: Muy interesante...s...",
    time: "8h",
    price: "$5.72",
    hasUnread: true
  },
  {
    id: 3,
    name: "d",
    avatar: "https://i.pravatar.cc/150?img=3",
    lastMessage: "SCM: Bought a key",
    time: "1mo",
    price: "$0.00",
    hasUnread: true
  },
  {
    id: 4,
    name: "$FR (FriendRock)",
    avatar: "https://i.pravatar.cc/150?img=4",
    lastMessage: "SCM: thats a cool app",
    time: "3mo",
    price: "$0.69",
    hasUnread: true
  },
  {
    id: 5,
    name: "SCM",
    avatar: "https://i.pravatar.cc/150?img=5",
    lastMessage: "Send them their first message",
    time: "",
    price: "$0.00",
    hasUnread: false
  }
];

export default function Chat() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("My room");
  const [showNewClubModal, setShowNewClubModal] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<{id: number; name: string; avatar: string} | null>(null);
  const [messageInput, setMessageInput] = useState("");

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      // Add message to chat (would integrate with WebSocket)
      console.log("Sending message:", messageInput);
      setMessageInput("");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Left Sidebar */}
      <div className="fixed left-0 top-0 h-full w-16 bg-white border-r border-gray-200 flex flex-col items-center py-4">
        <div className="w-8 h-8 bg-gray-300 rounded-lg mb-8"></div>
        
        <div className="space-y-6">
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 text-gray-400 mb-1">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 2l-9 5-9-5h18z"/>
              </svg>
            </div>
            <span className="text-xs text-gray-500">Wallet</span>
          </div>
          
          <div className="flex flex-col items-center">
            <MessageCircle className="w-6 h-6 text-gray-800 mb-1" />
            <span className="text-xs text-gray-800 font-medium">Chat</span>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 text-gray-400 mb-1">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
            </div>
            <span className="text-xs text-gray-500">Discover</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-16 h-screen flex flex-col">
        {/* Top Header */}
        <div className="h-16 bg-white border-b border-gray-200 flex items-center px-6 justify-between">
          <div className="flex items-center gap-4">
            <img
              src="https://i.pravatar.cc/40?img=6"
              alt="Profile"
              className="w-10 h-10 rounded-full"
            />
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Find friends or clubs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-100 border-0 rounded-lg text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          
          <Bell className="w-6 h-6 text-gray-400" />
        </div>

        {/* Chat Content */}
        <div className="flex-1 flex flex-col">
          {/* Tab Header */}
          <div className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-blue-600" />
                </div>
                <button
                  onClick={() => setActiveTab("My room")}
                  className={`px-3 py-1 rounded-lg text-sm font-medium ${
                    activeTab === "My room"
                      ? "text-blue-600 bg-blue-50"
                      : "text-gray-600 hover:text-gray-800"
                  }`}
                >
                  My room
                </button>
              </div>
              
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Plus className="w-5 h-5 text-green-600" />
                </div>
                <button
                  onClick={() => {
                    setActiveTab("New club");
                    setShowNewClubModal(true);
                  }}
                  className={`px-3 py-1 rounded-lg text-sm font-medium ${
                    activeTab === "New club"
                      ? "text-green-600 bg-green-50"
                      : "text-gray-600 hover:text-gray-800"
                  }`}
                >
                  New club
                </button>
              </div>
            </div>
            
            <RotateCcw className="w-5 h-5 text-gray-400" />
          </div>

          {/* Conditional Chat Content */}
          <div className="flex-1 overflow-y-auto">
            {selectedRoom ? (
              /* Individual Chat Room Interface */
              <div className="h-full flex flex-col">
                {/* Chat Room Header */}
                <div className="bg-white border-b border-gray-200 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setSelectedRoom(null)}
                        className="p-1 hover:bg-gray-100 rounded-lg"
                      >
                        <ArrowLeft className="w-5 h-5 text-gray-600" />
                      </button>
                      <img
                        src={selectedRoom.avatar}
                        alt={selectedRoom.name}
                        className="w-10 h-10 rounded-lg"
                      />
                      <div>
                        <h2 className="font-semibold text-gray-900 text-lg">{selectedRoom.name}</h2>
                        <p className="text-sm text-gray-500">151 members • $9,652.62</p>
                      </div>
                    </div>
                    <MoreHorizontal className="w-5 h-5 text-gray-400" />
                  </div>
                  
                  {/* Price Chart */}
                  <div className="mt-4 h-20 bg-gray-100 rounded-lg p-3">
                    <svg width="100%" height="100%" viewBox="0 0 280 60" className="overflow-visible">
                      <defs>
                        <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" style={{stopColor: '#10b981', stopOpacity: 0.3}} />
                          <stop offset="100%" style={{stopColor: '#10b981', stopOpacity: 0.1}} />
                        </linearGradient>
                      </defs>
                      {/* Chart data points */}
                      <path 
                        d="M10,45 L40,42 L70,38 L100,35 L130,32 L160,28 L190,25 L220,22 L250,18 L270,15"
                        stroke="#10b981" 
                        strokeWidth="2" 
                        fill="none"
                      />
                      <path 
                        d="M10,45 L40,42 L70,38 L100,35 L130,32 L160,28 L190,25 L220,22 L250,18 L270,15 L270,60 L10,60 Z"
                        fill="url(#chartGradient)"
                      />
                      {/* Data points */}
                      <circle cx="270" cy="15" r="3" fill="#10b981" />
                    </svg>
                  </div>
                </div>

                {/* Chat Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {chatMessages[selectedRoom.id]?.map((message) => (
                    <div key={message.id} className="flex gap-3">
                      <img
                        src={message.avatar}
                        alt={message.user}
                        className="w-8 h-8 rounded-full flex-shrink-0"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm text-gray-900">
                            {message.user}
                          </span>
                          {message.isCreator && (
                            <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
                              ✅ President
                            </span>
                          )}
                          <span className="text-xs text-gray-500">{message.time}</span>
                        </div>
                        
                        <div className="bg-cyan-100 rounded-lg p-3 max-w-md">
                          <p className="text-sm text-gray-900 whitespace-pre-line">
                            {message.message}
                          </p>
                        </div>
                        
                        {message.reactions && (
                          <div className="flex gap-2 mt-2">
                            {Object.entries(message.reactions).map(([emoji, count]) => (
                              <button
                                key={emoji}
                                className="flex items-center gap-1 bg-gray-100 hover:bg-gray-200 rounded-full px-2 py-1 text-xs"
                              >
                                <span>{emoji}</span>
                                <span className="text-gray-600">{count}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  {/* Unread indicator */}
                  <div className="flex items-center justify-center">
                    <div className="bg-blue-500 text-white text-xs px-3 py-1 rounded-full flex items-center gap-2">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                      Unread →
                    </div>
                  </div>
                </div>

                {/* Message Input */}
                <div className="bg-white border-t border-gray-200 p-4">
                  <div className="flex items-center gap-3">
                    <input
                      type="text"
                      placeholder="Write something..."
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      className="flex-1 bg-gray-100 border-0 rounded-lg px-4 py-2 text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <Image className="w-5 h-5" />
                    </button>
                    <button
                      onClick={handleSendMessage}
                      className="bg-cyan-400 hover:bg-cyan-500 text-white p-2 rounded-lg"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* Room List View */
              <div className="max-w-2xl mx-auto">
                {activeTab === "My room" && (
                  <div className="space-y-0">
                    {/* User's Club Rooms */}
                    <div 
                      className="flex items-center p-3 hover:bg-gray-50 cursor-pointer transition-colors border-b border-gray-100"
                      onClick={() => setSelectedRoom({ id: 1, name: "VM CLUB", avatar: "https://i.pravatar.cc/40?img=1" })}
                    >
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center text-white font-bold text-sm mr-3">
                        VM
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900 text-sm">VM CLUB</h3>
                          <div className="flex items-center gap-1 text-xs text-gray-500">
                            <span>1x</span>
                            <span>VM:</span>
                            <span>🌟</span>
                            <span>🎉</span>
                            <span>y los murcielagos h...</span>
                          </div>
                        </div>
                        <div className="text-xs text-gray-500">$85.24</div>
                      </div>
                      <div className="flex flex-col items-end">
                        <div className="text-xs text-gray-400 mb-1">4h</div>
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      </div>
                    </div>

                    <div 
                      className="flex items-center p-3 hover:bg-gray-50 cursor-pointer transition-colors border-b border-gray-100"
                      onClick={() => setSelectedRoom({ id: 2, name: "TXICOCRYPTO", avatar: "https://i.pravatar.cc/40?img=2" })}
                    >
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center text-white font-bold text-sm mr-3">
                      TX
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-900 text-sm">TXICOCRYPTO</h3>
                      </div>
                      <div className="text-xs text-gray-500 mb-1">
                        1x markus: Muy interesante....🚀
                      </div>
                      <div className="text-xs text-gray-500">$5.70</div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className="text-xs text-gray-400 mb-1">9h</div>
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    </div>
                  </div>

                  <div className="flex items-center p-3 hover:bg-gray-50 cursor-pointer transition-colors border-b border-gray-100">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center text-white font-bold text-sm mr-3">
                      d
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-900 text-sm">d</h3>
                      </div>
                      <div className="text-xs text-gray-500 mb-1">
                        1x Boy: Bought a key
                      </div>
                      <div className="text-xs text-gray-500">$0.00</div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className="text-xs text-gray-400 mb-1">1mo</div>
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    </div>
                  </div>

                  <div className="flex items-center p-3 hover:bg-gray-50 cursor-pointer transition-colors border-b border-gray-100">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-400 to-blue-500 flex items-center justify-center text-white font-bold text-sm mr-3">
                      $FR
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-900 text-sm">$FR (FriendRock)</h3>
                      </div>
                      <div className="text-xs text-gray-500 mb-1">
                        SCM: thats a cool app
                      </div>
                      <div className="text-xs text-gray-500">$0.02</div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className="text-xs text-gray-400 mb-1">3mo</div>
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    </div>
                  </div>

                  <div className="flex items-center p-3 hover:bg-gray-50 cursor-pointer transition-colors border-b border-gray-100">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-gray-400 to-gray-600 flex items-center justify-center text-white font-bold text-sm mr-3">
                      SCM
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-900 text-sm">SCM</h3>
                      </div>
                      <div className="text-xs text-gray-500 mb-1">
                        Send them their first message
                      </div>
                      <div className="text-xs text-gray-500">$0.00</div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className="text-xs text-gray-400 mb-1"></div>
                    </div>
                  </div>
                </div>
              )}
              
              {(activeTab === "Explore" || activeTab === "Search") && chatRooms
                .filter(room => 
                  room.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  room.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
                )
                .map((room) => (
                <div
                  key={room.id}
                  className="flex items-center gap-4 p-4 hover:bg-gray-50 border-b border-gray-100 cursor-pointer"
                >
                  <img
                    src={room.avatar}
                    alt={room.name}
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-semibold text-gray-900 truncate">
                        {room.name}
                      </h3>
                      <span className="text-sm text-gray-500">{room.time}</span>
                    </div>
                    
                    <p className="text-sm text-gray-600 truncate mb-1">
                      {room.lastMessage}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">{room.price}</span>
                      {room.hasUnread && (
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              {activeTab === "New club" && (
                <div className="text-center py-16">
                  <div className="text-gray-500 text-lg">Create a new club</div>
                  <div className="text-gray-400 text-sm mt-2">
                    Click "New club" to get started
                  </div>
                </div>
              )}
              
              {(activeTab === "Explore" || activeTab === "Search") && chatRooms.filter(room => 
                room.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                room.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
              ).length === 0 && (
                <div className="text-center py-16">
                  <div className="text-gray-500 text-lg">No chats found</div>
                  <div className="text-gray-400 text-sm mt-2">
                    {searchQuery ? "Try a different search term" : "Start a conversation to see it here"}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* New Club Modal */}
      <NewClubModal
        isOpen={showNewClubModal}
        onClose={() => setShowNewClubModal(false)}
      />
    </div>
  );
}
