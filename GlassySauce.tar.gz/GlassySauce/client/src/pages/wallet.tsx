import { useState } from "react";
import { Bell, Search, TrendingUp, Layers, DollarSign } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { TradingWidgetModal } from "@/components/wallet/trading-widget-modal";
import { StakingWidgetModal } from "@/components/wallet/staking-widget-modal";
import { LoansWidgetModal } from "@/components/wallet/loans-widget-modal";
import { FarmingModal } from "@/components/wallet/farming-modal";
import { SendReceiveModal } from "@/components/wallet/send-receive-modal";
import { BuySellModal } from "@/components/wallet/buy-sell-modal";
import { ClaimRewardsModal } from "@/components/wallet/claim-rewards-modal";
import { KeyPurchaseModal } from "@/components/wallet/key-purchase-modal";
import type { Portfolio } from "@/types";

export default function Wallet() {
  const [tradingModalOpen, setTradingModalOpen] = useState(false);
  const [stakingModalOpen, setStakingModalOpen] = useState(false);
  const [loansModalOpen, setLoansModalOpen] = useState(false);
  const [farmingModalOpen, setFarmingModalOpen] = useState(false);
  const [sendReceiveModalOpen, setSendReceiveModalOpen] = useState(false);
  const [buySellModalOpen, setBuySellModalOpen] = useState(false);
  const [claimModalOpen, setClaimModalOpen] = useState(false);
  const [keyPurchaseModalOpen, setKeyPurchaseModalOpen] = useState(false);
  const [claimRewardType, setClaimRewardType] = useState<'farm' | 'club'>('farm');
  
  const { data: portfolio, isLoading } = useQuery<Portfolio>({
    queryKey: ['/api/wallet/portfolio'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="animate-spin w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="w-12 h-12 rounded-full overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=48&h=48&fit=crop&crop=face" 
              alt="Profile" 
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1 mx-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Find creators or clubs..."
                className="w-full pl-12 pr-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <button className="p-3 text-white/60 hover:text-white">
            <Bell className="w-6 h-6" />
          </button>
        </div>

        {/* Wallet Value & Price */}
        <div className="flex items-center space-x-12 mb-12">
          <div>
            <p className="text-white/60 text-sm mb-2">Wallet Value</p>
            <p className="text-4xl font-bold text-white">$125.86</p>
          </div>
          <div>
            <p className="text-white/60 text-sm mb-2">$FANS Price</p>
            <p className="text-4xl font-bold text-pink-400">$0.03</p>
          </div>
        </div>

        {/* Assets Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* ETH */}
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <svg width="32" height="32" viewBox="0 0 24 24" className="text-white">
                <path d="M12 1.5L5.25 12.75L12 16.5L18.75 12.75L12 1.5z" fill="currentColor"/>
                <path d="M12 18L5.25 14.25L12 22.5L18.75 14.25L12 18z" fill="currentColor"/>
              </svg>
            </div>
            <p className="text-white/60 text-sm mb-2">ETH</p>
            <p className="text-xl font-bold text-white mb-4">◆ 0.005</p>
            <button 
              className="bg-gradient-to-r from-teal-500 to-cyan-500 text-white px-6 py-2 rounded-full font-medium hover:from-teal-600 hover:to-cyan-600 transition-colors shadow-lg"
              onClick={() => setSendReceiveModalOpen(true)}
            >
              Send/Receive
            </button>
          </div>

          {/* $FRIEND */}
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <span className="text-white font-bold text-lg">FANS</span>
            </div>
            <p className="text-white/60 text-sm mb-2">$FANS</p>
            <p className="text-xl font-bold text-white mb-4">◉ 173.01</p>
            <button 
              className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-6 py-2 rounded-full font-medium hover:from-pink-600 hover:to-purple-600 transition-colors shadow-lg"
              onClick={() => setBuySellModalOpen(true)}
            >
              Buy/Sell
            </button>
          </div>

          {/* Keys */}
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <span className="text-4xl">🗝️</span>
            </div>
            <p className="text-white/60 text-sm mb-2">Keys</p>
            <p className="text-xl font-bold text-white mb-4">$105.11</p>
            <button 
              className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-6 py-2 rounded-full font-medium hover:from-yellow-600 hover:to-orange-600 transition-colors shadow-lg"
              onClick={() => setKeyPurchaseModalOpen(true)}
            >
              Chat
            </button>
          </div>
        </div>

        {/* Farm Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Your Farm */}
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <span className="text-4xl">🏠</span>
            </div>
            <p className="text-white/60 text-sm mb-2">Your Farm</p>
            <div className="flex items-center justify-center space-x-2 mb-4">
              <span className="text-pink-400 text-xl font-bold">◉ 0</span>
              <span className="text-white/60">and</span>
              <span className="text-white text-xl font-bold">◆ 0</span>
            </div>
            <button 
              className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-2 rounded-full font-medium hover:from-green-600 hover:to-emerald-600 transition-colors shadow-lg"
              onClick={() => setFarmingModalOpen(true)}
            >
              Add/Remove
            </button>
          </div>

          {/* Farm Rewards */}
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <span className="text-4xl">🏆</span>
            </div>
            <p className="text-white/60 text-sm mb-2">Farm Rewards</p>
            <p className="text-xl font-bold text-pink-400 mb-4">◉ 0</p>
            <button 
              className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-2 rounded-full font-medium hover:from-blue-600 hover:to-cyan-600 transition-colors shadow-lg"
              onClick={() => {
                setClaimRewardType('farm');
                setClaimModalOpen(true);
              }}
            >
              Claim
            </button>
          </div>

          {/* Club Rewards */}
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <span className="text-4xl">🎁</span>
            </div>
            <p className="text-white/60 text-sm mb-2">Club Rewards</p>
            <p className="text-xl font-bold text-pink-400 mb-4">◉ 14.00645</p>
            <button 
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-2 rounded-full font-medium hover:from-purple-600 hover:to-pink-600 transition-colors shadow-lg"
              onClick={() => {
                setClaimRewardType('club');
                setClaimModalOpen(true);
              }}
            >
              Claim
            </button>
          </div>
        </div>

        {/* Enhanced Features Section */}
        <div className="border-t border-white/20 pt-8">
          <h2 className="text-xl font-semibold text-white mb-6 text-center">DeFi Tools</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Trading Widget */}
            <div 
              className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6 hover:bg-white/20 transition-all cursor-pointer shadow-lg"
              onClick={() => setTradingModalOpen(true)}
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Trading</h3>
                <p className="text-white/60 text-sm mb-4">Swap Assets Across Blockchains</p>
                <button className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-4 py-2 rounded-full text-sm font-medium hover:from-blue-600 hover:to-cyan-600 transition-colors shadow-lg">
                  Trade
                </button>
              </div>
            </div>

            {/* Staking Widget */}
            <div 
              className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6 hover:bg-white/20 transition-all cursor-pointer shadow-lg"
              onClick={() => setStakingModalOpen(true)}
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Layers className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Staking</h3>
                <p className="text-white/60 text-sm mb-4">Earn Passive Income</p>
                <button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-full text-sm font-medium hover:from-purple-600 hover:to-pink-600 transition-colors shadow-lg">
                  Staking
                </button>
              </div>
            </div>

            {/* Loans Widget */}
            <div 
              className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-6 hover:bg-white/20 transition-all cursor-pointer shadow-lg"
              onClick={() => setLoansModalOpen(true)}
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <DollarSign className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Loans</h3>
                <p className="text-white/60 text-sm mb-4">Borrow Against Your Assets</p>
                <button className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-4 py-2 rounded-full text-sm font-medium hover:from-green-600 hover:to-emerald-600 transition-colors shadow-lg">
                  Borrow
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <TradingWidgetModal 
        isOpen={tradingModalOpen} 
        onClose={() => setTradingModalOpen(false)} 
      />
      <StakingWidgetModal 
        isOpen={stakingModalOpen} 
        onClose={() => setStakingModalOpen(false)} 
      />
      <LoansWidgetModal 
        isOpen={loansModalOpen} 
        onClose={() => setLoansModalOpen(false)} 
      />
      <FarmingModal 
        isOpen={farmingModalOpen} 
        onClose={() => setFarmingModalOpen(false)} 
      />
      <SendReceiveModal 
        isOpen={sendReceiveModalOpen} 
        onClose={() => setSendReceiveModalOpen(false)} 
      />
      <BuySellModal 
        isOpen={buySellModalOpen} 
        onClose={() => setBuySellModalOpen(false)} 
      />
      <ClaimRewardsModal 
        isOpen={claimModalOpen} 
        onClose={() => setClaimModalOpen(false)} 
        rewardType={claimRewardType}
      />
      <KeyPurchaseModal 
        isOpen={keyPurchaseModalOpen} 
        onClose={() => setKeyPurchaseModalOpen(false)} 
      />
    </div>
  );
}