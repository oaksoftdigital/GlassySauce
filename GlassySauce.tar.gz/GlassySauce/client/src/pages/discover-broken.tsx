import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { EnhancedCreatorCard } from "@/components/profiles/enhanced-creator-card";
import { useQuery } from "@tanstack/react-query";
import type { Creator } from "@/types";

const filterOptions = [
  { key: "trending", label: "🔥 Trending", active: true },
  { key: "rising", label: "⭐ Rising Stars", active: false },
  { key: "high-value", label: "💎 High Value", active: false },
  { key: "vip", label: "👑 VIP", active: false },
];

export default function Discover() {
  const [activeFilter, setActiveFilter] = useState("trending");
  
  const { data: creators, isLoading } = useQuery<Creator[]>({
    queryKey: ['/api/creators', activeFilter],
  });

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Discover Creators</h1>
          <p className="text-white/60">Find and invest in your favorite creators</p>
        </div>
        
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 text-shadow">
            Discover Hot Creators
          </h2>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Find trending creators, join exclusive communities, and invest in rising stars
          </p>
        </div>
        
        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filterOptions.map((filter) => (
            <GradientButton
              key={filter.key}
              variant={activeFilter === filter.key ? "saucy" : "glass"}
              onClick={() => setActiveFilter(filter.key)}
              className={`border-2 transition-all ${
                activeFilter === filter.key 
                  ? "border-pink-500" 
                  : "border-transparent hover:border-pink-500/50"
              }`}
            >
              {filter.label}
            </GradientButton>
          ))}
        </div>
        
        {/* Creator Cards Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <GlassCard key={i} className="h-96 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {creators?.map((creator, index) => (
              <EnhancedCreatorCard key={creator.id} creator={creator} rank={index + 1} />
            ))}
          </div>
        )}
        
        {(!creators || creators.length === 0) && !isLoading && (
          <div className="text-center py-16">
            <GlassCard className="max-w-md mx-auto p-8">
              <h3 className="text-2xl font-bold text-white mb-4">No Creators Found</h3>
              <p className="text-white/70">
                No creators match your current filter. Try switching to a different category.
              </p>
            </GlassCard>
          </div>
        )}
        </div>
      </div>
    </div>
  );
}
