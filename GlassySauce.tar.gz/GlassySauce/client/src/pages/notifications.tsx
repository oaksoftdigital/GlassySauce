import { useState } from "react";
import { ArrowLeft, Heart, MessageCircle, UserPlus, DollarSign, Star, TrendingUp, Gift, Crown, Zap } from "lucide-react";
import { Link } from "wouter";

interface Notification {
  id: number;
  type: 'follow' | 'like' | 'comment' | 'purchase' | 'tip' | 'subscription' | 'message' | 'milestone' | 'token_buy' | 'exclusive_content';
  user: {
    name: string;
    username: string;
    avatar: string;
    verified: boolean;
    isCreator?: boolean;
  };
  content: string;
  timestamp: string;
  isRead: boolean;
  metadata?: {
    amount?: number;
    postImage?: string;
    tokenPrice?: number;
    milestone?: string;
  };
}

export default function Notifications() {
  const [notifications] = useState<Notification[]>([
    {
      id: 1,
      type: 'token_buy',
      user: {
        name: 'CryptoWhale88',
        username: 'cryptowhale88',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: true
      },
      content: 'purchased 50 $FANS tokens',
      timestamp: '2m',
      isRead: false,
      metadata: {
        amount: 50,
        tokenPrice: 2.45
      }
    },
    {
      id: 2,
      type: 'follow',
      user: {
        name: 'Bella Thorne',
        username: 'bellathorne',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: true,
        isCreator: true
      },
      content: 'started following you',
      timestamp: '5m',
      isRead: false
    },
    {
      id: 3,
      type: 'tip',
      user: {
        name: 'DiamondHands',
        username: 'diamondhands',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: false
      },
      content: 'sent you a tip',
      timestamp: '12m',
      isRead: false,
      metadata: {
        amount: 25
      }
    },
    {
      id: 4,
      type: 'like',
      user: {
        name: 'Amouranth',
        username: 'amouranth',
        avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: true,
        isCreator: true
      },
      content: 'liked your exclusive content',
      timestamp: '15m',
      isRead: true,
      metadata: {
        postImage: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400'
      }
    },
    {
      id: 5,
      type: 'subscription',
      user: {
        name: 'VIPFan2024',
        username: 'vipfan2024',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c64e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: false
      },
      content: 'subscribed to your VIP tier',
      timestamp: '22m',
      isRead: true,
      metadata: {
        amount: 199
      }
    },
    {
      id: 6,
      type: 'comment',
      user: {
        name: 'Tana Mongeau',
        username: 'tanamongeau',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: true,
        isCreator: true
      },
      content: 'commented on your post: "Love this content! 🔥"',
      timestamp: '35m',
      isRead: true
    },
    {
      id: 7,
      type: 'milestone',
      user: {
        name: 'Fans.tech',
        username: 'fanstech',
        avatar: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: true
      },
      content: 'You reached 10K followers! 🎉',
      timestamp: '1h',
      isRead: true,
      metadata: {
        milestone: '10K Followers'
      }
    },
    {
      id: 8,
      type: 'exclusive_content',
      user: {
        name: 'Premium_Collector',
        username: 'premium_collector',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: false
      },
      content: 'unlocked your exclusive content',
      timestamp: '2h',
      isRead: true,
      metadata: {
        amount: 75
      }
    },
    {
      id: 9,
      type: 'message',
      user: {
        name: 'Mia Khalifa',
        username: 'miakhalifa',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: true,
        isCreator: true
      },
      content: 'sent you a private message',
      timestamp: '3h',
      isRead: true
    },
    {
      id: 10,
      type: 'token_buy',
      user: {
        name: 'TokenTrader',
        username: 'tokentrader',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400',
        verified: false
      },
      content: 'bought 100 $FANS tokens',
      timestamp: '4h',
      isRead: true,
      metadata: {
        amount: 100,
        tokenPrice: 2.38
      }
    }
  ]);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'follow':
        return <UserPlus className="w-4 h-4 text-blue-500" />;
      case 'like':
        return <Heart className="w-4 h-4 text-red-500" />;
      case 'comment':
        return <MessageCircle className="w-4 h-4 text-green-500" />;
      case 'tip':
        return <DollarSign className="w-4 h-4 text-yellow-500" />;
      case 'subscription':
        return <Crown className="w-4 h-4 text-purple-500" />;
      case 'purchase':
        return <DollarSign className="w-4 h-4 text-green-500" />;
      case 'message':
        return <MessageCircle className="w-4 h-4 text-blue-500" />;
      case 'milestone':
        return <Star className="w-4 h-4 text-orange-500" />;
      case 'token_buy':
        return <TrendingUp className="w-4 h-4 text-teal-500" />;
      case 'exclusive_content':
        return <Zap className="w-4 h-4 text-pink-500" />;
      default:
        return <Heart className="w-4 h-4 text-gray-500" />;
    }
  };

  const getNotificationBadge = (user: any) => {
    if (user.isCreator) {
      return (
        <div className="w-4 h-4 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
          <Crown className="w-2.5 h-2.5 text-white" />
        </div>
      );
    }
    if (user.verified) {
      return (
        <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
          <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen glass">
      {/* Header */}
      <div className="sticky top-0 z-10 glass-light border-b border-white/10 backdrop-blur-md">
        <div className="flex items-center gap-4 p-4">
          <Link href="/" className="p-2 glass rounded-full hover:bg-white/10 transition-colors">
            <ArrowLeft className="w-5 h-5 text-white/80" />
          </Link>
          <h1 className="text-xl font-bold text-white">Notifications</h1>
        </div>
      </div>

      {/* Notifications List */}
      <div className="divide-y divide-white/5">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className={`flex items-start gap-3 p-4 hover:bg-white/5 transition-all cursor-pointer ${
              !notification.isRead ? 'bg-white/5' : ''
            }`}
          >
            {/* User Avatar with Notification Icon */}
            <div className="relative flex-shrink-0">
              <img
                src={notification.user.avatar}
                alt={notification.user.name}
                className="w-12 h-12 rounded-full object-cover"
              />
              {/* Notification Type Icon */}
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-gray-900 rounded-full flex items-center justify-center border-2 border-gray-900">
                {getNotificationIcon(notification.type)}
              </div>
            </div>

            {/* Notification Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold text-white text-sm">
                      {notification.user.name}
                    </span>
                    {getNotificationBadge(notification.user)}
                    <span className="text-white/60 text-xs">
                      @{notification.user.username}
                    </span>
                  </div>
                  
                  <p className="text-white/80 text-sm leading-relaxed">
                    {notification.content}
                  </p>

                  {/* Metadata */}
                  {notification.metadata && (
                    <div className="mt-2">
                      {notification.metadata.amount && (
                        <div className="inline-flex items-center gap-1 px-2 py-1 bg-gradient-to-r from-teal-500/20 to-purple-600/20 rounded-full">
                          <DollarSign className="w-3 h-3 text-teal-400" />
                          <span className="text-xs text-white/90 font-medium">
                            {notification.type === 'token_buy' 
                              ? `${notification.metadata.amount} $FANS`
                              : `$${notification.metadata.amount}`
                            }
                          </span>
                        </div>
                      )}
                      
                      {notification.metadata.milestone && (
                        <div className="inline-flex items-center gap-1 px-2 py-1 bg-gradient-to-r from-orange-500/20 to-pink-500/20 rounded-full">
                          <Star className="w-3 h-3 text-orange-400" />
                          <span className="text-xs text-white/90 font-medium">
                            {notification.metadata.milestone}
                          </span>
                        </div>
                      )}

                      {notification.metadata.postImage && (
                        <div className="mt-2">
                          <img
                            src={notification.metadata.postImage}
                            alt="Post"
                            className="w-16 h-16 rounded-lg object-cover"
                          />
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex flex-col items-end ml-3">
                  <span className="text-xs text-white/50 mb-1">
                    {notification.timestamp}
                  </span>
                  {!notification.isRead && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Load More */}
      <div className="p-6 text-center">
        <button className="text-white/60 hover:text-white transition-colors text-sm">
          Load more notifications
        </button>
      </div>
    </div>
  );
}