import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Send, Plus, Search, MoreHorizontal, Image, MessageCircle, Bell, X } from "lucide-react";
import { GradientButton } from "@/components/ui/gradient-button";
import { NewClubModal } from "@/components/chat/new-club-modal";
import { wsManager } from "@/lib/websocket";

interface ChatRoom {
  id: number;
  name: string;
  creatorId: number;
  memberCount: number;
  lastMessage?: string;
  lastMessageTime?: string;
  price?: number;
  avatar?: string;
}

interface ChatMessage {
  id: number;
  user: string;
  avatar: string;
  message: string;
  time: string;
  isCreator: boolean;
  reactions?: Record<string, number>;
}

export default function Chat() {
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewClubModal, setShowNewClubModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [searchTabActive, setSearchTabActive] = useState<'clubs' | 'people'>('clubs');
  const [searchInput, setSearchInput] = useState("");
  const [chatMessages, setChatMessages] = useState<Record<number, ChatMessage[]>>({});
  const [activeTab, setActiveTab] = useState<'my-room' | 'new-club'>('my-room');
  const [showNotificationBanner, setShowNotificationBanner] = useState(true);

  // Fetch chat rooms
  const { data: rooms = [] } = useQuery<ChatRoom[]>({
    queryKey: ["/api/chat/rooms"],
  });

  // Search data for clubs and people
  const searchClubs = [
    {
      id: 1,
      name: "VM CLUB",
      members: 151,
      price: 2856.1,
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      rank: 1
    },
    {
      id: 2,
      name: "Bunnilio World Order",
      members: 237,
      price: 235.6225,
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612c64e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      rank: 2
    },
    {
      id: 3,
      name: "aixbt",
      members: 2,
      price: 2220.1,
      avatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      rank: 3
    },
    {
      id: 4,
      name: "Auto Giveaways by Fr...",
      members: 36,
      price: 188.5129,
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      rank: 4
    },
    {
      id: 5,
      name: "Onchain Finance and ...",
      members: 13,
      price: 180.9025,
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      rank: 5
    }
  ];

  const searchPeople = [
    {
      id: 1,
      name: "Bella Thorne",
      username: "bellathorne",
      followers: "24.3M",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: true
    },
    {
      id: 2,
      name: "Tana Mongeau",
      username: "tanamongeau",
      followers: "5.4M",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612c64e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: true
    },
    {
      id: 3,
      name: "Amouranth",
      username: "amouranth",
      followers: "1.8M",
      avatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: true
    }
  ];

  // Enhanced rooms data matching Friend.tech style
  const enhancedRooms = [
    {
      id: 1,
      name: "VM CLUB",
      creatorId: 1,
      memberCount: 245,
      lastMessage: "💎outxider.eth🫵: Maestro co...",
      lastMessageTime: "6h",
      price: 86.10,
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      hasUnread: true
    },
    {
      id: 2,
      name: "TXICOCRYPTO", 
      creatorId: 2,
      memberCount: 189,
      lastMessage: "Crypto Nest: Comparto este hil...",
      lastMessageTime: "12h",
      price: 5.74,
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612c64e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      hasUnread: true
    },
    {
      id: 3,
      name: "$FR (FriendRock)",
      creatorId: 3, 
      memberCount: 156,
      lastMessage: "David: https://time.fun?ref=da...",
      lastMessageTime: "16h",
      price: 0.69,
      avatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      hasUnread: true
    },
    {
      id: 4,
      name: "d",
      creatorId: 4,
      memberCount: 89,
      lastMessage: "SCM: Bought a key",
      lastMessageTime: "1mo",
      price: 0.00,
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      hasUnread: false
    },
    {
      id: 5,
      name: "SCM",
      creatorId: 5,
      memberCount: 67,
      lastMessage: "Send them their first message",
      lastMessageTime: "",
      price: 0.00,
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      hasUnread: false
    }
  ];

  // Mock chat messages
  const mockMessages: Record<number, ChatMessage[]> = {
    1: [
      {
        id: 1,
        user: "outxider.eth",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        message: "Maestro continues to deliver alpha 💎",
        time: "6h",
        isCreator: true,
        reactions: { "💎": 12, "🔥": 8 }
      }
    ],
    2: [
      {
        id: 2,
        user: "Crypto Nest",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612c64e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        message: "Comparto este hilo sobre las mejores estrategias de trading",
        time: "12h",
        isCreator: true,
        reactions: { "🚀": 15, "💯": 10 }
      }
    ]
  };

  useEffect(() => {
    setChatMessages(mockMessages);
    // Don't auto-select a room - show the default interface with "My room" and "New club" buttons
  }, []);

  useEffect(() => {
    wsManager.connect();
    
    wsManager.on('newMessage', (message) => {
      setChatMessages(prev => ({
        ...prev,
        [message.roomId]: [...(prev[message.roomId] || []), message]
      }));
    });

    return () => {
      wsManager.disconnect();
    };
  }, []);

  const handleSendMessage = () => {
    if (messageInput.trim() && selectedRoom) {
      const newMessage: ChatMessage = {
        id: Date.now(),
        user: "You",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        message: messageInput,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isCreator: false
      };

      setChatMessages(prev => ({
        ...prev,
        [selectedRoom.id]: [...(prev[selectedRoom.id] || []), newMessage]
      }));

      wsManager.send('sendMessage', {
        roomId: selectedRoom.id,
        message: messageInput
      });

      setMessageInput("");
    }
  };

  const filteredRooms = enhancedRooms.filter(room =>
    room.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredSearchClubs = searchClubs.filter(club =>
    club.name.toLowerCase().includes(searchInput.toLowerCase())
  );

  const filteredSearchPeople = searchPeople.filter(person =>
    person.name.toLowerCase().includes(searchInput.toLowerCase()) ||
    person.username.toLowerCase().includes(searchInput.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col">
      {!selectedRoom ? (
        // Friend.tech Main View - No Room Selected
        <div className="flex-1 flex flex-col">
          <div className="w-full max-w-4xl mx-auto glass flex flex-col flex-1">
            {/* Top Header with Profile and Search */}
            <div className="p-4 border-b border-white/10">
              <div className="flex items-center justify-between mb-4">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
                  alt="Profile"
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div className="flex-1 mx-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
                    <input
                      type="text"
                      placeholder="Search for clubs..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onFocus={() => setShowSearchModal(true)}
                      className="w-full pl-10 pr-4 py-2.5 glass rounded-full text-sm text-white placeholder-white/40 focus:outline-none focus:ring-1 focus:ring-white/20"
                    />
                  </div>
                </div>
                <button className="p-2 glass rounded-full hover:bg-white/10 transition-colors">
                  <Bell className="w-5 h-5 text-white/60" />
                </button>
              </div>
            </div>

            {/* Tab Buttons - My room / New club */}
            <div className="p-6 border-b border-white/10">
              <div className="flex items-start justify-center gap-8">
                <div className="flex flex-col items-center">
                  <button
                    onClick={() => setActiveTab('my-room')}
                    className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                      activeTab === 'my-room' 
                        ? 'bg-blue-400 text-white' 
                        : 'bg-blue-200 text-blue-600 hover:bg-blue-300'
                    }`}
                  >
                    <MessageCircle className="w-8 h-8" />
                  </button>
                  <span className="text-sm text-white/70 mt-3 font-medium">My room</span>
                </div>
                
                <div className="flex flex-col items-center">
                  <button
                    onClick={() => {
                      setActiveTab('new-club');
                      setShowNewClubModal(true);
                    }}
                    className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                      activeTab === 'new-club' 
                        ? 'bg-blue-400 text-white' 
                        : 'bg-blue-200 text-blue-600 hover:bg-blue-300'
                    }`}
                  >
                    <Plus className="w-8 h-8" />
                  </button>
                  <span className="text-sm text-white/70 mt-3 font-medium">New club</span>
                </div>
              </div>
            </div>

            {/* Notification Banner */}
            <div className="mx-4 my-3">
              <div className="bg-blue-500 rounded-2xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="text-white">✕</div>
                  <span className="text-white text-sm">Stay up to date with friend.tech by turning on notifications</span>
                </div>
                <button className="bg-white text-blue-500 px-4 py-1.5 rounded-xl text-sm font-medium">
                  Turn on
                </button>
              </div>
            </div>

            {/* Rooms List */}
            <div className="flex-1 overflow-y-auto px-4">
              {filteredRooms.map((room) => (
                <div
                  key={room.id}
                  onClick={() => setSelectedRoom(room)}
                  className="flex items-start gap-3 p-3 cursor-pointer transition-all mb-2 hover:bg-white/5 rounded-lg"
                >
                  <div className="flex flex-col items-center">
                    <img
                      src={room.avatar}
                      alt={room.name}
                      className="w-16 h-16 rounded-lg object-cover border-2 border-white/10 bg-gray-700"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(room.name)}&background=4f46e5&color=fff&size=64`;
                      }}
                    />
                    <div className="text-xs text-white/50 mt-1 font-medium">
                      ${room.price.toFixed(2)}
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-white text-base">{room.name}</h3>
                        <p className="text-sm text-white/60 mt-1 leading-tight">
                          {room.lastMessage}
                        </p>
                      </div>
                      
                      <div className="flex flex-col items-end ml-3">
                        <span className="text-xs text-white/40 mb-1">{room.lastMessageTime}</span>
                        {room.hasUnread && (
                          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        // Chat Room View - When Room is Selected
        <div className="h-screen flex">
          {/* Chat Area */}
          <div className="flex-1 flex flex-col">
            {/* Chat Header */}
            <div className="p-4 glass border-b border-white/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setSelectedRoom(null)}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                  >
                    <div className="w-6 h-6 text-white">←</div>
                  </button>
                  <Link href={`/profile/${selectedRoom.creatorId}`}>
                    <img
                      src={selectedRoom.avatar}
                      alt={selectedRoom.name}
                      className="w-14 h-14 rounded-full object-cover cursor-pointer hover:opacity-80 border-2 border-white/10 bg-gray-700"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedRoom.name)}&background=4f46e5&color=fff&size=56`;
                      }}
                    />
                  </Link>
                  <div>
                    <h2 className="font-semibold text-white">{selectedRoom.name}</h2>
                    <p className="text-xs text-white/60">{selectedRoom.memberCount} holders</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-sm font-medium chart-gradient text-transparent bg-clip-text">
                      ${selectedRoom.price.toFixed(2)}
                    </div>
                    <div className="text-xs text-green-400">+12.5%</div>
                  </div>
                  <button className="p-2 glass rounded-lg hover:bg-white/10 transition-colors">
                    <MoreHorizontal className="w-4 h-4 text-white/60" />
                  </button>
                </div>
              </div>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {chatMessages[selectedRoom.id]?.map((message) => (
                <div key={message.id} className="flex gap-3">
                  <Link href={`/profile/${1}`}>
                    <img
                      src={message.avatar}
                      alt={message.user}
                      className="w-12 h-12 rounded-full flex-shrink-0 cursor-pointer hover:opacity-80 border-2 border-white/10 bg-gray-700"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(message.user)}&background=4f46e5&color=fff&size=48`;
                      }}
                    />
                  </Link>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Link href={`/profile/${1}`}>
                        <span className="font-medium text-sm text-white hover:underline cursor-pointer">
                          {message.user}
                        </span>
                      </Link>
                      {message.isCreator && (
                        <span className="text-xs chart-gradient px-2 py-0.5 rounded-full text-white">
                          ✓
                        </span>
                      )}
                      <span className="text-xs text-white/40">{message.time}</span>
                    </div>
                    
                    <div className="glass rounded-lg p-3 max-w-md">
                      <p className="text-sm text-white leading-relaxed">
                        {message.message}
                      </p>
                    </div>
                    
                    {message.reactions && (
                      <div className="flex gap-1 mt-2">
                        {Object.entries(message.reactions).map(([emoji, count]) => (
                          <button
                            key={emoji}
                            className="flex items-center gap-1 glass hover:bg-white/10 rounded-full px-2 py-1 text-xs text-white transition-colors"
                          >
                            <span>{emoji}</span>
                            <span className="text-white/60">{count}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <div className="p-4 glass border-t border-white/10">
              <div className="flex items-center gap-2">
                <button className="p-2 glass rounded-lg hover:bg-white/10 transition-colors">
                  <Image className="w-4 h-4 text-white/60" />
                </button>
                <div className="flex-1 relative">
                  <input
                    type="text"
                    placeholder="Send a message..."
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="w-full px-3 py-2 glass rounded-lg text-sm text-white placeholder-white/40 focus:outline-none focus:ring-1 focus:ring-white/20"
                  />
                </div>
                <GradientButton
                  onClick={handleSendMessage}
                  variant="saucy"
                  size="sm"
                  className="px-3 py-2"
                >
                  <Send className="w-4 h-4" />
                </GradientButton>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Search Modal */}
      {showSearchModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-start justify-center p-4 z-50">
          <div className="bg-white rounded-3xl w-full max-w-md mt-8 max-h-[80vh] overflow-hidden">
            {/* Search Header */}
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search for clubs..."
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                    autoFocus
                    className="w-full pl-10 pr-4 py-3 bg-gray-100 rounded-xl text-sm text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
                <button
                  onClick={() => {
                    setShowSearchModal(false);
                    setSearchInput("");
                  }}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
            </div>

            {/* Search Tabs */}
            <div className="flex border-b border-gray-200">
              <button
                onClick={() => setSearchTabActive('clubs')}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors ${
                  searchTabActive === 'clubs'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Clubs
              </button>
              <button
                onClick={() => setSearchTabActive('people')}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors ${
                  searchTabActive === 'people'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                People
              </button>
              <div className="flex-1 flex justify-end items-center pr-4">
                <button
                  onClick={() => {
                    setShowSearchModal(false);
                    setSearchInput("");
                  }}
                  className="text-gray-500 hover:text-gray-700 text-sm"
                >
                  Close
                </button>
              </div>
            </div>

            {/* Search Results */}
            <div className="flex-1 overflow-y-auto max-h-96">
              {searchTabActive === 'clubs' ? (
                <div className="p-4 space-y-3">
                  {filteredSearchClubs.map((club) => (
                    <div
                      key={club.id}
                      onClick={() => {
                        setShowSearchModal(false);
                        setSearchInput("");
                        // Handle club selection
                      }}
                      className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-xl cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-gray-400 w-4">
                            {club.rank}
                          </span>
                          <img
                            src={club.avatar}
                            alt={club.name}
                            className="w-10 h-10 rounded-lg object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 text-sm">
                            {club.name}
                          </h3>
                          <p className="text-xs text-gray-500">
                            {club.members} members • Price: {club.price.toFixed(4)} $FRIEND
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  {filteredSearchClubs.length === 0 && searchInput && (
                    <div className="text-center py-8 text-gray-500">
                      <p>No clubs found matching "{searchInput}"</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-4 space-y-3">
                  {filteredSearchPeople.map((person) => (
                    <div
                      key={person.id}
                      onClick={() => {
                        setShowSearchModal(false);
                        setSearchInput("");
                        // Handle person selection
                      }}
                      className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-xl cursor-pointer transition-colors"
                    >
                      <img
                        src={person.avatar}
                        alt={person.name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-gray-900 text-sm">
                            {person.name}
                          </h3>
                          {person.verified && (
                            <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                              <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                              </svg>
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-gray-500">
                          @{person.username} • {person.followers} followers
                        </p>
                      </div>
                    </div>
                  ))}
                  {filteredSearchPeople.length === 0 && searchInput && (
                    <div className="text-center py-8 text-gray-500">
                      <p>No people found matching "{searchInput}"</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* New Club Modal */}
      <NewClubModal 
        isOpen={showNewClubModal} 
        onClose={() => {
          setShowNewClubModal(false);
          setActiveTab('my-room');
        }} 
      />
    </div>
  );
}