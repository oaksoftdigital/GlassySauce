import { useState } from "react";
import { CampaignDashboard } from "@/components/campaigns/campaign-dashboard";
import { CampaignBuilderModal } from "@/components/campaigns/campaign-builder-modal";
import { Button } from "@/components/ui/button";
import { Target, Plus } from "lucide-react";

export default function Campaigns() {
  const [showCampaignBuilder, setShowCampaignBuilder] = useState(false);

  // Sample creators data for the campaign builder
  const sampleCreators = [
    {
      id: 1,
      name: "Bella Thorne",
      image: "https://images.unsplash.com/photo-1494790108755-2616b332446c?w=400&h=400&fit=crop",
      followers: "25M",
      engagement: "4.8%",
      platform: "Instagram",
      category: "Celebrity",
      roi: "650%",
      responseTime: "2 hours",
      priceRange: "0.5-2.0 ETH"
    },
    {
      id: 2,
      name: "Logan Paul",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
      followers: "23M",
      engagement: "6.2%",
      platform: "YouTube",
      category: "Entertainment",
      roi: "720%",
      responseTime: "4 hours",
      priceRange: "1.0-3.0 ETH"
    },
    {
      id: 3,
      name: "Charli D'Amelio",
      image: "https://images.unsplash.com/photo-1494790108755-2616b332446c?w=400&h=400&fit=crop",
      followers: "150M",
      engagement: "8.4%",
      platform: "TikTok",
      category: "Dance",
      roi: "890%",
      responseTime: "1 hour",
      priceRange: "2.0-5.0 ETH"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                Campaign Dashboard
              </h1>
              <p className="text-gray-400 mt-2">
                Monitor and manage your creator partnerships and campaigns
              </p>
            </div>
            <Button
              onClick={() => setShowCampaignBuilder(true)}
              className="bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Campaign
            </Button>
          </div>
        </div>

        {/* Campaign Dashboard */}
        <CampaignDashboard />

        {/* Campaign Builder Modal */}
        {showCampaignBuilder && (
          <CampaignBuilderModal
            isOpen={showCampaignBuilder}
            onClose={() => setShowCampaignBuilder(false)}
            availableCreators={sampleCreators}
          />
        )}
      </div>
    </div>
  );
}