import { useState } from "react";
import { Search, Filter, TrendingUp, Users, Plus } from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ClubCard } from "@/components/clubs/club-card";
import { NewClubModal } from "@/components/chat/new-club-modal";

export default function Clubs() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilter, setActiveFilter] = useState("all");
  const [showLaunchModal, setShowLaunchModal] = useState(false);

  // Mock clubs data - in real app this would come from API
  const mockClubs = [
    {
      id: 1,
      name: "VM CLUB",
      creator: "ViolentMagicClub",
      creatorId: 1,
      description: "Club Violencia Mágica",
      profileImage: "https://images.unsplash.com/photo-1494790108755-2616c0763c62?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      memberCount: 151,
      keyPrice: "0.653",
      priceChange24h: 15.2,
      totalValue: "9653.62",
      isActive: true,
      category: "entertainment"
    },
    {
      id: 2,
      name: "BELLA'S ELITE",
      creator: "BellaThorne",
      creatorId: 2,
      description: "Exclusive access to Bella's inner circle",
      profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      memberCount: 2847,
      keyPrice: "1.234",
      priceChange24h: 8.7,
      totalValue: "15420.33",
      isActive: true,
      category: "lifestyle"
    },
    {
      id: 3,
      name: "TANA'S CHAOS",
      creator: "TanaMongeau",
      creatorId: 3,
      description: "Welcome to controlled chaos",
      profileImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      memberCount: 1923,
      keyPrice: "0.987",
      priceChange24h: -3.2,
      totalValue: "8756.21",
      isActive: true,
      category: "lifestyle"
    },
    {
      id: 4,
      name: "AMOURANTH VIP",
      creator: "Amouranth",
      creatorId: 4,
      description: "Premium content and exclusive streams",
      profileImage: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      memberCount: 4521,
      keyPrice: "2.156",
      priceChange24h: 22.5,
      totalValue: "28934.44",
      isActive: true,
      category: "entertainment"
    },
    {
      id: 5,
      name: "MIA'S SANCTUARY",
      creator: "MiaKhalifa",
      creatorId: 5,
      description: "Safe space for real conversations",
      profileImage: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      memberCount: 3267,
      keyPrice: "1.789",
      priceChange24h: 12.1,
      totalValue: "19823.67",
      isActive: true,
      category: "lifestyle"
    },
    {
      id: 6,
      name: "CRYPTO QUEENS",
      creator: "CryptoEmily",
      creatorId: 6,
      description: "Alpha calls and DeFi strategies",
      profileImage: "https://images.unsplash.com/photo-1524250502761-1ac6f2e30d43?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      memberCount: 892,
      keyPrice: "3.421",
      priceChange24h: 45.3,
      totalValue: "42167.89",
      isActive: true,
      category: "crypto"
    }
  ];

  const filters = [
    { id: "all", label: "All Clubs", icon: null },
    { id: "entertainment", label: "Entertainment", icon: "🎭" },
    { id: "lifestyle", label: "Lifestyle", icon: "✨" },
    { id: "crypto", label: "Crypto", icon: "₿" },
    { id: "trending", label: "Trending", icon: "🔥" }
  ];

  const filteredClubs = mockClubs.filter(club => {
    const matchesSearch = club.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         club.creator.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = activeFilter === "all" || 
                         club.category === activeFilter ||
                         (activeFilter === "trending" && club.priceChange24h > 10);
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold gradient-text mb-2">
                Clubs
              </h1>
              <p className="text-white/70 text-lg">
                Join exclusive communities and connect with like-minded people
              </p>
            </div>
            <GradientButton 
              className="flex items-center space-x-2"
              onClick={() => setShowLaunchModal(true)}
            >
              <Plus className="w-4 h-4" />
              <span>Create Club</span>
            </GradientButton>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                placeholder="Search clubs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/5 border-white/20 text-white placeholder-white/40"
              />
            </div>
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                    activeFilter === filter.id
                      ? 'chart-gradient text-white'
                      : 'bg-white/5 text-white/70 hover:bg-white/10'
                  }`}
                >
                  {filter.icon && <span className="mr-2">{filter.icon}</span>}
                  {filter.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <GlassCard className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 chart-gradient rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">
                  {mockClubs.reduce((sum, club) => sum + club.memberCount, 0).toLocaleString()}
                </div>
                <div className="text-white/60">Total Members</div>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 chart-gradient rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">
                  {mockClubs.reduce((sum, club) => sum + parseFloat(club.totalValue), 0).toFixed(0)}K
                </div>
                <div className="text-white/60">Total Volume</div>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 chart-gradient rounded-full flex items-center justify-center">
                <Filter className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{mockClubs.length}</div>
                <div className="text-white/60">Active Clubs</div>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Club Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredClubs.map((club, index) => (
            <ClubCard key={club.id} club={club} rank={index + 1} />
          ))}
        </div>

        {filteredClubs.length === 0 && (
          <div className="text-center py-16">
            <GlassCard className="max-w-md mx-auto p-8">
              <h3 className="text-2xl font-bold text-white mb-4">No Clubs Found</h3>
              <p className="text-white/70 mb-6">
                {searchTerm ? 
                  `No clubs match "${searchTerm}". Try adjusting your search or filters.` :
                  "No clubs match your current filter. Try switching to a different category."
                }
              </p>
              <GradientButton onClick={() => { setSearchTerm(""); setActiveFilter("all"); }}>
                Clear Filters
              </GradientButton>
            </GlassCard>
          </div>
        )}
      </div>

      {/* Create Club Modal */}
      <NewClubModal 
        isOpen={showLaunchModal} 
        onClose={() => setShowLaunchModal(false)}
        title="Create Club"
        subtitle="Create your exclusive club and start monetizing your influence"
      />
    </div>
  );
}