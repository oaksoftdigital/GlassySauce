import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { FansIcon, EthereumIcon, UsdcIcon } from "@/components/ui/crypto-icons";
import { Button } from "@/components/ui/button";
import { ChevronDown, ArrowUpDown, TrendingUp, TrendingDown, Volume2, VolumeX } from "lucide-react";
import { TokenSelector, TokenDisplay } from "@/components/trading/token-selector";
import { Token, getTokenBySymbol, getPopularTokens } from "@/lib/tokens";

export default function Trading() {
  // Initialize with default tokens
  const [baseToken, setBaseToken] = useState<Token | undefined>(getTokenBySymbol('FANS', 1));
  const [quoteToken, setQuoteToken] = useState<Token | undefined>(getTokenBySymbol('ETH', 1));
  const [buySellMode, setBuySellMode] = useState<"buy" | "sell">("buy");
  const [amount, setAmount] = useState("");
  const [quoteAmount, setQuoteAmount] = useState("");
  const [showTokenSelector, setShowTokenSelector] = useState(false);
  const [selectingToken, setSelectingToken] = useState<'base' | 'quote' | null>(null);
  const [selectedChain, setSelectedChain] = useState(1); // Default to Ethereum

  const handleTokenSelect = (token: Token, type: 'base' | 'quote') => {
    if (type === 'base') {
      setBaseToken(token);
    } else {
      setQuoteToken(token);
    }
    setShowTokenSelector(false);
    setSelectingToken(null);
  };

  const openTokenSelector = (type: 'base' | 'quote') => {
    setSelectingToken(type);
    setShowTokenSelector(true);
  };

  const swapTokens = () => {
    const temp = baseToken;
    setBaseToken(quoteToken);
    setQuoteToken(temp);
    setAmount('');
    setQuoteAmount('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-white mb-4 tracking-wider">
            TRADE
          </h1>
          <p className="text-white/60 text-lg">
            Trade creator tokens with professional-grade tools
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Main Chart Section */}
        <div className="xl:col-span-2">
          <GlassCard className="h-[600px] p-6">
            {/* Chart Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 cursor-pointer hover:bg-white/5 px-3 py-2 rounded-lg transition-colors">
                  {baseToken && (
                    <img src={baseToken.logoURI} alt={baseToken.symbol} className="w-6 h-6 rounded-full" />
                  )}
                  <span className="text-white font-bold">${baseToken?.symbol || 'FANS'}</span>
                  <span className="text-white/60">/</span>
                  {quoteToken && (
                    <img src={quoteToken.logoURI} alt={quoteToken.symbol} className="w-5 h-5 rounded-full" />
                  )}
                  <span className="text-white/60">{quoteToken?.symbol || 'ETH'}</span>
                  <ChevronDown className="w-4 h-4 text-white/40" />
                </div>
                
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-green-400 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    +12.5%
                  </span>
                  <span className="text-white/60">24h: $4,200.00</span>
                  <span className="text-white/60">Vol: $1.2M</span>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" className="text-white/60">
                  1m
                </Button>
                <Button variant="ghost" size="sm" className="text-white/60">
                  5m
                </Button>
                <Button variant="ghost" size="sm" className="text-white/60">
                  1h
                </Button>
                <Button variant="ghost" size="sm" className="bg-blue-500/20 text-blue-400">
                  4h
                </Button>
                <Button variant="ghost" size="sm" className="text-white/60">
                  1d
                </Button>
              </div>
            </div>

            {/* Trading Chart */}
            <div className="h-[480px] bg-gray-900/50 rounded-lg p-4 relative overflow-hidden">
              <svg width="100%" height="100%" viewBox="0 0 800 400" className="absolute inset-0">
                <defs>
                  <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" style={{stopColor: '#10b981', stopOpacity: 0.3}} />
                    <stop offset="100%" style={{stopColor: '#10b981', stopOpacity: 0.05}} />
                  </linearGradient>
                </defs>
                
                {/* Grid Lines */}
                {[...Array(10)].map((_, i) => (
                  <line
                    key={`v-${i}`}
                    x1={80 + (i * 64)}
                    y1="20"
                    x2={80 + (i * 64)}
                    y2="360"
                    stroke="rgba(255,255,255,0.1)"
                    strokeWidth="1"
                  />
                ))}
                {[...Array(8)].map((_, i) => (
                  <line
                    key={`h-${i}`}
                    x1="80"
                    y1={40 + (i * 40)}
                    x2="720"
                    y2={40 + (i * 40)}
                    stroke="rgba(255,255,255,0.1)"
                    strokeWidth="1"
                  />
                ))}

                {/* Price Chart Line */}
                <path 
                  d="M80,300 L144,280 L208,260 L272,240 L336,220 L400,200 L464,180 L528,160 L592,140 L656,120 L720,100"
                  stroke="#10b981" 
                  strokeWidth="3" 
                  fill="none"
                />
                
                {/* Chart Fill */}
                <path 
                  d="M80,300 L144,280 L208,260 L272,240 L336,220 L400,200 L464,180 L528,160 L592,140 L656,120 L720,100 L720,360 L80,360 Z"
                  fill="url(#chartGradient)"
                />

                {/* Volume Bars */}
                {[...Array(20)].map((_, i) => (
                  <rect
                    key={i}
                    x={80 + (i * 32)}
                    y={340 - (Math.random() * 40)}
                    width="8"
                    height={Math.random() * 40}
                    fill="rgba(16, 185, 129, 0.3)"
                  />
                ))}

                {/* Price Labels */}
                {[4300, 4250, 4200, 4150, 4100, 4050, 4000, 3950].map((price, i) => (
                  <text
                    key={price}
                    x="70"
                    y={45 + (i * 40)}
                    fill="rgba(255,255,255,0.6)"
                    fontSize="12"
                    textAnchor="end"
                  >
                    ${price}
                  </text>
                ))}

                {/* Current Price Indicator */}
                <circle cx="720" cy="100" r="4" fill="#10b981" />
                <line x1="720" y1="100" x2="760" y2="100" stroke="#10b981" strokeWidth="2" />
                <text x="765" y="105" fill="#10b981" fontSize="14" fontWeight="bold">
                  $4,320.00
                </text>
              </svg>
            </div>
          </GlassCard>
        </div>

        {/* Trading Panel */}
        <div className="space-y-6">
          {/* Exchange Panel */}
          <GlassCard className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">Exchange Crypto</h3>
              <div className="flex rounded-lg bg-gray-800/50 p-1">
                <button
                  onClick={() => setBuySellMode("buy")}
                  className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                    buySellMode === "buy"
                      ? "bg-green-500 text-white"
                      : "text-white/60 hover:text-white"
                  }`}
                >
                  Buy / Sell Crypto
                </button>
              </div>
            </div>

            <div className="space-y-4">
              {/* You Send */}
              <div>
                <label className="block text-white/60 text-sm mb-2">You send</label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="0.3"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-gray-800/50 border border-white/10 rounded-lg px-4 py-3 text-white pr-32"
                  />
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                    <TokenDisplay
                      token={quoteToken}
                      onClick={() => openTokenSelector('quote')}
                      showBalance={false}
                      showChain={true}
                    />
                  </div>
                </div>
                <div className="flex justify-between text-sm text-white/60 mt-1">
                  <span>Balance: 0.00 {quoteToken?.symbol}</span>
                  <span className="text-green-400">✓ Best rate</span>
                </div>
              </div>

              {/* Swap Button */}
              <div className="flex justify-center">
                <button 
                  onClick={swapTokens}
                  className="p-2 bg-gray-800/50 rounded-lg hover:bg-gray-700/50 transition-colors"
                >
                  <ArrowUpDown className="w-5 h-5 text-white/60" />
                </button>
              </div>

              {/* You Get */}
              <div>
                <label className="block text-white/60 text-sm mb-2">You get</label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="0"
                    value={quoteAmount}
                    onChange={(e) => setQuoteAmount(e.target.value)}
                    className="w-full bg-gray-800/50 border border-white/10 rounded-lg px-4 py-3 text-white pr-32"
                  />
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                    <TokenDisplay
                      token={baseToken}
                      onClick={() => openTokenSelector('base')}
                      showBalance={false}
                      showChain={true}
                    />
                  </div>
                </div>
                <div className="flex justify-between text-sm text-white/60 mt-1">
                  <span>Balance: 0.00 {baseToken?.symbol}</span>
                  <span className="text-white/40">Cross-chain bridge</span>
                </div>
              </div>

              {/* Exchange Button */}
              <Button className="w-full chart-gradient text-white font-semibold py-4 hover:opacity-90 shadow-lg hover:shadow-xl transition-all duration-300">
                Execute Trade
              </Button>
            </div>
          </GlassCard>

          {/* Trading Stats */}
          <GlassCard className="p-6">
            <h3 className="text-white font-semibold mb-4">Market Stats</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-white/60">24h Volume</span>
                <span className="text-white font-medium">$1.96M</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Market Cap</span>
                <span className="text-white font-medium">$10.05B</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Total Supply</span>
                <span className="text-white font-medium">1B $FANS</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Circulating</span>
                <span className="text-white font-medium">850M $FANS</span>
              </div>
            </div>
          </GlassCard>
        </div>
      </div>

      {/* Bottom Stats */}
      <div className="max-w-7xl mx-auto mt-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">1.96</div>
            <div className="text-white/60 text-sm">Seconds</div>
            <div className="text-white/40 text-xs">Median settlement time</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">$ 10.05</div>
            <div className="text-white/60 text-sm">Billion</div>
            <div className="text-white/40 text-xs">Volume settled</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">4</div>
            <div className="text-white/60 text-sm">Hours</div>
            <div className="text-white/40 text-xs">Lowest spread</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">100%</div>
            <div className="text-white/60 text-sm">Uptime since launch</div>
            <div className="text-white/40 text-xs">Since launch</div>
          </div>
        </div>
      </div>

      {/* Token Selector Modal */}
      {showTokenSelector && selectingToken && (
        <TokenSelector
          selectedToken={selectingToken === 'base' ? baseToken : quoteToken}
          onTokenSelect={(token) => handleTokenSelect(token, selectingToken)}
          onClose={() => {
            setShowTokenSelector(false);
            setSelectingToken(null);
          }}
          chainId={selectedChain}
          excludeTokens={
            selectingToken === 'base' 
              ? quoteToken ? [quoteToken.address] : []
              : baseToken ? [baseToken.address] : []
          }
        />
      )}
    </div>
  );
}
