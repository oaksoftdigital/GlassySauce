import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Search, Bell, MessageCircle, Plus, MoreHorizontal, Image, Send } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { wsManager } from "@/lib/websocket";
import { NewClubModal } from "@/components/chat/new-club-modal";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import type { ChatRoom, ChatMessage } from "@/types";

// Mock chat messages for individual rooms
const chatMessages: Record<number, Array<{
  id: number;
  user: string;
  avatar: string;
  message: string;
  time: string;
  isCreator: boolean;
  reactions?: Record<string, number>;
}>> = {
  1: [
    {
      id: 1,
      user: "Bella Thorne",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      message: "Hey everyone! Just dropped some exclusive content in my private gallery 💋",
      time: "2m",
      isCreator: true,
      reactions: { "🔥": 23, "💕": 45, "😍": 12 }
    },
    {
      id: 2,
      user: "CryptoFan",
      avatar: "https://i.pravatar.cc/40?img=1",
      message: "Your latest photoshoot was amazing! When are you releasing more behind-the-scenes content?",
      time: "5m",
      isCreator: false,
      reactions: { "👍": 8 }
    },
    {
      id: 3,
      user: "Bella Thorne",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      message: "Soon! I'm working on something special for my top holders 🎬✨",
      time: "3m",
      isCreator: true,
      reactions: { "🚀": 15, "💎": 9 }
    }
  ],
  2: [
    {
      id: 4,
      user: "Tana Mongeau",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612c64e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      message: "Chaos update: Just bought a new Tesla with my token earnings! 🚗💨",
      time: "10m",
      isCreator: true,
      reactions: { "🔥": 67, "💰": 23 }
    }
  ]
};

export default function ChatNew() {
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewClubModal, setShowNewClubModal] = useState(false);

  const { data: rooms, isLoading } = useQuery<ChatRoom[]>({
    queryKey: ['/api/chat/rooms'],
  });

  // Connect to WebSocket when component mounts
  useEffect(() => {
    wsManager.connect();
    
    wsManager.on('chat_message', (data) => {
      console.log('Received message:', data);
    });

    return () => {
      wsManager.disconnect();
    };
  }, []);

  // Set default selected room
  useEffect(() => {
    if (rooms && rooms.length > 0 && !selectedRoom) {
      setSelectedRoom(rooms[0]);
    }
  }, [rooms, selectedRoom]);

  const handleSendMessage = () => {
    if (messageInput.trim() && selectedRoom) {
      wsManager.send('chat_message', {
        roomId: selectedRoom.id,
        message: messageInput.trim(),
        userId: 1 // Current user ID
      });
      console.log("Sending message:", messageInput);
      setMessageInput("");
    }
  };

  const filteredRooms = rooms?.filter(room =>
    room.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  if (isLoading) {
    return (
      <div className="min-h-screen dark-gradient flex items-center justify-center">
        <div className="text-white text-lg">Loading chat rooms...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen dark-gradient">
      <div className="h-screen flex">
        {/* Chat Rooms Sidebar - Made bigger for easier use */}
        <div className="w-96 glass border-r border-white/10 flex flex-col">
          {/* Header - Bigger spacing */}
          <div className="p-8 border-b border-white/10">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-bold text-white">My Chats</h1>
              <button
                onClick={() => setShowNewClubModal(true)}
                className="p-4 glass rounded-2xl hover:bg-white/10 transition-colors"
              >
                <Plus className="w-6 h-6 text-white" />
              </button>
            </div>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/60" />
              <input
                type="text"
                placeholder="Search chats..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 glass rounded-2xl text-lg text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/20"
              />
            </div>
          </div>

          {/* Chat Rooms List - Much bigger for easier touch */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {filteredRooms.map((room) => (
              <div
                key={room.id}
                onClick={() => setSelectedRoom(room)}
                className={`p-6 rounded-2xl cursor-pointer transition-all ${
                  selectedRoom?.id === room.id
                    ? 'chart-gradient text-white shadow-lg'
                    : 'glass hover:bg-white/10 text-white/90'
                }`}
              >
                <div className="flex items-center gap-4">
                  {/* Much bigger profile picture with realistic OnlyFans model image */}
                  <div className="relative">
                    <img
                      src={room.name === "Bella's VIP Club" 
                        ? "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" 
                        : room.name === "Tana's Chaos Corner"
                        ? "https://images.unsplash.com/photo-1494790108755-2616b612c64e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
                        : "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"}
                      alt={room.name}
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-white/20"
                    />
                    {/* Online indicator */}
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-400 rounded-full border-2 border-black"></div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-lg truncate">{room.name}</div>
                    <div className="text-sm opacity-70 truncate">{room.description}</div>
                    <div className="text-sm opacity-60 mt-1 font-medium">
                      {room.memberCount} members • $FANS tokens
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {selectedRoom ? (
            <>
              {/* Chat Header - Bigger and more prominent */}
              <div className="p-8 glass border-b border-white/10">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <img
                      src={selectedRoom.name === "Bella's VIP Club" 
                        ? "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" 
                        : selectedRoom.name === "Tana's Chaos Corner"
                        ? "https://images.unsplash.com/photo-1494790108755-2616b612c64e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
                        : "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"}
                      alt={selectedRoom.name}
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-white/20"
                    />
                    <div>
                      <h2 className="font-bold text-white text-2xl">{selectedRoom.name}</h2>
                      <p className="text-lg text-white/60">{selectedRoom.memberCount} members • $FANS tokens</p>
                    </div>
                  </div>
                  <button className="p-3 glass rounded-2xl hover:bg-white/10 transition-colors">
                    <MoreHorizontal className="w-6 h-6 text-white/60" />
                  </button>
                </div>
                
                {/* Price Chart - Bigger */}
                <div className="mt-6 h-24 glass rounded-2xl p-4">
                  <svg width="100%" height="100%" viewBox="0 0 280 60" className="overflow-visible">
                    <defs>
                      <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" style={{stopColor: '#14b8a6', stopOpacity: 0.3}} />
                        <stop offset="100%" style={{stopColor: '#14b8a6', stopOpacity: 0.1}} />
                      </linearGradient>
                    </defs>
                    <path 
                      d="M10,45 L40,42 L70,38 L100,35 L130,32 L160,28 L190,25 L220,22 L250,18 L270,15"
                      stroke="#14b8a6" 
                      strokeWidth="3" 
                      fill="none"
                    />
                    <path 
                      d="M10,45 L40,42 L70,38 L100,35 L130,32 L160,28 L190,25 L220,22 L250,18 L270,15 L270,60 L10,60 Z"
                      fill="url(#chartGradient)"
                    />
                    <circle cx="270" cy="15" r="4" fill="#14b8a6" />
                  </svg>
                </div>
              </div>

              {/* Chat Messages - Much bigger and easier to read */}
              <div className="flex-1 overflow-y-auto p-8 space-y-6">
                {chatMessages[selectedRoom.id]?.map((message) => (
                  <div key={message.id} className="flex gap-5">
                    <Link href={`/profile/${1}`}>
                      <img
                        src={message.avatar}
                        alt={message.user}
                        className="w-14 h-14 rounded-2xl flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity border-2 border-white/20"
                      />
                    </Link>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <Link href={`/profile/${1}`} className="hover:underline">
                          <span className="font-semibold text-lg text-white cursor-pointer">
                            {message.user}
                          </span>
                        </Link>
                        {message.isCreator && (
                          <span className="text-sm chart-gradient px-3 py-1 rounded-full text-white font-medium">
                            ✅ Creator
                          </span>
                        )}
                        <span className="text-sm text-white/60 font-medium">{message.time}</span>
                      </div>
                      
                      <div className="glass rounded-2xl p-6 max-w-2xl">
                        <p className="text-lg text-white whitespace-pre-line leading-relaxed">
                          {message.message}
                        </p>
                      </div>
                      
                      {message.reactions && (
                        <div className="flex gap-3 mt-4">
                          {Object.entries(message.reactions).map(([emoji, count]) => (
                            <button
                              key={emoji}
                              className="flex items-center gap-2 glass hover:bg-white/10 rounded-2xl px-4 py-2 text-sm text-white transition-colors"
                            >
                              <span className="text-lg">{emoji}</span>
                              <span className="text-white/70 font-medium">{count}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Message Input - Much bigger and easier to use */}
              <div className="p-8 glass border-t border-white/10">
                <div className="flex items-center gap-4">
                  <button className="p-4 glass rounded-2xl hover:bg-white/10 transition-colors">
                    <Image className="w-6 h-6 text-white/60" />
                  </button>
                  <div className="flex-1 relative">
                    <input
                      type="text"
                      placeholder="Share something with your fans..."
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      className="w-full px-6 py-4 glass rounded-2xl text-lg text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/20"
                    />
                  </div>
                  <GradientButton
                    onClick={handleSendMessage}
                    variant="saucy"
                    size="lg"
                    className="px-6 py-4 text-lg"
                  >
                    <Send className="w-5 h-5" />
                  </GradientButton>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center text-white/60">
                <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium mb-2">Select a chat room</h3>
                <p className="text-sm">Choose a room from the sidebar to start chatting</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* New Club Modal */}
      <NewClubModal 
        isOpen={showNewClubModal} 
        onClose={() => setShowNewClubModal(false)} 
      />
    </div>
  );
}