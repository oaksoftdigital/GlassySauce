import { useState, useEffect } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { useQuery } from "@tanstack/react-query";
import { 
  Wallet, 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  Eye, 
  Copy, 
  ExternalLink,
  Star,
  BarChart3,
  Activity,
  Target,
  Users,
  Shield,
  Zap
} from "lucide-react";

// Mock wallet data
const mockWallets = [
  {
    id: 1,
    address: "0x742d35Cc6634C0532925a3b8D4D8B3f4c3E6B8A2",
    name: "Main Wallet",
    network: "Ethereum",
    balance: "$45,234.56",
    tokens: [
      { symbol: "ETH", amount: "12.5", value: "$24,500", change: "+3.2%" },
      { symbol: "USDC", amount: "8,234", value: "$8,234", change: "+0.1%" },
      { symbol: "BELLA", amount: "5,000", value: "$12,500", change: "+15.4%" }
    ],
    nfts: 23,
    transactions: 1247,
    isConnected: true
  },
  {
    id: 2,
    address: "0x8B7C9E2A1F6D4E3C5B8A9F2E4D7C1A6B5E8F3A9D",
    name: "Trading Wallet",
    network: "PulseChain",
    balance: "$18,923.45",
    tokens: [
      { symbol: "PLS", amount: "45,000", value: "$13,500", change: "+8.7%" },
      { symbol: "PLSX", amount: "12,000", value: "$3,600", change: "+12.3%" },
      { symbol: "HEX", amount: "8,500", value: "$1,823", change: "-2.1%" }
    ],
    nfts: 7,
    transactions: 892,
    isConnected: true
  }
];

const mockPredictions = [
  {
    id: 1,
    market: "BTC/USD",
    prediction: "Bullish",
    target: "$85,000",
    confidence: "High",
    timeframe: "30 days",
    status: "Active"
  },
  {
    id: 2,
    market: "ETH/USD",
    prediction: "Bullish",
    target: "$4,200",
    confidence: "Medium",
    timeframe: "14 days",
    status: "Active"
  }
];

const mockRecentActivity = [
  {
    id: 1,
    type: "Trade",
    action: "Bought 500 BELLA tokens",
    amount: "$1,250",
    time: "2h ago",
    network: "Ethereum"
  },
  {
    id: 2,
    type: "Prediction",
    action: "Made BTC prediction",
    amount: "Target: $85k",
    time: "4h ago",
    network: "Global"
  },
  {
    id: 3,
    type: "Social",
    action: "Connected with @cryptowhale",
    amount: "New Connection",
    time: "1d ago",
    network: "Fans.tech"
  }
];

export default function WalletTracker() {
  const [activeTab, setActiveTab] = useState("overview");
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [walletAddress, setWalletAddress] = useState("");

  const { data: portfolioData } = useQuery({
    queryKey: ['/api/wallet/portfolio'],
  });

  const totalValue = mockWallets.reduce((sum, wallet) => {
    return sum + parseFloat(wallet.balance.replace(/[$,]/g, ''));
  }, 0);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const shortenAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Wallet Tracker</h1>
              <p className="text-white/60">
                Connect your wallets to track portfolio, build Web3 identity, and enhance trading
              </p>
            </div>
            <GradientButton 
              variant="saucy" 
              onClick={() => setShowConnectModal(true)}
              className="flex items-center space-x-2"
            >
              <Plus className="w-5 h-5" />
              <span>Connect Wallet</span>
            </GradientButton>
          </div>

          {/* Portfolio Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <GlassCard className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                  <Wallet className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">
                    {formatCurrency(totalValue)}
                  </div>
                  <div className="text-white/60 text-sm">Total Portfolio</div>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">+12.4%</div>
                  <div className="text-white/60 text-sm">24h Change</div>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-500/20 rounded-xl flex items-center justify-center">
                  <Target className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">{mockPredictions.length}</div>
                  <div className="text-white/60 text-sm">Active Predictions</div>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-orange-500/20 rounded-xl flex items-center justify-center">
                  <Users className="w-5 h-5 text-orange-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">127</div>
                  <div className="text-white/60 text-sm">Connections</div>
                </div>
              </div>
            </GlassCard>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="mb-6">
          <div className="flex items-center space-x-6">
            {['overview', 'wallets', 'predictions', 'activity', 'identity'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg font-medium transition-all capitalize ${
                  activeTab === tab
                    ? 'bg-blue-500/20 text-blue-400'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <GlassCard className="p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Portfolio Performance</h3>
                  <div className="h-64 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-lg flex items-center justify-center">
                    <div className="text-white/60">Portfolio chart visualization</div>
                  </div>
                </GlassCard>

                <GlassCard className="p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Top Holdings</h3>
                  <div className="space-y-3">
                    {mockWallets[0].tokens.map((token, index) => (
                      <div key={index} className="flex items-center justify-between p-3 glass rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-xs font-bold">{token.symbol.slice(0, 2)}</span>
                          </div>
                          <div>
                            <div className="text-white font-medium">{token.symbol}</div>
                            <div className="text-white/60 text-sm">{token.amount}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-white font-medium">{token.value}</div>
                          <div className={`text-sm ${token.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                            {token.change}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </div>
            )}

            {activeTab === 'wallets' && (
              <div className="space-y-4">
                {mockWallets.map((wallet) => (
                  <GlassCard key={wallet.id} className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                          <Wallet className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="text-white font-medium">{wallet.name}</div>
                          <div className="text-white/60 text-sm">{wallet.network}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-bold text-lg">{wallet.balance}</div>
                        <div className="text-green-400 text-sm">Connected</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 mb-4">
                      <code className="text-white/60 text-sm">{shortenAddress(wallet.address)}</code>
                      <button 
                        onClick={() => copyToClipboard(wallet.address)}
                        className="text-blue-400 hover:text-blue-300"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button className="text-blue-400 hover:text-blue-300">
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-white font-medium">{wallet.tokens.length}</div>
                        <div className="text-white/60 text-sm">Tokens</div>
                      </div>
                      <div className="text-center">
                        <div className="text-white font-medium">{wallet.nfts}</div>
                        <div className="text-white/60 text-sm">NFTs</div>
                      </div>
                      <div className="text-center">
                        <div className="text-white font-medium">{wallet.transactions}</div>
                        <div className="text-white/60 text-sm">Transactions</div>
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}

            {activeTab === 'predictions' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-white">Market Predictions</h3>
                  <GradientButton size="sm" variant="glass">
                    <Plus className="w-4 h-4 mr-2" />
                    New Prediction
                  </GradientButton>
                </div>
                
                {mockPredictions.map((prediction) => (
                  <GlassCard key={prediction.id} className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                          <Target className="w-5 h-5 text-green-400" />
                        </div>
                        <div>
                          <div className="text-white font-medium">{prediction.market}</div>
                          <div className="text-white/60 text-sm">{prediction.prediction} - {prediction.timeframe}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-bold">{prediction.target}</div>
                        <div className="text-green-400 text-sm">{prediction.confidence} Confidence</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-white/60 text-sm">Status: {prediction.status}</div>
                      <div className="flex items-center space-x-2">
                        <button className="text-blue-400 hover:text-blue-300">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="text-yellow-400 hover:text-yellow-300">
                          <Star className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}

            {activeTab === 'activity' && (
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white">Recent Activity</h3>
                {mockRecentActivity.map((activity) => (
                  <GlassCard key={activity.id} className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                        <Activity className="w-5 h-5 text-blue-400" />
                      </div>
                      <div className="flex-1">
                        <div className="text-white font-medium">{activity.action}</div>
                        <div className="text-white/60 text-sm">{activity.network} • {activity.time}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-medium">{activity.amount}</div>
                        <div className="text-white/60 text-sm capitalize">{activity.type}</div>
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}

            {activeTab === 'identity' && (
              <div className="space-y-6">
                <GlassCard className="p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Web3 Identity</h3>
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                      <Shield className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <div className="text-white font-bold text-lg">Crypto Trader</div>
                      <div className="text-white/60">Level 3 • 127 Connections</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 glass rounded-lg">
                      <div className="text-white font-bold text-xl">94%</div>
                      <div className="text-white/60 text-sm">Success Rate</div>
                    </div>
                    <div className="text-center p-4 glass rounded-lg">
                      <div className="text-white font-bold text-xl">$64K</div>
                      <div className="text-white/60 text-sm">Total Volume</div>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard className="p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Achievements</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-3 p-3 glass rounded-lg">
                      <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center">
                        <Star className="w-4 h-4 text-yellow-400" />
                      </div>
                      <div>
                        <div className="text-white font-medium">Top Trader</div>
                        <div className="text-white/60 text-sm">This month</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-3 glass rounded-lg">
                      <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center">
                        <Zap className="w-4 h-4 text-green-400" />
                      </div>
                      <div>
                        <div className="text-white font-medium">Early Adopter</div>
                        <div className="text-white/60 text-sm">Platform Pioneer</div>
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              <GlassCard className="p-4">
                <h3 className="text-white font-semibold mb-3">Quick Actions</h3>
                <div className="space-y-2">
                  <GradientButton size="sm" variant="glass" className="w-full">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    View Analytics
                  </GradientButton>
                  <GradientButton size="sm" variant="glass" className="w-full">
                    <Target className="w-4 h-4 mr-2" />
                    Make Prediction
                  </GradientButton>
                  <GradientButton size="sm" variant="glass" className="w-full">
                    <Users className="w-4 h-4 mr-2" />
                    Find Traders
                  </GradientButton>
                </div>
              </GlassCard>

              <GlassCard className="p-4">
                <h3 className="text-white font-semibold mb-3">Connected Networks</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-white/60 text-sm">Ethereum</span>
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/60 text-sm">PulseChain</span>
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/60 text-sm">Polygon</span>
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                  </div>
                </div>
              </GlassCard>
            </div>
          </div>
        </div>
      </div>

      {/* Connect Wallet Modal */}
      {showConnectModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="glass rounded-xl p-6 max-w-md w-full mx-4">
            <h3 className="text-xl font-bold text-white mb-4">Connect Wallet</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-white/60 text-sm mb-2">Wallet Address</label>
                <input
                  type="text"
                  value={walletAddress}
                  onChange={(e) => setWalletAddress(e.target.value)}
                  placeholder="0x..."
                  className="w-full px-4 py-2 glass rounded-lg text-white placeholder-white/40 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-white/60 text-sm mb-2">Network</label>
                <select className="w-full px-4 py-2 glass rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-blue-500">
                  <option value="ethereum">Ethereum</option>
                  <option value="pulsechain">PulseChain</option>
                  <option value="polygon">Polygon</option>
                  <option value="bsc">BSC</option>
                </select>
              </div>
              <div className="flex items-center space-x-3">
                <GradientButton 
                  variant="saucy" 
                  onClick={() => setShowConnectModal(false)}
                  className="flex-1"
                >
                  Connect
                </GradientButton>
                <GradientButton 
                  variant="glass" 
                  onClick={() => setShowConnectModal(false)}
                  className="flex-1"
                >
                  Cancel
                </GradientButton>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}