import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Users, Calendar, ShoppingBag, Filter, Search, Trophy, TrendingUp, Target, CheckCircle, Zap, Shield, CreditCard } from "lucide-react";
import { CreateCampaignModal } from "@/components/campaigns/create-campaign-modal";
import { NewClubModal } from "@/components/chat/new-club-modal";
import { ReviewModal } from "@/components/events/review-modal";
import BookCallModal from "@/components/campaigns/book-call-modal";
import { CampaignBuilderModal } from "@/components/campaigns/campaign-builder-modal";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Alpha() {
  const [activeTab, setActiveTab] = useState<"leaderboard" | "events" | "dao">("leaderboard");
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [showReview, setShowReview] = useState(false);
  const [showPartnership, setShowPartnership] = useState(false);
  const [showBookCall, setShowBookCall] = useState(false);
  const [showCampaignBuilder, setShowCampaignBuilder] = useState(false);
  const [selectedHost, setSelectedHost] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [platformFilter, setPlatformFilter] = useState("all");
  const [followersFilter, setFollowersFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [engagementFilter, setEngagementFilter] = useState("all");
  const [responseTimeFilter, setResponseTimeFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");

  // Sample hosts data with top-tier content creators
  const hosts = [
    {
      id: 1,
      name: "Bella Thorne",
      username: "@bellathorne",
      bio: "Actress • OnlyFans Pioneer • 24M Instagram Followers",
      image: "https://images.unsplash.com/photo-1494790108755-2616b332446c?w=100&h=100&fit=crop",
      followers: "24.8M",
      posts: "8.2K",
      holders: "1.2K",
      rating: 4.7,
      categories: ["Entertainment", "Fashion", "Lifestyle"],
      verified: true,
      platform: "OnlyFans",
      engagementRate: "4.2%",
      responseTime: "< 24h",
      averageROI: "340%"
    },
    {
      id: 2,
      name: "Mia Khalifa",
      username: "@miakhalifa",
      bio: "Sports Commentator • OnlyFans Creator • 27M Instagram",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
      followers: "27.1M",
      posts: "4.8K",
      holders: "892",
      rating: 4.5,
      categories: ["Sports", "Entertainment", "Commentary"],
      verified: true,
      platform: "OnlyFans",
      engagementRate: "3.8%",
      responseTime: "< 12h",
      averageROI: "420%"
    },
    {
      id: 3,
      name: "Charli D'Amelio",
      username: "@charlidamelio",
      bio: "TikTok Queen • 150M Followers • Gen Z Voice",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
      followers: "150.2M",
      posts: "2.1K",
      holders: "2.8K",
      rating: 4.9,
      categories: ["Dance", "Entertainment", "Youth"],
      verified: true,
      platform: "TikTok",
      engagementRate: "8.7%",
      responseTime: "< 6h",
      averageROI: "680%"
    },
    {
      id: 4,
      name: "Addison Rae",
      username: "@addisonre",
      bio: "TikTok Star • 88M Followers • Brand Ambassador",
      image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop",
      followers: "88.7M",
      posts: "1.9K",
      holders: "1.9K",
      rating: 4.6,
      categories: ["Dance", "Beauty", "Lifestyle"],
      verified: true,
      platform: "TikTok",
      engagementRate: "6.4%",
      responseTime: "< 8h",
      averageROI: "520%"
    },
    {
      id: 5,
      name: "Tana Mongeau",
      username: "@tanamongeau",
      bio: "YouTuber • OnlyFans Creator • Controversial Content",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
      followers: "5.4M",
      posts: "12.3K",
      holders: "654",
      rating: 4.3,
      categories: ["Entertainment", "Controversy", "Lifestyle"],
      verified: true,
      platform: "OnlyFans",
      engagementRate: "7.2%",
      responseTime: "< 4h",
      averageROI: "380%"
    },
    {
      id: 6,
      name: "Amouranth",
      username: "@amouranth",
      bio: "Twitch Streamer • OnlyFans Top Creator • Business Mogul",
      image: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=100&h=100&fit=crop",
      followers: "6.2M",
      posts: "15.7K",
      holders: "987",
      rating: 4.4,
      categories: ["Gaming", "Entertainment", "Business"],
      verified: true,
      platform: "OnlyFans",
      engagementRate: "5.9%",
      responseTime: "< 3h",
      averageROI: "450%"
    },
    {
      id: 7,
      name: "Logan Paul",
      username: "@loganpaul",
      bio: "YouTuber • Boxer • Entrepreneur • 23M YouTube Subscribers",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
      followers: "23.6M",
      posts: "2.1K",
      holders: "1.5K",
      rating: 4.6,
      categories: ["Entertainment", "Sports", "Business"],
      verified: true,
      platform: "YouTube",
      engagementRate: "8.4%",
      responseTime: "< 6h",
      averageROI: "520%"
    },
    {
      id: 8,
      name: "Jake Paul",
      username: "@jakepaul",
      bio: "YouTuber • Boxer • Team 1000 • 20M YouTube Subscribers",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
      followers: "20.4M",
      posts: "1.8K",
      holders: "1.2K",
      rating: 4.4,
      categories: ["Entertainment", "Sports", "Lifestyle"],
      verified: true,
      platform: "YouTube",
      engagementRate: "7.8%",
      responseTime: "< 8h",
      averageROI: "480%"
    },
    {
      id: 9,
      name: "Kylie Jenner",
      username: "@kyliejenner",
      bio: "Reality TV • Kylie Cosmetics • 400M Instagram Followers",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
      followers: "398.5M",
      posts: "7.2K",
      holders: "3.8K",
      rating: 4.9,
      categories: ["Beauty", "Fashion", "Business"],
      verified: true,
      platform: "Instagram",
      engagementRate: "2.1%",
      responseTime: "< 24h",
      averageROI: "890%"
    },
    {
      id: 10,
      name: "Charli D'Amelio",
      username: "@charlidamelio",
      bio: "TikTok Star • Dancer • 151M TikTok Followers",
      image: "https://images.unsplash.com/photo-1494790108755-2616b332446c?w=100&h=100&fit=crop",
      followers: "151.2M",
      posts: "2.3K",
      holders: "2.1K",
      rating: 4.7,
      categories: ["Dance", "Entertainment", "Youth"],
      verified: true,
      platform: "TikTok",
      engagementRate: "6.3%",
      responseTime: "< 12h",
      averageROI: "620%"
    },
    {
      id: 11,
      name: "Addison Rae",
      username: "@addisonre",
      bio: "TikTok Star • Actress • Item Beauty • 88M TikTok Followers",
      image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&h=100&fit=crop",
      followers: "88.7M",
      posts: "1.9K",
      holders: "1.8K",
      rating: 4.6,
      categories: ["Beauty", "Entertainment", "Dance"],
      verified: true,
      platform: "TikTok",
      engagementRate: "7.1%",
      responseTime: "< 6h",
      averageROI: "550%"
    },
    {
      id: 12,
      name: "Belle Delphine",
      username: "@belledelphine",
      bio: "Internet Personality • OnlyFans Creator • Cosplay Icon",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
      followers: "12.4M",
      posts: "892",
      holders: "2.3K",
      rating: 4.8,
      categories: ["Gaming", "Cosplay", "Entertainment"],
      verified: true,
      platform: "OnlyFans",
      engagementRate: "15.2%",
      responseTime: "< 2h",
      averageROI: "720%"
    },
    {
      id: 13,
      name: "Corinna Kopf",
      username: "@corinnakopf",
      bio: "YouTuber • Twitch Streamer • OnlyFans Creator",
      image: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=100&h=100&fit=crop",
      followers: "6.8M",
      posts: "1.2K",
      holders: "1.9K",
      rating: 4.5,
      categories: ["Gaming", "Entertainment", "Lifestyle"],
      verified: true,
      platform: "OnlyFans",
      engagementRate: "9.4%",
      responseTime: "< 4h",
      averageROI: "580%"
    },
    {
      id: 14,
      name: "Loren Gray",
      username: "@lorengray",
      bio: "Singer • TikTok Star • 54M TikTok Followers",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
      followers: "54.1M",
      posts: "2.8K",
      holders: "1.1K",
      rating: 4.3,
      categories: ["Music", "Entertainment", "Fashion"],
      verified: true,
      platform: "TikTok",
      engagementRate: "5.7%",
      responseTime: "< 8h",
      averageROI: "420%"
    },
    {
      id: 15,
      name: "Pokimane",
      username: "@pokimanelol",
      bio: "Twitch Streamer • YouTuber • 9M Twitch Followers",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
      followers: "9.3M",
      posts: "3.1K",
      holders: "2.2K",
      rating: 4.7,
      categories: ["Gaming", "Entertainment", "Tech"],
      verified: true,
      platform: "Twitch",
      engagementRate: "8.9%",
      responseTime: "< 3h",
      averageROI: "640%"
    },
    {
      id: 16,
      name: "Dixie D'Amelio",
      username: "@dixiedamelio",
      bio: "Singer • TikTok Star • Sister of Charli • 57M TikTok Followers",
      image: "https://images.unsplash.com/photo-1494790108755-2616b332446c?w=100&h=100&fit=crop",
      followers: "57.4M",
      posts: "1.7K",
      holders: "1.3K",
      rating: 4.4,
      categories: ["Music", "Entertainment", "Youth"],
      verified: true,
      platform: "TikTok",
      engagementRate: "6.8%",
      responseTime: "< 10h",
      averageROI: "480%"
    },
    {
      id: 17,
      name: "MrBeast",
      username: "@mrbeast",
      bio: "YouTuber • Philanthropist • 200M YouTube Subscribers",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
      followers: "203.5M",
      posts: "741",
      holders: "4.2K",
      rating: 4.9,
      categories: ["Entertainment", "Philanthropy", "Business"],
      verified: true,
      platform: "YouTube",
      engagementRate: "12.4%",
      responseTime: "< 48h",
      averageROI: "1200%"
    },
    {
      id: 18,
      name: "Emma Chamberlain",
      username: "@emmachamberlain",
      bio: "YouTuber • Podcaster • Fashion Icon • 16M YouTube Subscribers",
      image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&h=100&fit=crop",
      followers: "16.2M",
      posts: "2.4K",
      holders: "1.7K",
      rating: 4.6,
      categories: ["Fashion", "Lifestyle", "Coffee"],
      verified: true,
      platform: "YouTube",
      engagementRate: "7.3%",
      responseTime: "< 12h",
      averageROI: "520%"
    },
    {
      id: 19,
      name: "Lana Rhoades",
      username: "@lanarhoades",
      bio: "Former Adult Film Star • OnlyFans Creator • Podcast Host",
      image: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=100&h=100&fit=crop",
      followers: "16.8M",
      posts: "1.1K",
      holders: "3.4K",
      rating: 4.8,
      categories: ["Entertainment", "Lifestyle", "Business"],
      verified: true,
      platform: "OnlyFans",
      engagementRate: "11.7%",
      responseTime: "< 6h",
      averageROI: "680%"
    },
    {
      id: 20,
      name: "Riley Reid",
      username: "@rileyreidx3",
      bio: "Adult Film Star • OnlyFans Creator • Social Media Influencer",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
      followers: "8.9M",
      posts: "2.3K",
      holders: "2.8K",
      rating: 4.7,
      categories: ["Entertainment", "Lifestyle", "Fitness"],
      verified: true,
      platform: "OnlyFans",
      engagementRate: "13.2%",
      responseTime: "< 4h",
      averageROI: "750%"
    },
    {
      id: 21,
      name: "James Charles",
      username: "@jamescharles",
      bio: "Beauty YouTuber • Makeup Artist • 24M YouTube Subscribers",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
      followers: "24.1M",
      posts: "3.2K",
      holders: "1.9K",
      rating: 4.3,
      categories: ["Beauty", "Fashion", "LGBTQ+"],
      verified: true,
      platform: "YouTube",
      engagementRate: "6.1%",
      responseTime: "< 8h",
      averageROI: "440%"
    },
    {
      id: 22,
      name: "Nikocado Avocado",
      username: "@nikocadoavocado",
      bio: "Mukbang YouTuber • Dramatic Content Creator • 4M YouTube Subscribers",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
      followers: "4.2M",
      posts: "1.8K",
      holders: "892",
      rating: 4.1,
      categories: ["Food", "Entertainment", "Controversy"],
      verified: true,
      platform: "YouTube",
      engagementRate: "9.8%",
      responseTime: "< 24h",
      averageROI: "380%"
    },
    {
      id: 23,
      name: "Valkyrae",
      username: "@valkyrae",
      bio: "Twitch Streamer • YouTuber • 100 Thieves Co-owner • 3.9M YouTube Subscribers",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
      followers: "3.9M",
      posts: "2.1K",
      holders: "1.8K",
      rating: 4.6,
      categories: ["Gaming", "Entertainment", "Business"],
      verified: true,
      platform: "YouTube",
      engagementRate: "8.4%",
      responseTime: "< 5h",
      averageROI: "560%"
    },
    {
      id: 24,
      name: "Bretman Rock",
      username: "@bretmanrock",
      bio: "Beauty Influencer • Comedian • 18M Instagram Followers",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
      followers: "18.3M",
      posts: "2.8K",
      holders: "1.4K",
      rating: 4.5,
      categories: ["Beauty", "Comedy", "LGBTQ+"],
      verified: true,
      platform: "Instagram",
      engagementRate: "7.9%",
      responseTime: "< 6h",
      averageROI: "490%"
    }
  ];

  // Filter creators based on search term and filters
  const filteredHosts = hosts.filter((host) => {
    // Search term filter
    if (searchTerm && searchTerm.trim() !== "") {
      const searchLower = searchTerm.toLowerCase();
      const nameMatch = host.name.toLowerCase().includes(searchLower);
      const usernameMatch = host.username?.toLowerCase().includes(searchLower);
      const bioMatch = host.bio?.toLowerCase().includes(searchLower);
      
      if (!nameMatch && !usernameMatch && !bioMatch) {
        return false;
      }
    }

    // Platform filter
    if (platformFilter !== "all") {
      const platformMatch = host.platform.toLowerCase() === platformFilter.toLowerCase();
      if (!platformMatch) {
        return false;
      }
    }

    // Category filter
    if (categoryFilter !== "all") {
      const categoryMatch = host.categories.some((cat: string) => 
        cat.toLowerCase() === categoryFilter.toLowerCase()
      );
      if (!categoryMatch) {
        return false;
      }
    }

    // Followers filter
    if (followersFilter !== "all") {
      const followers = parseFloat(host.followers.replace(/[^\d.]/g, ''));
      const unit = host.followers.includes('M') ? 'M' : 'K';
      
      if (followersFilter === "1m-10m" && (unit !== 'M' || followers < 1 || followers > 10)) {
        return false;
      }
      if (followersFilter === "10m-50m" && (unit !== 'M' || followers < 10 || followers > 50)) {
        return false;
      }
      if (followersFilter === "50m+" && (unit !== 'M' || followers < 50)) {
        return false;
      }
    }

    // Engagement filter
    if (engagementFilter !== "all") {
      const engagement = parseFloat(host.engagementRate.replace('%', ''));
      
      if (engagementFilter === "high" && engagement < 5) {
        return false;
      }
      if (engagementFilter === "medium" && (engagement < 2 || engagement >= 5)) {
        return false;
      }
      if (engagementFilter === "low" && engagement >= 2) {
        return false;
      }
    }

    return true;
  });

  const handleLeaveReview = (host: any) => {
    setSelectedHost(host);
    setShowReview(true);
  };

  const handlePartnerWith = (host: any) => {
    setSelectedHost(host);
    setShowPartnership(true);
  };

  const handleBookCall = (host: any) => {
    setSelectedHost(host);
    setShowBookCall(true);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900/50 border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              Creator Marketplace Alpha
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Connect with top OnlyFans, Instagram, and TikTok creators to accelerate your Web3 brand growth.
            </p>
            
            {/* Create Campaign Button */}
            <div className="mt-8">
              <Button
                onClick={() => setShowCampaignBuilder(true)}
                className="bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600 text-white px-8 py-3 rounded-2xl font-semibold text-lg shadow-lg"
              >
                <Target className="w-5 h-5 mr-2" />
                Create Campaign
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-8">
            {[
              { key: "leaderboard", label: "Creator Leaderboard", icon: Trophy },
              { key: "events", label: "Event Campaigns", icon: Calendar },
              { key: "dao", label: "Creator DAO", icon: Users }
            ].map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key as any)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-colors ${
                  activeTab === key
                    ? "border-purple-500 text-white"
                    : "border-transparent text-gray-400 hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Leaderboard Tab */}
      {activeTab === "leaderboard" && (
        <div className="max-w-7xl mx-auto px-6 py-12">
          {/* Search Bar */}
          <div className="mb-6">
            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search by name, specialty, or @username..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-gray-800/50 border-gray-700 rounded-2xl text-lg placeholder-gray-400 focus:border-purple-500/50 focus:ring-purple-500/20"
              />
            </div>
          </div>

          {/* Filters */}
          <div className="bg-gray-800/50 rounded-2xl p-6 mb-8">
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-300">Filters:</span>
              </div>
              
              <Select value={platformFilter} onValueChange={setPlatformFilter}>
                <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                  <SelectValue placeholder="Platform" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="all">All Platforms</SelectItem>
                  <SelectItem value="onlyfans">OnlyFans</SelectItem>
                  <SelectItem value="instagram">Instagram</SelectItem>
                  <SelectItem value="tiktok">TikTok</SelectItem>
                  <SelectItem value="youtube">YouTube</SelectItem>
                  <SelectItem value="twitch">Twitch</SelectItem>
                </SelectContent>
              </Select>

              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="beauty">Beauty</SelectItem>
                  <SelectItem value="fashion">Fashion</SelectItem>
                  <SelectItem value="gaming">Gaming</SelectItem>
                  <SelectItem value="lifestyle">Lifestyle</SelectItem>
                  <SelectItem value="fitness">Fitness</SelectItem>
                  <SelectItem value="sports">Sports</SelectItem>
                  <SelectItem value="music">Music</SelectItem>
                  <SelectItem value="dance">Dance</SelectItem>
                  <SelectItem value="business">Business</SelectItem>
                  <SelectItem value="tech">Tech</SelectItem>
                  <SelectItem value="comedy">Comedy</SelectItem>
                  <SelectItem value="food">Food</SelectItem>
                  <SelectItem value="cosplay">Cosplay</SelectItem>
                  <SelectItem value="philanthropy">Philanthropy</SelectItem>
                  <SelectItem value="controversy">Controversy</SelectItem>
                  <SelectItem value="youth">Youth</SelectItem>
                  <SelectItem value="lgbtq+">LGBTQ+</SelectItem>
                  <SelectItem value="coffee">Coffee</SelectItem>
                </SelectContent>
              </Select>

              <Select value={followersFilter} onValueChange={setFollowersFilter}>
                <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                  <SelectValue placeholder="Followers" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="all">All Ranges</SelectItem>
                  <SelectItem value="1m-10m">1M - 10M</SelectItem>
                  <SelectItem value="10m-50m">10M - 50M</SelectItem>
                  <SelectItem value="50m+">50M+</SelectItem>
                </SelectContent>
              </Select>

              <Select value={engagementFilter} onValueChange={setEngagementFilter}>
                <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                  <SelectValue placeholder="Engagement Rate" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="all">All Rates</SelectItem>
                  <SelectItem value="high">High (5%+)</SelectItem>
                  <SelectItem value="medium">Medium (2-5%)</SelectItem>
                  <SelectItem value="low">Low (0-2%)</SelectItem>
                </SelectContent>
              </Select>

              <Select value={responseTimeFilter} onValueChange={setResponseTimeFilter}>
                <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                  <SelectValue placeholder="Response Time" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="all">All Response Times</SelectItem>
                  <SelectItem value="instant">&lt; 1 hour</SelectItem>
                  <SelectItem value="fast">&lt; 24 hours</SelectItem>
                  <SelectItem value="moderate">1-3 days</SelectItem>
                </SelectContent>
              </Select>

              <Select value={locationFilter} onValueChange={setLocationFilter}>
                <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="us">United States</SelectItem>
                  <SelectItem value="uk">United Kingdom</SelectItem>
                  <SelectItem value="ca">Canada</SelectItem>
                  <SelectItem value="au">Australia</SelectItem>
                  <SelectItem value="de">Germany</SelectItem>
                  <SelectItem value="fr">France</SelectItem>
                </SelectContent>
              </Select>

              <Button className="bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600">
                <Search className="w-4 h-4 mr-2" />
                Apply Filters
              </Button>
            </div>
          </div>

          {/* Creator Cards */}
          {filteredHosts.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Search className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <h3 className="text-xl font-semibold mb-2">No creators found</h3>
                <p>Try adjusting your search terms or filters to find creators.</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
              {filteredHosts.map((host) => (
              <Card key={host.id} className="bg-gray-800/50 border-gray-700 p-8 hover:border-purple-500/50 transition-all min-h-[480px]">
                <div className="flex items-center gap-4 mb-6">
                  <img 
                    src={host.image} 
                    alt={host.name}
                    className="w-20 h-20 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-xl">{host.name}</h3>
                      {host.verified && <CheckCircle className="w-5 h-5 text-blue-400" />}
                    </div>
                    <p className="text-gray-400 text-sm">{host.username}</p>
                    <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/50 text-sm mt-2">
                      {host.platform}
                    </Badge>
                  </div>
                </div>

                <p className="text-gray-300 text-sm mb-6 leading-relaxed">{host.bio}</p>

                <div className="grid grid-cols-3 gap-4 mb-6 text-center">
                  <div>
                    <div className="text-xl font-bold text-purple-400">{host.followers}</div>
                    <div className="text-xs text-gray-400">Followers</div>
                  </div>
                  <div>
                    <div className="text-xl font-bold text-teal-400">{host.engagementRate}</div>
                    <div className="text-xs text-gray-400">Engagement</div>
                  </div>
                  <div>
                    <div className="text-xl font-bold text-green-400">{host.averageROI}</div>
                    <div className="text-xs text-gray-400">Avg ROI</div>
                  </div>
                </div>

                <div className="flex justify-between items-center mb-6 text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(host.rating)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-600"
                        }`}
                      />
                    ))}
                    <span className="ml-2 text-sm">{host.rating}</span>
                  </div>
                  <div className="text-xs">Response: {host.responseTime}</div>
                </div>

                <div className="flex flex-wrap gap-2 mb-6">
                  {host.categories.map((category) => (
                    <Badge key={category} variant="outline" className="border-gray-600 text-gray-300 text-xs">
                      {category}
                    </Badge>
                  ))}
                </div>

                <div className="flex flex-col gap-3 mt-auto">
                  <Button 
                    className="w-full bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600 py-3"
                    onClick={() => handlePartnerWith(host)}
                  >
                    <Target className="w-4 h-4 mr-2" />
                    Partner with {host.name.split(' ')[0]}
                  </Button>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline"
                      className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700 py-2"
                      onClick={() => handleBookCall(host)}
                    >
                      <Calendar className="w-4 h-4 mr-2" />
                      Book Call
                    </Button>
                    <Button 
                      variant="outline"
                      className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700 py-2"
                      onClick={() => handleLeaveReview(host)}
                    >
                      <Star className="w-4 h-4 mr-2" />
                      Review
                    </Button>
                  </div>
                </div>
              </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Events Tab */}
      {activeTab === "events" && (
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold">Event Campaigns</h2>
            <Button
              onClick={() => setShowCreateEvent(true)}
              className="bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600"
            >
              Create Event
            </Button>
          </div>
          <div className="text-center text-gray-400 py-12">
            Event management features coming soon...
          </div>
        </div>
      )}

      {/* DAO Tab */}
      {activeTab === "dao" && (
        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Creator DAO</h2>
            <p className="text-xl text-gray-300">
              Governance and revenue sharing for the creator economy
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-gray-800/50 border-gray-700 p-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400 mb-2">20%</div>
                <div className="text-sm text-gray-400">Platform Revenue Share</div>
              </div>
            </Card>
            <Card className="bg-gray-800/50 border-gray-700 p-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-teal-400 mb-2">12</div>
                <div className="text-sm text-gray-400">Active Creators</div>
              </div>
            </Card>
            <Card className="bg-gray-800/50 border-gray-700 p-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400 mb-2">$FANS</div>
                <div className="text-sm text-gray-400">Governance Token</div>
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* Partnership Modal */}
      {showPartnership && selectedHost && (
        <Dialog open={showPartnership} onOpenChange={() => {
          setShowPartnership(false);
          setSelectedHost(null);
        }}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold">Partner with {selectedHost.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="flex items-center gap-6">
                <img
                  src={selectedHost.image}
                  alt={selectedHost.name}
                  className="w-20 h-20 rounded-full object-cover"
                />
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2">{selectedHost.name}</h3>
                  <p className="text-gray-300 mb-2">{selectedHost.bio}</p>
                  <div className="flex gap-4 text-sm text-gray-400">
                    <span>{selectedHost.followers} followers</span>
                    <span>{selectedHost.engagementRate} engagement</span>
                    <span>{selectedHost.averageROI} avg ROI</span>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-700 pt-6">
                <h4 className="text-lg font-semibold mb-4">Partnership Details</h4>
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h5 className="font-medium mb-2">Platform Fee</h5>
                    <div className="text-2xl font-bold text-purple-400">0.05 ETH</div>
                    <div className="text-sm text-gray-400">One-time partnership fee</div>
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h5 className="font-medium mb-2">Estimated Campaign Value</h5>
                    <div className="text-2xl font-bold text-green-400">$17,000</div>
                    <div className="text-sm text-gray-400">Based on {selectedHost.averageROI} ROI</div>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-700 pt-6">
                <h4 className="text-lg font-semibold mb-4">What's Included</h4>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    Direct contact with {selectedHost.name}
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    Campaign strategy consultation
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    Performance tracking and analytics
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    Escrow payment protection
                  </li>
                </ul>
              </div>
              
              <div className="flex gap-4 pt-6">
                <Button
                  onClick={() => {
                    setShowPartnership(false);
                    setSelectedHost(null);
                  }}
                  variant="outline"
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600"
                >
                  Proceed to Payment
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Review Modal */}
      {showReview && selectedHost && (
        <ReviewModal
          host={selectedHost}
          onClose={() => {
            setShowReview(false);
            setSelectedHost(null);
          }}
        />
      )}

      {/* Create Event Modal */}
      {showCreateEvent && (
        <CreateCampaignModal
          onClose={() => setShowCreateEvent(false)}
          hosts={hosts}
        />
      )}

      {/* Book Call Modal */}
      {showBookCall && selectedHost && (
        <BookCallModal
          isOpen={showBookCall}
          onClose={() => {
            setShowBookCall(false);
            setSelectedHost(null);
          }}
          creator={selectedHost}
        />
      )}

      {/* Campaign Builder Modal */}
      {showCampaignBuilder && (
        <CampaignBuilderModal
          isOpen={showCampaignBuilder}
          onClose={() => setShowCampaignBuilder(false)}
          availableCreators={hosts}
        />
      )}
    </div>
  );
}