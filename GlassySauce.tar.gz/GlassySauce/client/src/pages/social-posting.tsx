import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Image, 
  Video, 
  Calendar, 
  Clock, 
  Hash, 
  AtSign, 
  Eye, 
  EyeOff, 
  Upload,
  X,
  User,
  Settings,
  Send,
  Plus
} from "lucide-react";
import { TwitterIcon, InstagramIcon, OnlyFansIcon } from "@/components/ui/crypto-icons";

interface SocialPlatform {
  id: string;
  name: string;
  icon: any;
  connected: boolean;
  color: string;
  limits: {
    maxChars: number;
    maxImages: number;
    maxVideos: number;
  };
}

export default function SocialPosting() {
  const [postContent, setPostContent] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["instagram", "twitter"]);
  const [mediaFiles, setMediaFiles] = useState<File[]>([]);
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("");
  const [contentType, setContentType] = useState<"public" | "premium" | "exclusive">("public");
  const [hashtags, setHashtags] = useState("");
  const [mentions, setMentions] = useState("");

  const platforms: SocialPlatform[] = [
    {
      id: "onlyfans",
      name: "OnlyFans",
      icon: OnlyFansIcon,
      connected: true,
      color: "from-blue-500 to-blue-600",
      limits: { maxChars: 1000, maxImages: 10, maxVideos: 1 }
    },
    {
      id: "instagram",
      name: "Instagram",
      icon: InstagramIcon,
      connected: true,
      color: "from-pink-500 to-purple-600",
      limits: { maxChars: 2200, maxImages: 10, maxVideos: 1 }
    },
    {
      id: "twitter",
      name: "X (Twitter)",
      icon: TwitterIcon,
      connected: true,
      color: "from-gray-800 to-black",
      limits: { maxChars: 280, maxImages: 4, maxVideos: 1 }
    }
  ];

  const togglePlatform = (platformId: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platformId) 
        ? prev.filter(id => id !== platformId)
        : [...prev, platformId]
    );
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setMediaFiles(prev => [...prev, ...files]);
  };

  const removeFile = (index: number) => {
    setMediaFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handlePost = () => {
    const postData = {
      content: postContent,
      platforms: selectedPlatforms,
      media: mediaFiles,
      scheduled: scheduledDate && scheduledTime ? new Date(`${scheduledDate}T${scheduledTime}`) : null,
      contentType,
      hashtags: hashtags.split(' ').filter(tag => tag.trim()),
      mentions: mentions.split(' ').filter(mention => mention.trim())
    };

    console.log('Posting to platforms:', postData);
    alert(`Post scheduled for ${selectedPlatforms.join(', ')}`);
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Cross-Platform Posting</h1>
          <p className="text-white/60">Post content across OnlyFans, Instagram, and X simultaneously</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Editor */}
          <div className="lg:col-span-2 space-y-6">
            {/* Platform Selection */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-bold text-white mb-4">Select Platforms</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {platforms.map((platform) => {
                  const Icon = platform.icon;
                  const isSelected = selectedPlatforms.includes(platform.id);
                  
                  return (
                    <div
                      key={platform.id}
                      onClick={() => togglePlatform(platform.id)}
                      className={`relative p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        isSelected 
                          ? "border-pink-500 bg-pink-500/10" 
                          : "border-white/20 hover:border-white/40"
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 rounded-lg flex items-center justify-center">
                          <Icon size={40} />
                        </div>
                        <div>
                          <div className="text-white font-medium">{platform.name}</div>
                          <Badge variant={platform.connected ? "default" : "secondary"} className="text-xs">
                            {platform.connected ? "Connected" : "Not Connected"}
                          </Badge>
                        </div>
                      </div>
                      
                      {isSelected && (
                        <div className="text-xs text-white/70">
                          <div>Max: {platform.limits.maxChars} chars</div>
                          <div>{platform.limits.maxImages} images, {platform.limits.maxVideos} video</div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </GlassCard>

            {/* Content Editor */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-bold text-white mb-4">Create Your Post</h2>
              
              {/* Content Type Selector */}
              <div className="mb-4">
                <label className="text-white/70 text-sm mb-2 block">Content Type</label>
                <div className="flex gap-2">
                  {[
                    { id: "public", label: "Public", icon: Eye },
                    { id: "premium", label: "Premium", icon: EyeOff },
                    { id: "exclusive", label: "Exclusive", icon: User }
                  ].map((type) => {
                    const Icon = type.icon;
                    return (
                      <button
                        key={type.id}
                        onClick={() => setContentType(type.id as any)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                          contentType === type.id
                            ? "bg-pink-500/20 border border-pink-500"
                            : "bg-white/5 border border-white/10 hover:border-white/20"
                        }`}
                      >
                        <Icon className="w-4 h-4 text-white" />
                        <span className="text-white text-sm">{type.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Text Content */}
              <div className="mb-4">
                <textarea
                  placeholder="What's happening?"
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  className="w-full h-32 bg-white/5 border border-white/10 rounded-lg p-4 text-white placeholder-white/40 resize-none focus:outline-none focus:border-pink-500/50"
                />
                <div className="text-right text-sm text-white/60 mt-1">
                  {postContent.length}/280 characters
                </div>
              </div>

              {/* Hashtags and Mentions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-white/70 text-sm mb-2 block flex items-center gap-2">
                    <Hash className="w-4 h-4" />
                    Hashtags
                  </label>
                  <input
                    type="text"
                    placeholder="#crypto #onlyfans #creator"
                    value={hashtags}
                    onChange={(e) => setHashtags(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white placeholder-white/40 focus:outline-none focus:border-pink-500/50"
                  />
                </div>
                <div>
                  <label className="text-white/70 text-sm mb-2 block flex items-center gap-2">
                    <AtSign className="w-4 h-4" />
                    Mentions
                  </label>
                  <input
                    type="text"
                    placeholder="@username @another"
                    value={mentions}
                    onChange={(e) => setMentions(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white placeholder-white/40 focus:outline-none focus:border-pink-500/50"
                  />
                </div>
              </div>

              {/* Media Upload */}
              <div className="mb-6">
                <label className="text-white/70 text-sm mb-2 block flex items-center gap-2">
                  <Upload className="w-4 h-4" />
                  Media Files
                </label>
                
                <div className="border-2 border-dashed border-white/20 rounded-lg p-6 text-center">
                  <input
                    type="file"
                    multiple
                    accept="image/*,video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="media-upload"
                  />
                  <label htmlFor="media-upload" className="cursor-pointer">
                    <Upload className="w-8 h-8 text-white/40 mx-auto mb-2" />
                    <div className="text-white/60">Click to upload images or videos</div>
                    <div className="text-white/40 text-sm">Max 10 files per platform</div>
                  </label>
                </div>

                {/* Media Preview */}
                {mediaFiles.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                    {mediaFiles.map((file, index) => (
                      <div key={index} className="relative">
                        <div className="aspect-square bg-white/10 rounded-lg flex items-center justify-center">
                          {file.type.startsWith('image/') ? (
                            <Image className="w-8 h-8 text-white/60" />
                          ) : (
                            <Video className="w-8 h-8 text-white/60" />
                          )}
                        </div>
                        <button
                          onClick={() => removeFile(index)}
                          className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center"
                        >
                          <X className="w-4 h-4 text-white" />
                        </button>
                        <div className="text-xs text-white/60 mt-1 truncate">{file.name}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </GlassCard>
          </div>

          {/* Sidebar - Schedule & Settings */}
          <div className="space-y-6">
            {/* Schedule Post */}
            <GlassCard className="p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Schedule Post
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-white/70 text-sm mb-2 block">Date</label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-pink-500/50"
                  />
                </div>
                <div>
                  <label className="text-white/70 text-sm mb-2 block">Time</label>
                  <input
                    type="time"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-pink-500/50"
                  />
                </div>
              </div>

              {scheduledDate && scheduledTime && (
                <div className="mt-4 p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-lg">
                  <div className="text-cyan-400 text-sm font-medium">Scheduled for:</div>
                  <div className="text-white text-sm">{new Date(`${scheduledDate}T${scheduledTime}`).toLocaleString()}</div>
                </div>
              )}
            </GlassCard>

            {/* Platform Limits */}
            <GlassCard className="p-6">
              <h3 className="text-lg font-bold text-white mb-4">Platform Limits</h3>
              <div className="space-y-3">
                {selectedPlatforms.map(platformId => {
                  const platform = platforms.find(p => p.id === platformId);
                  if (!platform) return null;
                  
                  const charCount = postContent.length;
                  const isOverLimit = charCount > platform.limits.maxChars;
                  
                  return (
                    <div key={platformId} className="flex items-center justify-between">
                      <span className="text-white/70 text-sm">{platform.name}</span>
                      <span className={`text-sm ${isOverLimit ? 'text-red-400' : 'text-green-400'}`}>
                        {charCount}/{platform.limits.maxChars}
                      </span>
                    </div>
                  );
                })}
              </div>
            </GlassCard>

            {/* Post Actions */}
            <div className="space-y-3">
              <GradientButton
                variant="saucy"
                className="w-full h-12 text-lg font-semibold"
                onClick={handlePost}
                disabled={!postContent.trim() || selectedPlatforms.length === 0}
              >
                <Send className="w-5 h-5 mr-2" />
                {scheduledDate && scheduledTime ? 'Schedule Post' : 'Post Now'}
              </GradientButton>
              
              <GradientButton
                variant="glass"
                className="w-full h-10"
                onClick={() => {
                  setPostContent("");
                  setMediaFiles([]);
                  setScheduledDate("");
                  setScheduledTime("");
                  setHashtags("");
                  setMentions("");
                }}
              >
                Clear All
              </GradientButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}