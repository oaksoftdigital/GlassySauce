import { Navigation } from "@/components/layout/navigation";
import { EnhancedPortfolio } from "@/components/wallet/enhanced-portfolio";
import { useQuery } from "@tanstack/react-query";
import type { Portfolio } from "@/types";

export default function Wallet() {
  const { data: portfolio, isLoading } = useQuery<Portfolio>({
    queryKey: ['/api/wallet/portfolio'],
  });

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 text-shadow">
              Your Wallet
            </h2>
            <p className="text-xl text-white/80">
              Manage your tokens, keys, and earnings
            </p>
          </div>
          
          {isLoading ? (
            <div className="animate-pulse">
              <div className="glass-dark rounded-3xl p-8 h-96 mb-8"></div>
            </div>
          ) : portfolio ? (
            <EnhancedPortfolio portfolio={portfolio} />
          ) : (
            <div className="text-center py-16">
              <div className="glass-dark rounded-3xl max-w-md mx-auto p-8">
                <h3 className="text-2xl font-bold text-white mb-4">No Portfolio Data</h3>
                <p className="text-white/70">
                  Connect your wallet to view your portfolio and holdings.
                </p>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
