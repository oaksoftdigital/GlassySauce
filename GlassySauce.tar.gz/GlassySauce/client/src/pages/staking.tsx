import { useState, useEffect } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Bookmark,
  DollarSign,
  ArrowUpCircle,
  ArrowDownCircle,
  Info,
  Plus,
  Minus,
  Wallet,
  TrendingUp,
  Clock,
  Shield
} from "lucide-react";
import { 
  EthereumIcon, 
  UsdtIcon, 
  UsdcIcon, 
  DaiIcon,
  FansIcon 
} from "@/components/ui/crypto-icons";

interface StakingPosition {
  id: string;
  token: string;
  symbol: string;
  amount: number;
  rewards: number;
  apr: number;
  icon: any;
  type: "dedicated" | "pooled" | "defi";
  protocol?: string;
}

interface EligibleAsset {
  id: string;
  token: string;
  symbol: string;
  balance: number;
  apr: number;
  estimatedRewards: string;
  icon: any;
  protocol: string;
}

const mockPositions: StakingPosition[] = [
  {
    id: "eth-dedicated",
    token: "Ethereum",
    symbol: "ETH",
    amount: 768.00,
    rewards: 56.7913,
    apr: 3.65,
    icon: EthereumIcon,
    type: "dedicated"
  },
  {
    id: "kilneth-pooled",
    token: "kilnETH",
    symbol: "kilnETH",
    amount: 83.98,
    rewards: 13.2935,
    apr: 3.31,
    icon: EthereumIcon,
    type: "pooled"
  },
  {
    id: "usdt-morpho",
    token: "Tether USD",
    symbol: "USDT",
    amount: 811.91,
    rewards: 97.76,
    apr: 12.66,
    icon: UsdtIcon,
    type: "defi",
    protocol: "Morpho"
  },
  {
    id: "usdc-compound",
    token: "USD Coin",
    symbol: "USDC",
    amount: 774.97,
    rewards: 98.64,
    apr: 10.59,
    icon: UsdcIcon,
    type: "defi",
    protocol: "Compound V3"
  }
];

const mockEligibleAssets: EligibleAsset[] = [
  {
    id: "usdt-available",
    token: "Tether USD",
    symbol: "USDT",
    balance: 201204.37,
    apr: 12.94,
    estimatedRewards: "+$26K/y",
    icon: UsdtIcon,
    protocol: "Morpho"
  },
  {
    id: "dai-available",
    token: "Dai Stablecoin",
    symbol: "DAI", 
    balance: 12901.38,
    apr: 8.82,
    estimatedRewards: "+$1.1K/y",
    icon: DaiIcon,
    protocol: "Sky"
  },
  {
    id: "eth-available",
    token: "Ethereum",
    symbol: "ETH",
    balance: 14122.47,
    apr: 3.98,
    estimatedRewards: "+$1.4M/y",
    icon: EthereumIcon,
    protocol: "Dedicated Staking"
  }
];

export default function Staking() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedNetwork, setSelectedNetwork] = useState("ethereum");
  const [walletAddress, setWalletAddress] = useState("0xEA2n...ReWA2D5");
  const [depositAmount, setDepositAmount] = useState("");
  const [selectedAsset, setSelectedAsset] = useState("ETH");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [selectedWithdrawAsset, setSelectedWithdrawAsset] = useState("Sky USDS");

  // Calculate totals
  const totalBalance = mockPositions.reduce((sum, pos) => sum + pos.amount, 0);
  const totalEarned = mockPositions.reduce((sum, pos) => sum + pos.rewards, 0);
  const totalEarnPositions = mockPositions.reduce((sum, pos) => sum + pos.amount, 0);
  const totalEligibleAssets = mockEligibleAssets.reduce((sum, asset) => sum + asset.balance, 0);

  return (
    <div className="min-h-screen p-6 space-y-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Staking</h1>
            <p className="text-white/60">Earn rewards on your crypto assets through staking and DeFi protocols</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="text-teal-400 border-teal-400">
              <FansIcon size={16} className="mr-2" />
              Fans.tech Staking
            </Badge>
          </div>
        </div>

        {/* Main Widget Container */}
        <GlassCard className="p-0 overflow-hidden">
          {/* Fans.tech Header */}
          <div className="p-6 border-b border-white/10">
            <div className="flex items-center justify-center mb-4">
              <div className="flex items-center gap-3">
                <FansIcon size={32} className="text-white" />
                <div className="text-2xl font-bold text-white">Fans.tech Staking</div>
              </div>
            </div>
            
            {/* Network and Address */}
            <div className="flex gap-4 max-w-md mx-auto">
              <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <div className="flex items-center gap-2">
                    <EthereumIcon size={20} />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ethereum">
                    <div className="flex items-center gap-2">
                      <EthereumIcon size={16} />
                      Ethereum
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              
              <Input
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                className="bg-white/5 border-white/10 text-white"
                placeholder="Wallet Address"
              />
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="px-6 pt-4">
              <TabsList className="grid w-full grid-cols-3 bg-white/5">
                <TabsTrigger 
                  value="overview" 
                  className="data-[state=active]:chart-gradient data-[state=active]:text-white"
                >
                  <Bookmark className="w-4 h-4 mr-2" />
                  Overview
                </TabsTrigger>
                <TabsTrigger 
                  value="earn" 
                  className="data-[state=active]:chart-gradient data-[state=active]:text-white"
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Earn
                </TabsTrigger>
                <TabsTrigger 
                  value="withdraw" 
                  className="data-[state=active]:chart-gradient data-[state=active]:text-white"
                >
                  <ArrowDownCircle className="w-4 h-4 mr-2" />
                  Withdraw
                </TabsTrigger>
              </TabsList>
            </div>

            {/* Overview Tab */}
            <TabsContent value="overview" className="p-6 space-y-6">
              {/* Balance Overview */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <GlassCard className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-white/70">Balance</span>
                    <Info className="w-4 h-4 text-white/40" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    ${totalBalance.toLocaleString()}.65
                  </div>
                </GlassCard>
                
                <GlassCard className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-white/70">Earned</span>
                    <Info className="w-4 h-4 text-white/40" />
                  </div>
                  <div className="text-2xl font-bold text-green-400">
                    +${totalEarned.toLocaleString()}.53
                  </div>
                </GlassCard>
              </div>

              {/* Earn Positions */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-white">
                    Earn positions ${totalEarnPositions.toLocaleString()}.44
                  </h3>
                  <Info className="w-4 h-4 text-white/40" />
                </div>

                <div className="space-y-2">
                  <div className="grid grid-cols-3 gap-4 text-sm text-white/60 font-medium px-4">
                    <span>POSITION</span>
                    <span>REWARDS</span>
                    <span>NRR</span>
                  </div>
                  
                  {mockPositions.map((position) => (
                    <GlassCard key={position.id} className="p-4 hover:bg-white/5 transition-colors cursor-pointer">
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <div className="flex items-center gap-3">
                          <position.icon size={24} />
                          <div>
                            <div className="font-medium text-white">
                              {position.amount.toFixed(2)}
                            </div>
                            <div className="text-sm text-white/60">
                              {position.symbol}
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="font-medium text-green-400">
                            +{position.rewards.toFixed(4)}
                          </div>
                          <div className="text-sm text-white/60">
                            {position.symbol}
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="font-medium text-white">
                            {position.apr.toFixed(2)}%
                          </div>
                        </div>
                      </div>
                    </GlassCard>
                  ))}
                </div>
              </div>

              {/* Eligible Assets */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-white">
                    Your eligible assets ${totalEligibleAssets.toLocaleString()}.22
                  </h3>
                  <Info className="w-4 h-4 text-white/40" />
                </div>

                <div className="space-y-2">
                  <div className="grid grid-cols-3 gap-4 text-sm text-white/60 font-medium px-4">
                    <span>ASSET</span>
                    <span>NRR</span>
                    <span>EST.REWARDS</span>
                  </div>
                  
                  {mockEligibleAssets.map((asset) => (
                    <GlassCard key={asset.id} className="p-4 hover:bg-white/5 transition-colors">
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <div className="flex items-center gap-3">
                          <asset.icon size={24} />
                          <div>
                            <div className="font-medium text-white">
                              {asset.balance.toLocaleString()}
                            </div>
                            <div className="text-sm text-white/60">
                              {asset.symbol}
                            </div>
                          </div>
                        </div>
                        
                        <div className="font-medium text-orange-400">
                          {asset.apr.toFixed(2)}%
                        </div>
                        
                        <div className="text-right">
                          <GradientButton variant="saucy" size="sm">
                            {asset.estimatedRewards}
                          </GradientButton>
                        </div>
                      </div>
                    </GlassCard>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Earn Tab */}
            <TabsContent value="earn" className="p-6 space-y-6">
              <div className="space-y-6">
                {/* Deposit Section */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Deposit</h3>
                  
                  <GlassCard className="p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <Input
                        type="number"
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        placeholder="0.00"
                        className="bg-transparent border-none text-2xl font-bold text-white flex-1"
                      />
                      <div className="flex items-center gap-2">
                        <GradientButton variant="glass" size="sm">
                          <Plus className="w-4 h-4" />
                        </GradientButton>
                        <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                          <SelectTrigger className="bg-white/10 border-white/10 text-white w-32">
                            <div className="flex items-center gap-2">
                              <EthereumIcon size={16} />
                              <SelectValue />
                            </div>
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ETH">
                              <div className="flex items-center gap-2">
                                <EthereumIcon size={16} />
                                ETH
                              </div>
                            </SelectItem>
                            <SelectItem value="USDT">
                              <div className="flex items-center gap-2">
                                <UsdtIcon size={16} />
                                USDT
                              </div>
                            </SelectItem>
                            <SelectItem value="USDC">
                              <div className="flex items-center gap-2">
                                <UsdcIcon size={16} />
                                USDC
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span className="text-white/60">MINIMUM DEPOSIT IS 32 ETH</span>
                      <span className="text-white/60">
                        <span className="text-white">14,122.4785 ETH AVAILABLE</span>
                        <span className="text-orange-400 ml-2 cursor-pointer">MAX</span>
                      </span>
                    </div>
                  </GlassCard>
                </div>

                {/* Earn Section */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Earn</h3>
                  
                  <GlassCard className="p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="text-3xl font-bold text-orange-400">3.98%</div>
                      <div className="flex items-center gap-2">
                        <EthereumIcon size={20} />
                        <Select defaultValue="dedicated">
                          <SelectTrigger className="bg-white/10 border-white/10 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="dedicated">via Dedicated Staking</SelectItem>
                            <SelectItem value="pooled">via Pooled Staking</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-white/60">YEARLY</span>
                        <div className="text-white">0 ETH ($0.00)</div>
                      </div>
                      <div>
                        <span className="text-white/60">MONTHLY</span>
                        <div className="text-white">0 ETH ($0.00)</div>
                      </div>
                    </div>
                  </GlassCard>

                  {/* Features */}
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 text-sm">
                      <Shield className="w-5 h-5 text-white/60 mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="font-medium text-white">DEDICATED STAKING</div>
                        <div className="text-white/60">FANS.TECH SECURE STAKING PROTOCOL</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 text-sm">
                      <TrendingUp className="w-5 h-5 text-white/60 mt-0.5 flex-shrink-0" />
                      <div className="text-white/60">
                        Stake your ETH with Fans.tech dedicated validators and earn rewards
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 text-sm">
                      <Clock className="w-5 h-5 text-white/60 mt-0.5 flex-shrink-0" />
                      <div className="text-white/60">
                        Rewards are earned approximately every 5 days and can be withdrawn manually
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 text-sm">
                      <Wallet className="w-5 h-5 text-white/60 mt-0.5 flex-shrink-0" />
                      <div className="text-white/60">
                        Request withdrawals at any time with standard network processing times
                      </div>
                    </div>
                  </div>
                </div>

                {/* Earn Button */}
                <GradientButton variant="saucy" className="w-full h-12 text-lg">
                  Earn
                </GradientButton>
              </div>
            </TabsContent>

            {/* Withdraw Tab */}
            <TabsContent value="withdraw" className="p-6 space-y-6">
              <div className="space-y-6">
                {/* Withdraw Section */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Withdraw</h3>
                  
                  <GlassCard className="p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <Input
                        type="number"
                        value={withdrawAmount}
                        onChange={(e) => setWithdrawAmount(e.target.value)}
                        placeholder="0.00"
                        className="bg-transparent border-none text-2xl font-bold text-white flex-1"
                      />
                      <Select value={selectedWithdrawAsset} onValueChange={setSelectedWithdrawAsset}>
                        <SelectTrigger className="bg-white/10 border-white/10 text-white w-40">
                          <div className="flex items-center gap-2">
                            <UsdcIcon size={16} />
                            <SelectValue />
                          </div>
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Sky USDS">Sky USDS</SelectItem>
                          <SelectItem value="USDT">USDT</SelectItem>
                          <SelectItem value="ETH">ETH</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span className="text-white/60">$536.08</span>
                      <span className="text-white/60">
                        <span className="text-white">536.23 USDS AVAILABLE</span>
                        <span className="text-orange-400 ml-2 cursor-pointer">MAX</span>
                      </span>
                    </div>
                  </GlassCard>

                  {/* Withdraw Details */}
                  <GlassCard className="p-4 space-y-3">
                    <div className="flex items-center gap-2 text-orange-400">
                      <UsdcIcon size={20} />
                      <span>You will receive 0 USDS</span>
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-white/60">SKY USDS RATE:</span>
                        <span className="text-white">1 USDS = 0.00 SEUSDS</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">WITHDRAW:</span>
                        <span className="text-white">0 SEUSDS ($0.00)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">RECEIVE:</span>
                        <span className="text-white">0 USDS ($0.00)</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 p-3 bg-white/5 rounded-lg">
                      <Info className="w-4 h-4 text-white/60 mt-0.5 flex-shrink-0" />
                      <div className="text-xs text-white/60">
                        YOU WILL EXIT THE SELECTED AMOUNT FROM YOUR ACTIVE POSITION FROM SKY USDS
                      </div>
                    </div>

                    <div className="flex items-start gap-2 p-3 bg-white/5 rounded-lg">
                      <Info className="w-4 h-4 text-white/60 mt-0.5 flex-shrink-0" />
                      <div className="text-xs text-white/60">
                        YOU WILL DIRECTLY RECEIVE THE ESTIMATED AMOUNT OF USDS IN YOUR WALLET
                      </div>
                    </div>

                    <div className="flex justify-between items-center py-2 border-t border-white/10">
                      <span className="text-white/60 flex items-center gap-2">
                        <div className="w-4 h-4 bg-black rounded flex items-center justify-center">
                          <span className="text-white text-xs">E</span>
                        </div>
                        EST. GAS FEE
                      </span>
                      <span className="text-white">0 ETH</span>
                    </div>
                  </GlassCard>

                  {/* Withdraw Button */}
                  <GradientButton variant="saucy" className="w-full h-12 text-lg">
                    Withdraw
                  </GradientButton>

                  <div className="text-xs text-white/40 text-center">
                    BY CLICKING "WITHDRAW" YOU AGREE TO OUR TERMS OF USE AND UNDERSTAND THE RISK DISCLOSURES
                  </div>
                </div>

                {/* Pending Requests */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-white">Pending request</h3>
                    <span className="text-white">$0.43</span>
                    <Info className="w-4 h-4 text-white/40" />
                  </div>

                  <div className="space-y-2">
                    <div className="grid grid-cols-3 gap-4 text-sm text-white/60 font-medium px-4">
                      <span>REQUEST</span>
                      <span>FROM</span>
                      <span>EST.CLAIM</span>
                    </div>
                    
                    <GlassCard className="p-4">
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <div className="flex items-center gap-2">
                          <EthereumIcon size={20} />
                          <div>
                            <div className="font-medium text-white">&lt;0.01</div>
                            <div className="text-sm text-white/60">ETH</div>
                          </div>
                        </div>
                        <div className="text-white/60">Pooled Staking</div>
                        <div className="text-white/60">N/A</div>
                      </div>
                    </GlassCard>
                  </div>
                </div>

                {/* Claimable */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-white">Claimable</h3>
                    <span className="text-white">$131.54</span>
                    <Info className="w-4 h-4 text-white/40" />
                  </div>

                  <div className="space-y-2">
                    <div className="grid grid-cols-3 gap-4 text-sm text-white/60 font-medium px-4">
                      <span>CLAIM</span>
                      <span>FROM</span>
                      <span></span>
                    </div>
                    
                    <GlassCard className="p-4">
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <div className="flex items-center gap-2">
                          <EthereumIcon size={20} />
                          <div>
                            <div className="font-medium text-white">&lt;0.01</div>
                            <div className="text-sm text-white/60">ETH</div>
                          </div>
                        </div>
                        <div className="text-white/60">Pooled Staking</div>
                        <GradientButton variant="saucy" size="sm">
                          Claim
                        </GradientButton>
                      </div>
                    </GlassCard>

                    <GlassCard className="p-4">
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <div className="flex items-center gap-2">
                          <EthereumIcon size={20} />
                          <div>
                            <div className="font-medium text-white">0.05</div>
                            <div className="text-sm text-white/60">ETH</div>
                          </div>
                        </div>
                        <div className="text-white/60">Dedicated Staking</div>
                        <GradientButton variant="saucy" size="sm">
                          Claim
                        </GradientButton>
                      </div>
                    </GlassCard>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Footer */}
          <div className="p-4 border-t border-white/10 text-center">
            <div className="text-xs text-white/40 flex items-center justify-center gap-2">
              <FansIcon size={12} />
              <span>POWERED BY <span className="font-semibold text-teal-400">FANS.TECH</span></span>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
}