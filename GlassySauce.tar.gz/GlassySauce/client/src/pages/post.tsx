import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Bell, 
  Filter, 
  Home, 
  Calendar, 
  FileText, 
  BarChart3, 
  MessageCircle, 
  Plus, 
  Settings, 
  ChevronDown, 
  MoreHorizontal,
  X,
  User,
  Share2,
  Eye
} from "lucide-react";
import { TwitterIcon, InstagramIcon, OnlyFansIcon, FansIcon } from "@/components/ui/crypto-icons";

interface Post {
  id: string;
  content: string;
  author: string;
  avatar: string;
  platform: "twitter" | "instagram" | "onlyfans";
  status: "scheduled" | "published" | "draft";
  date: string;
  hashtags: string[];
  engagement?: {
    likes: number;
    comments: number;
    shares: number;
  };
}

export default function Post() {
  const [currentView, setCurrentView] = useState("content");
  const [selectedWorkspace, setSelectedWorkspace] = useState("Fans.tech");
  const [searchQuery, setSearchQuery] = useState("");
  const [newPostContent, setNewPostContent] = useState("");
  const [showComposer, setShowComposer] = useState(false);
  const [selectedPlatforms, setSelectedPlatforms] = useState(["twitter"]);
  const [filterStatus, setFilterStatus] = useState("all");
  const [showMediaUpload, setShowMediaUpload] = useState(false);

  const posts: Post[] = [
    {
      id: "1",
      content: "🚀 Exciting news! $FANS token holders get exclusive access to premium creator content and early drops. Join the future of creator economy! #FANStoken #Web3Creators",
      author: "fanstech_official",
      avatar: "F",
      platform: "twitter",
      status: "published",
      date: "Dec 29, 2024 • 2:30 PM",
      hashtags: ["#FANStoken", "#Web3Creators", "#CreatorEconomy"],
      engagement: { likes: 847, comments: 112, shares: 203 }
    },
    {
      id: "2",
      content: "Behind the scenes of building the next-gen creator platform 💪 Where tokenization meets authentic connections. $FANS is revolutionizing how creators monetize! ✨",
      author: "fanstech_official",
      avatar: "F",
      platform: "instagram",
      status: "scheduled",
      date: "Dec 30, 2024 • 6:00 PM",
      hashtags: ["#BehindTheScenes", "#FANStoken", "#CreatorPlatform"]
    },
    {
      id: "3",
      content: "Exclusive $FANS staking rewards now live! 🔥 Earn passive income while supporting your favorite creators. Premium features unlocked for token holders only.",
      author: "fanstech_official",
      avatar: "F",
      platform: "onlyfans",
      status: "draft",
      date: "Draft",
      hashtags: ["#FANSstaking", "#ExclusiveContent", "#TokenRewards"]
    },
    {
      id: "4",
      content: "Thank you to our amazing $FANS community! 🙏 Over 10K holders and growing. Together we're building the future of decentralized creator monetization 💜",
      author: "fanstech_official",
      avatar: "F",
      platform: "twitter",
      status: "published",
      date: "Dec 28, 2024 • 4:15 PM",
      hashtags: ["#FANScommunity", "#ThankYou", "#Web3", "#Decentralized"],
      engagement: { likes: 1234, comments: 156, shares: 89 }
    }
  ];

  const sidebarItems = [
    { icon: Search, label: "Search", active: false },
    { icon: Bell, label: "Notifications", active: false, badge: true },
    { icon: FileText, label: "Content", active: true },
    { icon: Calendar, label: "Campaigns", active: false },
    { icon: BarChart3, label: "Analytics", active: false },
    { icon: MessageCircle, label: "Engagement", active: false }
  ];

  const channels = [
    { name: "fanstech_official", platform: "twitter", connected: true },
    { name: "fans.tech", platform: "instagram", connected: true },
    { name: "fanstech_creators", platform: "twitter", connected: true },
    { name: "fanstech_onlyfans", platform: "onlyfans", connected: true }
  ];

  return (
    <div className="min-h-screen glass flex">
      {/* Left Sidebar */}
      <div className="w-64 glass border-r border-white/20 flex flex-col">
        {/* Workspace Header */}
        <div className="p-4 border-b border-white/20">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gradient-to-r from-teal-400 to-purple-500 rounded flex items-center justify-center text-white text-xs font-bold">
              F
            </div>
            <span className="font-semibold text-white">{selectedWorkspace}</span>
            <ChevronDown className="w-4 h-4 text-white/60 ml-auto" />
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 p-4">
          <div className="space-y-2">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={() => setCurrentView(item.label.toLowerCase())}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    item.active 
                      ? "bg-gradient-to-r from-teal-400/20 to-purple-500/20 text-white border border-teal-400/30" 
                      : "text-white/70 hover:bg-white/10 hover:text-white"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm">{item.label}</span>
                  {item.badge && (
                    <div className="w-2 h-2 bg-orange-400 rounded-full ml-auto"></div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Channels Section */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-white/60 uppercase tracking-wide">Channels</span>
              <Plus className="w-4 h-4 text-white/40" />
            </div>
            <div className="space-y-1">
              {channels.map((channel) => (
                <div key={channel.name} className="flex items-center gap-2 px-2 py-1 rounded text-sm">
                  {channel.platform === "twitter" && <TwitterIcon size={16} />}
                  {channel.platform === "instagram" && <InstagramIcon size={16} />}
                  {channel.platform === "onlyfans" && <OnlyFansIcon size={16} />}
                  <span className="text-white/70 truncate">{channel.name}</span>
                  {!channel.connected && (
                    <div className="w-2 h-2 bg-yellow-400 rounded-full ml-auto"></div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* User Profile */}
        <div className="p-4 border-t border-white/20">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-r from-teal-400 to-purple-500 rounded-full flex items-center justify-center text-white text-sm">
              O
            </div>
            <span className="text-sm font-medium text-white">Fans.tech</span>
            <Settings className="w-4 h-4 text-white/40 ml-auto" />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="glass border-b border-white/20 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Home className="w-4 h-4 text-white/60" />
                <Calendar className="w-4 h-4 text-white/60" />
              </div>
              <span className="text-lg font-semibold text-white">Post</span>
              <div className="h-1 w-12 bg-gradient-to-r from-teal-400 to-purple-500 rounded-full"></div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-white/60" />
                <span className="text-sm text-white/70">Filter</span>
              </div>
              <div className="flex items-center gap-2">
                <Share2 className="w-4 h-4 text-white/60" />
                <span className="text-sm text-white/70">Media</span>
              </div>
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-white/60" />
                <User className="w-4 h-4 text-white/60" />
                <span className="text-sm text-white/70">2</span>
              </div>
              <button className="text-sm text-white/70 hover:text-white">Share</button>
              <GradientButton
                variant="saucy"
                size="sm"
                onClick={() => setShowComposer(!showComposer)}
              >
                Compose
              </GradientButton>
            </div>
          </div>
        </div>

        {/* $FANS Upgrade Banner */}
        <div className="bg-gradient-to-r from-teal-400/20 to-purple-500/20 border-b border-teal-400/30 px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-gradient-to-r from-teal-400 to-purple-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">F</span>
              </div>
              <div>
                <span className="text-sm text-white font-medium">Unlock premium posting features with $FANS tokens</span>
                <div className="text-xs text-white/80">Hold 100+ $FANS tokens to access cross-platform scheduling and analytics.</div>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="text-sm text-white/80 hover:text-white">Dismiss</button>
              <GradientButton variant="saucy" size="sm">
                Buy $FANS
              </GradientButton>
            </div>
          </div>
        </div>

        {/* Content Feed */}
        <div className="flex-1 p-6">
          {/* Post Composer Modal */}
          {showComposer && (
            <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50">
              <div className="glass rounded-xl shadow-2xl w-full max-w-3xl mx-4 max-h-[90vh] overflow-hidden border border-white/20">
                {/* Modal Header */}
                <div className="border-b border-white/20 p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <h2 className="text-white text-xl font-semibold">Post</h2>
                      <div className="h-1 w-12 bg-gradient-to-r from-teal-400 to-purple-500 rounded-full"></div>
                    </div>
                    <button 
                      onClick={() => setShowComposer(false)}
                      className="text-white/60 hover:text-white transition-colors"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                </div>

                {/* Platform Selection */}
                <div className="p-4 border-b border-white/20">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-white/60 text-sm">Post on:</span>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-teal-400/20 to-purple-500/20 rounded-lg border border-teal-400/30">
                        <FansIcon size={20} />
                        <span className="text-white text-sm">Add Platform</span>
                        <ChevronDown className="w-4 h-4 text-white/60" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-teal-400/20 to-purple-500/20 rounded-lg border border-teal-400/30">
                      <TwitterIcon size={24} />
                      <button className="text-white/60 bg-white/20 rounded-full w-4 h-4 flex items-center justify-center text-xs hover:bg-white/30">
                        <X className="w-2 h-2" />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-teal-400/20 to-purple-500/20 rounded-lg border border-teal-400/30">
                      <InstagramIcon size={24} />
                      <button className="text-white/60 bg-white/20 rounded-full w-4 h-4 flex items-center justify-center text-xs hover:bg-white/30">
                        <X className="w-2 h-2" />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-teal-400/20 to-purple-500/20 rounded-lg border border-teal-400/30">
                      <OnlyFansIcon size={24} />
                      <button className="text-white/60 bg-white/20 rounded-full w-4 h-4 flex items-center justify-center text-xs hover:bg-white/30">
                        <X className="w-2 h-2" />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-teal-400/20 to-purple-500/20 rounded-lg border border-teal-400/30">
                      <FansIcon size={24} />
                      <button className="text-white/60 bg-white/20 rounded-full w-4 h-4 flex items-center justify-center text-xs hover:bg-white/30">
                        <span className="text-xs font-bold">+</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Content Area */}
                <div className="p-4">
                  <textarea
                    placeholder="Share the next big thing..."
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    className="w-full h-32 bg-transparent border-none resize-none focus:outline-none text-white placeholder-white/50 text-lg"
                  />

                  {/* AI Generate Button */}
                  <button className="flex items-center gap-2 px-3 py-1 text-teal-400 hover:bg-teal-400/10 rounded mb-4">
                    <span className="text-teal-400">✨</span>
                    <span className="text-sm font-medium">Generate with AI</span>
                  </button>

                  {/* Media Tools */}
                  <div className="flex items-center justify-between">
                    <div className="flex gap-3">
                      <button 
                        onClick={() => setShowMediaUpload(true)}
                        className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded"
                      >
                        <span className="text-lg">🖼️</span>
                      </button>
                      <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded">
                        <span className="text-lg">GIF</span>
                      </button>
                      <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded">
                        <span className="text-lg">🎬</span>
                      </button>
                      <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded">
                        <span className="text-lg">📅</span>
                      </button>
                      <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded">
                        <span className="text-lg">🌐</span>
                      </button>
                    </div>
                    <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded">
                      <span className="text-lg">😊</span>
                    </button>
                  </div>
                </div>

                {/* Footer */}
                <div className="border-t border-white/20 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <button className="flex items-center gap-2 text-white/60 hover:text-white">
                        <Calendar className="w-4 h-4" />
                        <span className="text-sm">Select date & time</span>
                        <ChevronDown className="w-3 h-3" />
                      </button>
                      <button className="text-white/60 hover:text-white">
                        <span className="text-sm">Discard</span>
                      </button>
                    </div>
                    <GradientButton
                      variant="saucy"
                      disabled={!newPostContent.trim()}
                    >
                      Post
                    </GradientButton>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Post Feed Tabs */}
          <div className="mb-6">
            <div className="flex items-center space-x-6">
              {['All feed', 'Posts', 'Transactions', 'Trending'].map((tab) => (
                <button
                  key={tab}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    tab === 'All feed'
                      ? 'bg-gradient-to-r from-teal-400/20 to-purple-500/20 text-white border border-teal-400/30'
                      : 'text-white/60 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Posts Grid */}
          <div className="grid gap-4">
            {posts.map((post) => (
              <div key={post.id} className="glass rounded-xl p-4 border border-white/20">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-teal-400 to-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    {post.avatar}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-medium">{post.author}</span>
                      {post.platform === "twitter" && <TwitterIcon size={16} />}
                      {post.platform === "instagram" && <InstagramIcon size={16} />}
                      {post.platform === "onlyfans" && <OnlyFansIcon size={16} />}
                    </div>
                    <div className="text-xs text-white/60">{post.date}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      post.status === 'published' ? 'bg-green-500/20 text-green-400' :
                      post.status === 'scheduled' ? 'bg-blue-500/20 text-blue-400' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {post.status}
                    </span>
                    <MoreHorizontal className="w-4 h-4 text-white/40" />
                  </div>
                </div>
                
                <p className="text-white mb-3">{post.content}</p>
                
                {post.engagement && (
                  <div className="flex items-center gap-4 text-white/60 text-sm">
                    <span>❤️ {post.engagement.likes}</span>
                    <span>💬 {post.engagement.comments}</span>
                    <span>🔄 {post.engagement.shares}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}