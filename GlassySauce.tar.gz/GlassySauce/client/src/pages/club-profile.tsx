import { useState } from "react";
import { useParams, useLocation, Link } from "wouter";
import { ArrowLeft, Users, TrendingUp, MessageCircle, Star, Share2, MoreHorizontal } from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { TokenPerformanceChart } from "@/components/charts/token-performance-chart";

export default function ClubProfile() {
  const params = useParams();
  const [location, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("activity");
  const [showTradeModal, setShowTradeModal] = useState(false);
  const [tradeType, setTradeType] = useState<'buy' | 'sell'>('buy');
  const [tradeAmount, setTradeAmount] = useState('');
  const [isFollowing, setIsFollowing] = useState(false);
  const { toast } = useToast();

  const clubId = params.clubId;

  // Club data mapping - in real app would fetch by clubId from API
  const getClubById = (id: string) => {
    const clubs: Record<string, any> = {
      '1': {
        id: 1, name: "VM CLUB", creator: "ViolentMagicClub", creatorId: 5, description: "Club Violencia Mágica",
        coverImage: "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        profileImage: "https://images.unsplash.com/photo-1494790108755-2616c0763c62?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
        memberCount: 151, keyPrice: "0.653", floorPrice: "0.854", volume24h: "2.4", priceChange24h: 15.2,
        totalValue: "9653.62", isActive: true, createdAt: "2024-01-15"
      },
      '2': {
        id: 2, name: "BELLA'S ELITE", creator: "BellaThorne", creatorId: 1, description: "Exclusive access to Bella's inner circle",
        coverImage: "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
        memberCount: 2847, keyPrice: "1.234", floorPrice: "1.156", volume24h: "15.4", priceChange24h: 8.7,
        totalValue: "15420.33", isActive: true, createdAt: "2024-01-15"
      },
      '3': {
        id: 3, name: "TANA'S CHAOS", creator: "TanaMongeau", creatorId: 2, description: "Welcome to controlled chaos",
        coverImage: "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        profileImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
        memberCount: 1923, keyPrice: "0.987", floorPrice: "0.892", volume24h: "8.7", priceChange24h: -3.2,
        totalValue: "8756.21", isActive: true, createdAt: "2024-01-15"
      },
      '4': {
        id: 4, name: "AMOURANTH VIP", creator: "Amouranth", creatorId: 3, description: "Premium content and exclusive streams",
        coverImage: "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        profileImage: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
        memberCount: 4521, keyPrice: "2.156", floorPrice: "2.034", volume24h: "28.9", priceChange24h: 22.5,
        totalValue: "28934.44", isActive: true, createdAt: "2024-01-15"
      },
      '5': {
        id: 5, name: "MIA'S SANCTUARY", creator: "MiaKhalifa", creatorId: 4, description: "Safe space for real conversations",
        coverImage: "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        profileImage: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
        memberCount: 3267, keyPrice: "1.789", floorPrice: "1.678", volume24h: "19.8", priceChange24h: 12.1,
        totalValue: "19823.67", isActive: true, createdAt: "2024-01-15"
      }
    };
    return clubs[id] || clubs['1'];
  };

  const clubData = getClubById(clubId || '1');

  const clubMembers = [
    {
      id: 1,
      username: "VM",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616c0763c62?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      isFounder: true,
      lastActive: "2 hours ago",
      message: "Created on el 2009 de la fecha de todo podii itodetez y desde entonces analizamos los cánticos que espera al ponerse que vivimos dentro de un celeticass.",
      keyCount: 15
    },
    {
      id: 2,
      username: "RemiDuck",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      isFounder: false,
      lastActive: "3 hours ago",
      message: "Building the future of Web3 social platforms",
      keyCount: 8
    },
    {
      id: 3,
      username: "ulbre_d JA",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      isFounder: false,
      lastActive: "5 hours ago",
      message: "Caminante del Club 🌟... Hábil Sincronizala 🔮 Player of Life 🎮 ... Investor del Universo 💎 Elite Informador 📊",
      keyCount: 12
    },
    {
      id: 4,
      username: "Kino",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      isFounder: false,
      lastActive: "1 day ago",
      message: "Coordinador financiero y reincorporación. Cada aprendizaje es magia el resto. La 'Hazard financiera' es verse siempre libre. 💰",
      keyCount: 6
    }
  ];

  const handleTrade = () => {
    toast({
      title: tradeType === 'buy' ? "Keys Purchased!" : "Keys Sold!",
      description: `Successfully ${tradeType === 'buy' ? 'bought' : 'sold'} ${tradeAmount} club keys`,
    });
    setShowTradeModal(false);
    setTradeAmount('');
  };

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
    toast({
      title: isFollowing ? "Unfollowed Club" : "Following Club",
      description: isFollowing ? "You're no longer following this club" : "You'll receive updates about this club",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/')}
            className="text-white/70 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
              <Share2 className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Club Profile Header */}
        <GlassCard className="mb-6">
          <div className="p-6">
            <div className="flex items-start space-x-6">
              {/* Club Avatar */}
              <div className="relative">
                <img
                  src={clubData.profileImage}
                  alt={clubData.name}
                  className="w-28 h-28 rounded-2xl object-cover"
                />
                {clubData.isActive && (
                  <div className="absolute -top-2 -right-2 w-4 h-4 bg-green-400 rounded-full border-2 border-white/20"></div>
                )}
              </div>

              {/* Club Info */}
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h1 className="text-2xl font-bold text-white">{clubData.name}</h1>
                  <Badge className="bg-gradient-to-r from-pink-500 to-purple-600 text-white border-0">
                    CLUB
                  </Badge>
                </div>
                <p className="text-white/60 mb-2">@{clubData.creator}</p>
                <p className="text-white/80 text-sm mb-4">{clubData.description}</p>
                
                {/* Club Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-lg font-bold text-white">{clubData.memberCount}</div>
                    <div className="text-xs text-white/60">Members</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-white">{clubData.keyPrice} ETH</div>
                    <div className="text-xs text-white/60">Key Price</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-white">{clubData.volume24h}K</div>
                    <div className="text-xs text-white/60">24h Volume</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-cyan-400">+{clubData.priceChange24h}%</div>
                    <div className="text-xs text-white/60">24h Change</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-3 mt-6">
              <GradientButton
                onClick={() => setLocation(`/chat/club/${clubData.id}`)}
                className="flex items-center space-x-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat</span>
              </GradientButton>
              
              <Dialog open={showTradeModal} onOpenChange={setShowTradeModal}>
                <DialogTrigger asChild>
                  <GradientButton
                    variant="glass"
                    onClick={() => setTradeType('buy')}
                    className="flex items-center space-x-2"
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>Buy Keys</span>
                  </GradientButton>
                </DialogTrigger>
                <DialogContent className="glass-dark border-white/20">
                  <DialogHeader>
                    <DialogTitle className="text-white">Trade Club Keys</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="flex space-x-2">
                      <Button
                        variant={tradeType === 'buy' ? 'default' : 'outline'}
                        onClick={() => setTradeType('buy')}
                        className="flex-1"
                      >
                        Buy
                      </Button>
                      <Button
                        variant={tradeType === 'sell' ? 'default' : 'outline'}
                        onClick={() => setTradeType('sell')}
                        className="flex-1"
                      >
                        Sell
                      </Button>
                    </div>
                    <div>
                      <Label htmlFor="amount" className="text-white">Amount</Label>
                      <Input
                        id="amount"
                        type="number"
                        placeholder="Enter amount"
                        value={tradeAmount}
                        onChange={(e) => setTradeAmount(e.target.value)}
                        className="bg-white/5 border-white/20 text-white"
                      />
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <div className="flex justify-between text-sm">
                        <span className="text-white/70">Price per key:</span>
                        <span className="text-white">{clubData.keyPrice} ETH</span>
                      </div>
                      <div className="flex justify-between text-sm mt-1">
                        <span className="text-white/70">Total:</span>
                        <span className="text-white">
                          {tradeAmount ? (parseFloat(tradeAmount) * parseFloat(clubData.keyPrice)).toFixed(3) : '0.000'} ETH
                        </span>
                      </div>
                    </div>
                    <GradientButton onClick={handleTrade} className="w-full">
                      {tradeType === 'buy' ? 'Buy Keys' : 'Sell Keys'}
                    </GradientButton>
                  </div>
                </DialogContent>
              </Dialog>

              <Button
                variant="outline"
                onClick={handleFollow}
                className="border-white/20 text-white hover:bg-white/5"
              >
                <Star className={`w-4 h-4 mr-2 ${isFollowing ? 'fill-current' : ''}`} />
                {isFollowing ? 'Following' : 'Follow'}
              </Button>
            </div>
          </div>
        </GlassCard>

        {/* Price Chart */}
        <GlassCard className="mb-6">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white">Club Value</h3>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="text-2xl font-bold text-white">{clubData.keyPrice} ETH</div>
                  <div className={`text-sm font-medium ${
                    clubData.priceChange24h > 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {clubData.priceChange24h > 0 ? '+' : ''}{clubData.priceChange24h.toFixed(1)}% (24h)
                  </div>
                  <div className="text-xs text-white/60">Club Trading Value</div>
                </div>
              </div>
            </div>
            <TokenPerformanceChart 
              width={600} 
              height={220} 
              tokenSymbol={clubData.name.replace(' ', '')}
              currentPrice={parseFloat(clubData.keyPrice)}
              changePercent={clubData.priceChange24h}
              variant="detailed"
              showGrid={true}
              timeframe="6M"
              className="w-full"
            />
          </div>
        </GlassCard>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-white/5 border-white/20">
            <TabsTrigger value="activity" className="text-white data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500 data-[state=active]:to-purple-600">
              Activity
            </TabsTrigger>
            <TabsTrigger value="members" className="text-white data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500 data-[state=active]:to-purple-600">
              Members ({clubData.memberCount})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="activity" className="space-y-4">
            <GlassCard>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  {clubMembers.slice(0, 5).map((member) => (
                    <div key={member.id} className="flex items-start space-x-3 p-3 bg-white/5 rounded-lg">
                      <img
                        src={member.avatar}
                        alt={member.username}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-white font-medium">{member.username}</span>
                          {member.isFounder && (
                            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 text-xs">
                              FOUNDER
                            </Badge>
                          )}
                          <span className="text-white/60 text-sm">{member.lastActive}</span>
                        </div>
                        <p className="text-white/80 text-sm mt-1">{member.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </GlassCard>
          </TabsContent>

          <TabsContent value="members" className="space-y-4">
            <GlassCard>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">Club Members</h3>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-white/60" />
                    <span className="text-white/60">{clubData.memberCount} members</span>
                  </div>
                </div>
                <div className="space-y-3">
                  {clubMembers.map((member) => (
                    <div key={member.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors">
                      <div className="flex items-center space-x-3">
                        <img
                          src={member.avatar}
                          alt={member.username}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-white font-medium">{member.username}</span>
                            {member.isFounder && (
                              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 text-xs">
                                FOUNDER
                              </Badge>
                            )}
                          </div>
                          <span className="text-white/60 text-sm">{member.keyCount} keys</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <GradientButton size="sm" variant="glass">
                          Follow
                        </GradientButton>
                        <GradientButton size="sm">
                          Message
                        </GradientButton>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </GlassCard>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}