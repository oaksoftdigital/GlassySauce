import { useState } from "react";
import { useParams, Link } from "wouter";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ArrowLeft, MessageCircle, Key, Share, Users, Trophy, X, HelpCircle } from "lucide-react";
import { TwitterIcon, InstagramIcon, OnlyFansIcon, FansIcon } from "@/components/ui/crypto-icons";
import { useQuery } from "@tanstack/react-query";
import type { Creator } from "@/types";

// Trade Keys Modal Component
function TradeKeysModal({ creator, isOpen, onClose }: { creator: Creator; isOpen: boolean; onClose: () => void }) {
  const [userKeys, setUserKeys] = useState(0);
  const [buyAmount, setBuyAmount] = useState("");
  const [sellAmount, setSellAmount] = useState("");
  
  const keyPrice = parseFloat(creator.currentPrice);
  const sellPrice = keyPrice * 0.9; // 10% selling fee
  
  const handleBuyKey = () => {
    console.log(`Buying key for ${creator.displayName} at ${keyPrice} ETH`);
    // Handle buy logic
    onClose();
  };
  
  const handleSellKey = () => {
    console.log(`Selling key for ${creator.displayName} at ${sellPrice} ETH`);
    // Handle sell logic  
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto bg-slate-900/95 border-slate-700">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-white font-semibold">Trade Keys</DialogTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4 text-white/60" />
          </Button>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Creator Info */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-12 h-12">
                <AvatarImage src={creator.profileImage} />
                <AvatarFallback>{creator.displayName[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-1">
                  <span className="text-white font-medium">{creator.displayName}</span>
                </div>
                <span className="text-white/60 text-sm">You own {userKeys} keys</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-teal-400 font-bold text-lg">{keyPrice.toFixed(3)} ETH</div>
              <div className="text-white/60 text-xs flex items-center gap-1">
                Key price <HelpCircle className="w-3 h-3" />
              </div>
            </div>
          </div>

          {/* Buy Button */}
          <Button 
            onClick={handleBuyKey}
            className="w-full bg-gradient-to-r from-teal-400 to-blue-500 hover:from-teal-500 hover:to-blue-600 text-white font-semibold py-3 rounded-xl"
          >
            Buy a key
          </Button>

          {/* Sell Button */}
          <Button 
            onClick={handleSellKey}
            className="w-full bg-gradient-to-r from-pink-400 to-rose-500 hover:from-pink-500 hover:to-rose-600 text-white font-semibold py-3 rounded-xl"
          >
            Sell a key
          </Button>

          {/* Sell Price */}
          <div className="text-center">
            <span className="text-white/60 text-sm">Sell Price: {sellPrice.toFixed(6)} ETH</span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function CreatorProfile() {
  const { userId } = useParams();
  const [activeTab, setActiveTab] = useState("Clubs");
  const [showTradeModal, setShowTradeModal] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);

  // Creator data mapping - in real app would fetch by userId from API
  const getCreatorById = (id: string): Creator => {
    const creators: Record<string, Creator> = {
      '1': {
        id: 1, userId: 1, displayName: "Bella Thorne", 
        bio: "Actress, singer, and entrepreneur. Building the future of creator economy ✨",
        profileImage: "https://images.unsplash.com/photo-1494790108755-2616c0763c62?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        currentPrice: "0.156", tokenSymbol: "BELLA", holderCount: 8542, totalVolume: "2400", ranking: 1,
        chatMemberCount: 3228, isOnline: false, tokenSupply: "1000000", coverImage: undefined, socialLinks: undefined, createdAt: "2024-01-01"
      },
      '2': {
        id: 2, userId: 2, displayName: "Tana Mongeau",
        bio: "Content creator and podcast host. Chaos coordinator and storyteller 🎭",
        profileImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        currentPrice: "0.089", tokenSymbol: "TANA", holderCount: 6234, totalVolume: "1850", ranking: 2,
        chatMemberCount: 2891, isOnline: true, tokenSupply: "875000", coverImage: undefined, socialLinks: undefined, createdAt: "2024-01-01"
      },
      '3': {
        id: 3, userId: 3, displayName: "Amouranth",
        bio: "Entrepreneur, streamer, and content creator. Building digital empires 💼",
        profileImage: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        currentPrice: "0.234", tokenSymbol: "AMOU", holderCount: 9876, totalVolume: "3200", ranking: 3,
        chatMemberCount: 4521, isOnline: false, tokenSupply: "1200000", coverImage: undefined, socialLinks: undefined, createdAt: "2024-01-01"
      },
      '4': {
        id: 4, userId: 4, displayName: "Mia Khalifa",
        bio: "Sports commentator and social media personality. Authentic conversations only 🗣️",
        profileImage: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        currentPrice: "0.178", tokenSymbol: "MIA", holderCount: 7342, totalVolume: "2100", ranking: 4,
        chatMemberCount: 3267, isOnline: true, tokenSupply: "950000", coverImage: undefined, socialLinks: undefined, createdAt: "2024-01-01"
      },
      '5': {
        id: 5, userId: 5, displayName: "VM",
        bio: "Creador en el 2009 de la Teoría del todo ifotónica, y desde entonces analizamos los cambios que supone el postular que vivimos dentro de un ordenador.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        currentPrice: "0.676", tokenSymbol: "VM", holderCount: 102, totalVolume: "45000", ranking: 5,
        chatMemberCount: 3228, isOnline: false, tokenSupply: "1000", coverImage: undefined, socialLinks: undefined, createdAt: "2024-01-01"
      }
    };
    return creators[id] || creators['1'];
  };

  const creator = getCreatorById(userId || "1");

  // Additional profile data not in schema
  const profileData = {
    username: "@valdeande",
    lastSeen: "3mo ago",
    lastMessage: "33m ago"
  };

  const stats = {
    holders: 102,
    holding: 122,
    followers: 3228,
    following: 156
  };

  const clubs = [
    {
      id: 1,
      name: "VM CLUB",
      symbol: "FT#22700",
      description: "Club Valdeande Magico",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    },
    {
      id: 2,
      name: "Valdeande 3.0.1",
      symbol: "FT#236794",
      description: "Club del futuro tech blockchain",
      image: "https://images.unsplash.com/photo-1518085250887-2f903c200fee?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    }
  ];

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
  };

  const handleChat = () => {
    // Navigate to chat with creator
    console.log("Opening chat with", creator.displayName);
  };

  const handleBuyKey = () => {
    setShowTradeModal(true);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <Link href="/">
            <Button variant="ghost" className="text-white/60 hover:text-white">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
          </Link>
          
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              onClick={handleChat}
              className="text-white/60 hover:text-white flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              Chat
            </Button>
            <Button 
              onClick={handleBuyKey}
              className="bg-gradient-to-r from-teal-400 to-blue-500 hover:from-teal-500 hover:to-blue-600 text-white font-semibold px-6 py-2 rounded-xl flex items-center gap-2"
            >
              <Key className="w-4 h-4" />
              Buy
            </Button>
          </div>
        </div>

        {/* Profile Section */}
        <div className="p-6">
          <div className="flex items-start justify-between mb-6">
            {/* Profile Info */}
            <div className="flex items-start gap-4">
              <Avatar className="w-28 h-28">
                <AvatarImage src={creator.profileImage} />
                <AvatarFallback>{creator.displayName[0]}</AvatarFallback>
              </Avatar>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <h1 className="text-3xl font-bold text-white">{creator.displayName}</h1>
                </div>
                <p className="text-white/60">{profileData.username}</p>
                <p className="text-white/60 text-sm">
                  Last seen {profileData.lastSeen} • Last message sent {profileData.lastMessage}
                </p>
              </div>
            </div>

            {/* Key Price */}
            <div className="text-right">
              <div className="flex items-center gap-1 text-2xl font-bold text-white mb-1">
                <FansIcon size={20} />
                {creator.currentPrice}
              </div>
              <div className="text-white/60 text-sm">Key Price</div>
            </div>
          </div>

          {/* Bio */}
          <p className="text-white mb-6">{creator.bio}</p>

          {/* Follow Button */}
          <Button 
            onClick={handleFollow}
            variant="outline"
            className="w-full border-white/20 text-white hover:bg-white/5 mb-6 py-3"
          >
            {isFollowing ? "Unfollow" : "Unfollow"}
          </Button>

          {/* Action Buttons */}
          <div className="flex items-center gap-4 mb-6">
            <Badge variant="secondary" className="bg-white/10 text-white">
              #1
            </Badge>
            <Button variant="ghost" className="text-white/60 hover:text-white flex items-center gap-2">
              <Share className="w-4 h-4" />
              Share
            </Button>
            <Button variant="ghost" className="text-white/60 hover:text-white flex items-center gap-2">
              <Users className="w-4 h-4" />
              Snapshot holders
            </Button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{stats.holders}</div>
              <div className="text-white/60 text-sm">Holders</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{stats.holding}</div>
              <div className="text-white/60 text-sm">Holding</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{formatNumber(stats.followers)}</div>
              <div className="text-white/60 text-sm">Followers</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{stats.following}</div>
              <div className="text-white/60 text-sm">Following</div>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-white/10 mb-6">
            <div className="flex gap-8">
              {["Clubs", "Activity", "Holders", "Holding", "Followers", "Following"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`pb-3 px-1 text-sm font-medium transition-colors relative ${
                    activeTab === tab
                      ? "text-teal-400"
                      : "text-white/60 hover:text-white"
                  }`}
                >
                  {tab}
                  {activeTab === tab && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-teal-400 to-blue-500" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="space-y-4">
            {activeTab === "Clubs" && (
              <div className="space-y-4">
                {clubs.map((club) => (
                  <GlassCard key={club.id} className="p-4">
                    <div className="flex items-center gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={club.image} />
                        <AvatarFallback>{club.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-semibold text-white">{club.name}</h3>
                        <p className="text-white/60 text-sm">{club.symbol}</p>
                        <p className="text-white/60 text-sm">{club.description}</p>
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}
            
            {activeTab === "Activity" && (
              <div className="text-center py-12">
                <p className="text-white/60">No recent activity</p>
              </div>
            )}
            
            {activeTab === "Holders" && (
              <div className="text-center py-12">
                <p className="text-white/60">Key holders will appear here</p>
              </div>
            )}
            
            {activeTab === "Holding" && (
              <div className="text-center py-12">
                <p className="text-white/60">Holdings will appear here</p>
              </div>
            )}
            
            {activeTab === "Followers" && (
              <div className="text-center py-12">
                <p className="text-white/60">Followers will appear here</p>
              </div>
            )}
            
            {activeTab === "Following" && (
              <div className="text-center py-12">
                <p className="text-white/60">Following will appear here</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Trade Keys Modal */}
      <TradeKeysModal 
        creator={creator}
        isOpen={showTradeModal}
        onClose={() => setShowTradeModal(false)}
      />
    </div>
  );
}