import { useState, useEffect } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { EnhancedCreatorCard } from "@/components/profiles/enhanced-creator-card";
import { ActivityFeed } from "@/components/activity/activity-feed";
import { NotificationPanel } from "@/components/notifications/notification-panel";
import { OnboardingFlow } from "@/components/onboarding/onboarding-flow";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Bell, Sparkles, TrendingUp, Users, Crown } from "lucide-react";
import type { Creator } from "@/types";

export default function Home() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const { data: topCreators, isLoading } = useQuery<Creator[]>({
    queryKey: ['/api/creators/top'],
  });

  const { data: stats } = useQuery<{
    totalVolume: string;
    activeCreators: string;
    tokenHolders: string;
    satisfaction: string;
  }>({
    queryKey: ['/api/stats'],
  });

  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
    if (!hasSeenOnboarding) {
      setTimeout(() => setShowOnboarding(true), 1000);
    }
  }, []);

  const handleCloseOnboarding = () => {
    setShowOnboarding(false);
    localStorage.setItem('hasSeenOnboarding', 'true');
  };

  return (
    <div className="min-h-screen">
      {/* Top Bar with Notifications */}
      <div className="sticky top-0 z-30 glass-dark border-b border-white/10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowNotifications(true)}
              className="relative p-2 glass-dark rounded-xl text-white/70 hover:text-white transition-all"
            >
              <Bell className="w-5 h-5" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-pink-500 rounded-full"></div>
            </button>
          </div>
        </div>
      </div>
      
      {/* Main Dashboard Content */}
      <div className="flex-1 p-6">
        <div className="max-w-7xl mx-auto">
          
          {/* Hero Section */}
          <div className="mb-12">
            <div className="text-center mb-8">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
                Welcome to <span className="gradient-text">Fans.tech</span>
              </h1>
              <p className="text-lg text-white/70 max-w-2xl mx-auto">
                Transform your influence into digital assets with bonding curve mechanics and token-gated communities.
              </p>
            </div>
            
            {/* Quick Actions */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <GradientButton variant="saucy" size="lg" glow>
                <Crown className="mr-2 w-5 h-5" />
                Become a Creator
              </GradientButton>
              <GradientButton variant="glass" size="lg">
                <Sparkles className="mr-2 w-5 h-5" />
                Explore Tokens
              </GradientButton>
            </div>
            
            {/* Platform Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <GlassCard hover className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">
                      ${stats?.totalVolume || '2.4M'}
                    </div>
                    <div className="text-white/60 text-sm">Total Volume</div>
                  </div>
                </div>
              </GlassCard>
              <GlassCard hover className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-purple-500/20 rounded-xl flex items-center justify-center">
                    <Crown className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">
                      {stats?.activeCreators || '3K'}
                    </div>
                    <div className="text-white/60 text-sm">Active Creators</div>
                  </div>
                </div>
              </GlassCard>
              <GlassCard hover className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                    <Users className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">
                      {stats?.tokenHolders || '89K'}
                    </div>
                    <div className="text-white/60 text-sm">Token Holders</div>
                  </div>
                </div>
              </GlassCard>
              <GlassCard hover className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-pink-500/20 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">
                      {stats?.satisfaction || '94%'}
                    </div>
                    <div className="text-white/60 text-sm">Satisfaction</div>
                  </div>
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Main Dashboard Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            
            {/* Featured Creators - Takes up 2 columns */}
            <div className="lg:col-span-2">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-white mb-2">Featured Creators</h2>
                <p className="text-white/60">Top performing creators on the platform</p>
              </div>
              
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[1, 2, 3, 4].map((i) => (
                    <GlassCard key={i} className="h-64 animate-pulse" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {topCreators?.slice(0, 4).map((creator, index) => (
                    <EnhancedCreatorCard key={creator.id} creator={creator} rank={index + 1} />
                  ))}
                </div>
              )}
              
              <div className="mt-6 text-center">
                <Link href="/discover">
                  <GradientButton variant="glass" size="sm">
                    View All Creators
                  </GradientButton>
                </Link>
              </div>
            </div>

            {/* Activity Feed - Takes up 1 column */}
            <div className="lg:col-span-1">
              <ActivityFeed />
            </div>
          </div>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Why Choose Fans.tech?
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <GlassCard hover className="p-8 text-center">
              <div className="w-16 h-16 gradient-saucy rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-coins text-white text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Token Economics</h3>
              <p className="text-white/70">
                Fair bonding curve pricing ensures early supporters are rewarded while maintaining accessibility
              </p>
            </GlassCard>
            
            <GlassCard hover className="p-8 text-center">
              <div className="w-16 h-16 gradient-coral rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-users text-white text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Exclusive Access</h3>
              <p className="text-white/70">
                Token-gated communities give your biggest fans VIP access to premium content and direct interaction
              </p>
            </GlassCard>
            
            <GlassCard hover className="p-8 text-center">
              <div className="w-16 h-16 gradient-purple rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-chart-line text-white text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Analytics & Growth</h3>
              <p className="text-white/70">
                Detailed analytics help you understand your audience and optimize your monetization strategy
              </p>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-4 border-t border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 rounded-full gradient-saucy flex items-center justify-center">
                  <i className="fas fa-fire text-white text-lg"></i>
                </div>
                <span className="text-2xl font-bold text-white">Fans.tech</span>
              </div>
              <p className="text-white/70">Tokenizing influence for the next generation of creators.</p>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Platform</h4>
              <div className="space-y-2">
                <Link href="/discover" className="block text-white/70 hover:text-white transition-colors">
                  Discover
                </Link>
                <Link href="/trading" className="block text-white/70 hover:text-white transition-colors">
                  Trading
                </Link>
                <Link href="/wallet" className="block text-white/70 hover:text-white transition-colors">
                  Wallet
                </Link>
                <Link href="/chat" className="block text-white/70 hover:text-white transition-colors">
                  Communities
                </Link>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <div className="space-y-2">
                <a href="#" className="block text-white/70 hover:text-white transition-colors">
                  Help Center
                </a>
                <a href="#" className="block text-white/70 hover:text-white transition-colors">
                  API Docs
                </a>
                <a href="#" className="block text-white/70 hover:text-white transition-colors">
                  Discord
                </a>
                <a href="#" className="block text-white/70 hover:text-white transition-colors">
                  Contact
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Connect</h4>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 glass rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="w-10 h-10 glass rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all">
                  <i className="fab fa-discord"></i>
                </a>
                <a href="#" className="w-10 h-10 glass rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all">
                  <i className="fab fa-telegram"></i>
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-white/10 mt-12 pt-8 text-center">
            <p className="text-white/50">© 2024 Fans.tech. All rights reserved.</p>
          </div>
        </div>
      </footer>
        </div>
      </div>

      {/* Modals */}
      <OnboardingFlow 
        isOpen={showOnboarding} 
        onClose={handleCloseOnboarding} 
      />
      
      <NotificationPanel 
        isOpen={showNotifications} 
        onClose={() => setShowNotifications(false)} 
      />
    </div>
  );
}
