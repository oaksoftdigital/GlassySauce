import { useState, useEffect } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { 
  Bookmark, 
  MessageCircle, 
  Repeat2, 
  Heart, 
  Share, 
  X,
  BarChart3
} from "lucide-react";

// Mock data matching the home feed posts
const mockFeedPosts = [
  {
    id: 1,
    user: {
      name: "Tya 39% 💎",
      handle: "@tyaoutside",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616c57c7f78?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: true
    },
    content: "Hodling my position 🚀 BTC at $71k! 💪 #HODL #BTC #Bitcoin #cryptocurrency #bullish $BTC",
    timestamp: "2h",
    engagement: {
      comments: 234,
      retweets: 1200,
      likes: 3400
    },
    chart: {
      symbol: "BTC",
      price: "$71,234",
      change: "+3.45%",
      changeValue: "+$2,456"
    }
  },
  {
    id: 2,
    user: {
      name: "coremortgagecapital.eth",
      handle: "@coremortgagecapital",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: false
    },
    content: "Good buy position 📈 BTC at $71k! 💎 #Bitcoin",
    timestamp: "3h",
    engagement: {
      comments: 45,
      retweets: 234,
      likes: 890
    },
    chart: {
      symbol: "BTC",
      price: "$71,456",
      change: "+2.89%",
      changeValue: "+$1,234"
    }
  },
  {
    id: 3,
    user: {
      name: "pleasehelpmechakra.eth",
      handle: "@pleasehelpmechakra",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: false
    },
    content: "Loaded my position 🚀 BTC at $71k! 💪 #Bitcoin",
    timestamp: "5h",
    engagement: {
      comments: 89,
      retweets: 456,
      likes: 1200
    },
    chart: {
      symbol: "BTC", 
      price: "$71,089",
      change: "+1.34%",
      changeValue: "+$891"
    }
  },
  {
    id: 4,
    user: {
      name: "Madi 🎯",
      handle: "@madi",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: true
    },
    content: "Welcome to our new members! 🎉 6873 MEMBERS ON TEAM! 🚀 Get your unique invite code below 👇",
    timestamp: "1d",
    engagement: {
      comments: 167,
      retweets: 892,
      likes: 2100
    },
    special: {
      type: "welcome",
      members: "6873",
      title: "Welcome to our new members"
    }
  }
];

export default function Bookmarks() {
  const [bookmarkedPosts, setBookmarkedPosts] = useState<number[]>([]);

  useEffect(() => {
    // Load bookmarks from localStorage
    const savedBookmarks = localStorage.getItem('bookmarkedPosts');
    if (savedBookmarks) {
      setBookmarkedPosts(JSON.parse(savedBookmarks));
    }
  }, []);

  const removeBookmark = (postId: number) => {
    const newBookmarks = bookmarkedPosts.filter(id => id !== postId);
    setBookmarkedPosts(newBookmarks);
    localStorage.setItem('bookmarkedPosts', JSON.stringify(newBookmarks));
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  const renderChart = () => (
    <div className="w-full h-24 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg flex items-center justify-center relative overflow-hidden">
      <svg viewBox="0 0 200 60" className="w-full h-full">
        <path
          d="M10,50 Q50,20 90,30 T170,15"
          stroke="url(#chartGradient)"
          strokeWidth="2"
          fill="none"
        />
        <defs>
          <linearGradient id="chartGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#3b82f6" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );

  // Filter posts to only show bookmarked ones
  const bookmarkedPostsData = mockFeedPosts.filter(post => bookmarkedPosts.includes(post.id));

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Your Bookmarks</h1>
          <p className="text-white/60">
            Posts you've saved from the social feed
          </p>
        </div>

        {/* Bookmarked Posts */}
        {bookmarkedPostsData.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 mx-auto mb-4 bg-white/5 rounded-full flex items-center justify-center">
              <Bookmark className="w-10 h-10 text-white/40" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No bookmarks yet</h3>
            <p className="text-white/60 mb-6">
              Start bookmarking posts from the social feed to save them here
            </p>
            <GradientButton variant="saucy">
              Explore Feed
            </GradientButton>
          </div>
        ) : (
          <div className="space-y-4">
            {bookmarkedPostsData.map((post) => (
              <div key={post.id} className="glass rounded-xl p-4 hover:bg-white/5 transition-colors">
                {/* Post Header */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <img
                      src={post.user.avatar}
                      alt={post.user.name}
                      className="w-14 h-14 rounded-full object-cover border-2 border-white/10 bg-gray-700"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(post.user.name)}&background=4f46e5&color=fff&size=56`;
                      }}
                    />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-white font-medium">{post.user.name}</span>
                        {post.user.verified && (
                          <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-xs">✓</span>
                          </div>
                        )}
                      </div>
                      <span className="text-white/60 text-sm">{post.user.handle}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-white/60 text-sm">{post.timestamp}</span>
                    <button 
                      onClick={() => removeBookmark(post.id)}
                      className="p-1 hover:bg-white/10 rounded transition-colors"
                    >
                      <X className="w-4 h-4 text-white/60 hover:text-white" />
                    </button>
                  </div>
                </div>

                {/* Post Content */}
                <div className="mb-4">
                  <p className="text-white mb-3">{post.content}</p>
                  
                  {/* Chart for trading posts */}
                  {post.chart && (
                    <div className="glass rounded-lg p-3 mb-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-medium">{post.chart.symbol}</span>
                        <span className="text-green-400 text-sm">{post.chart.change}</span>
                      </div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white text-lg font-bold">{post.chart.price}</span>
                        <span className="text-green-400 text-sm">{post.chart.changeValue}</span>
                      </div>
                      {renderChart()}
                    </div>
                  )}

                  {/* Special welcome post */}
                  {post.special && (
                    <div className="glass rounded-lg p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/20">
                      <div className="text-center">
                        <h3 className="text-white font-bold text-lg mb-2">{post.special.title}</h3>
                        <div className="text-4xl font-bold text-white mb-2">{post.special.members}</div>
                        <div className="text-white/60 text-sm">MEMBERS ON TEAM</div>
                        <div className="mt-4">
                          <GradientButton size="sm" variant="saucy">
                            Get your unique invite code
                          </GradientButton>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Post Actions */}
                <div className="flex items-center justify-between text-white/60">
                  <button className="flex items-center space-x-2 hover:text-blue-400 transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    <span className="text-sm">{formatNumber(post.engagement.comments)}</span>
                  </button>
                  <button className="flex items-center space-x-2 hover:text-green-400 transition-colors">
                    <Repeat2 className="w-4 h-4" />
                    <span className="text-sm">{formatNumber(post.engagement.retweets)}</span>
                  </button>
                  <button className="flex items-center space-x-2 hover:text-red-400 transition-colors">
                    <Heart className="w-4 h-4" />
                    <span className="text-sm">{formatNumber(post.engagement.likes)}</span>
                  </button>
                  <button className="flex items-center space-x-2 text-yellow-400 hover:text-yellow-300 transition-colors">
                    <Bookmark className="w-4 h-4 fill-current" />
                  </button>
                  <button className="flex items-center space-x-2 hover:text-blue-400 transition-colors">
                    <Share className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}