import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  ArrowLeft,
  Copy,
  ExternalLink,
  Twitter,
  Instagram,
  Globe,
  Shield,
  CheckCircle,
  AlertCircle,
  Plus,
  Wallet,
  TrendingUp
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { FansIcon } from "@/components/ui/crypto-icons";

export default function Account() {
  const [isConnectingTwitter, setIsConnectingTwitter] = useState(false);
  const [isConnectingInstagram, setIsConnectingInstagram] = useState(false);
  const [isConnectingOnlyFans, setIsConnectingOnlyFans] = useState(false);
  const { toast } = useToast();

  const userAccount = {
    displayName: "SCM",
    username: "@sikaffycapital",
    walletAddress: "0x7cfe...1de09",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    isVerified: false,
    socialConnections: {
      twitter: {
        connected: false,
        username: null,
        followers: null,
        verified: false
      },
      instagram: {
        connected: false,
        username: null,
        followers: null,
        verified: false
      },
      onlyfans: {
        connected: false,
        username: null,
        subscribers: null,
        verified: false
      }
    },
    tradingFeesEarned: {
      amount: "--",
      symbol: "ETH"
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Wallet address copied to clipboard",
    });
  };

  const connectTwitter = async () => {
    setIsConnectingTwitter(true);
    // Simulate API call
    setTimeout(() => {
      setIsConnectingTwitter(false);
      toast({
        title: "Twitter Connected!",
        description: "Your Twitter account has been verified and connected",
      });
    }, 2000);
  };

  const connectInstagram = async () => {
    setIsConnectingInstagram(true);
    // Simulate API call
    setTimeout(() => {
      setIsConnectingInstagram(false);
      toast({
        title: "Instagram Connected!",
        description: "Your Instagram account has been verified and connected",
      });
    }, 2000);
  };

  const connectOnlyFans = async () => {
    setIsConnectingOnlyFans(true);
    // Simulate API call
    setTimeout(() => {
      setIsConnectingOnlyFans(false);
      toast({
        title: "OnlyFans Connected!",
        description: "Your OnlyFans account has been verified and connected",
      });
    }, 2000);
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="sm" className="text-white/60">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-3xl font-bold text-white">Account</h1>
        </div>

        {/* Profile Section */}
        <GlassCard className="p-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Avatar className="w-16 h-16">
                <AvatarImage src={userAccount.avatar} />
                <AvatarFallback>{userAccount.displayName[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-bold text-white">{userAccount.displayName}</h2>
                  {userAccount.isVerified && (
                    <Shield className="w-5 h-5 text-blue-400" />
                  )}
                </div>
                <p className="text-white/60">{userAccount.username}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-white/60 text-sm font-mono">{userAccount.walletAddress}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(userAccount.walletAddress)}
                    className="p-1"
                  >
                    <Copy className="w-3 h-3 text-white/60" />
                  </Button>
                </div>
              </div>
            </div>
            <Button variant="outline" className="text-white border-white/20 hover:bg-white/10">
              Edit profile
            </Button>
          </div>
        </GlassCard>

        {/* Social Media Connections */}
        <GlassCard className="p-8">
          <h3 className="text-xl font-bold text-white mb-6">Connect Your Social Media</h3>
          <p className="text-white/60 mb-6">
            Connect your social media accounts to verify your influence and unlock higher token values
          </p>

          <div className="space-y-4">
            {/* Twitter Connection */}
            <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <Twitter className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <div className="font-semibold text-white">Twitter</div>
                  <div className="text-white/60 text-sm">
                    {userAccount.socialConnections.twitter.connected 
                      ? `@${userAccount.socialConnections.twitter.username} • ${userAccount.socialConnections.twitter.followers} followers`
                      : "Connect to verify your Twitter following"
                    }
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {userAccount.socialConnections.twitter.connected ? (
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Connected
                  </Badge>
                ) : (
                  <GradientButton
                    variant="saucy"
                    size="sm"
                    onClick={connectTwitter}
                    disabled={isConnectingTwitter}
                  >
                    <Twitter className="w-4 h-4 mr-2" />
                    {isConnectingTwitter ? "Connecting..." : "Verify with Twitter"}
                  </GradientButton>
                )}
              </div>
            </div>

            {/* Instagram Connection */}
            <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-pink-500/20 rounded-full flex items-center justify-center">
                  <Instagram className="w-6 h-6 text-pink-400" />
                </div>
                <div>
                  <div className="font-semibold text-white">Instagram</div>
                  <div className="text-white/60 text-sm">
                    {userAccount.socialConnections.instagram.connected 
                      ? `@${userAccount.socialConnections.instagram.username} • ${userAccount.socialConnections.instagram.followers} followers`
                      : "Connect to verify your Instagram following"
                    }
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {userAccount.socialConnections.instagram.connected ? (
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Connected
                  </Badge>
                ) : (
                  <GradientButton
                    variant="saucy"
                    size="sm"
                    onClick={connectInstagram}
                    disabled={isConnectingInstagram}
                  >
                    <Instagram className="w-4 h-4 mr-2" />
                    {isConnectingInstagram ? "Connecting..." : "Verify with Instagram"}
                  </GradientButton>
                )}
              </div>
            </div>

            {/* OnlyFans Connection */}
            <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center">
                  <Globe className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <div className="font-semibold text-white">OnlyFans</div>
                  <div className="text-white/60 text-sm">
                    {userAccount.socialConnections.onlyfans.connected 
                      ? `@${userAccount.socialConnections.onlyfans.username} • ${userAccount.socialConnections.onlyfans.subscribers} subscribers`
                      : "Connect to verify your OnlyFans profile"
                    }
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {userAccount.socialConnections.onlyfans.connected ? (
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Connected
                  </Badge>
                ) : (
                  <GradientButton
                    variant="saucy"
                    size="sm"
                    onClick={connectOnlyFans}
                    disabled={isConnectingOnlyFans}
                  >
                    <Globe className="w-4 h-4 mr-2" />
                    {isConnectingOnlyFans ? "Connecting..." : "Verify with OnlyFans"}
                  </GradientButton>
                )}
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Trading Earnings */}
        <GlassCard className="p-8">
          <h3 className="text-xl font-bold text-white mb-4">Trading Fees Earned</h3>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-slate-800/50 flex items-center justify-center">
              <FansIcon size={24} />
            </div>
            <div>
              <div className="text-3xl font-bold text-white">
                {userAccount.tradingFeesEarned.amount}
              </div>
              <div className="text-white/60">
                {userAccount.tradingFeesEarned.symbol} earned from trading fees
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Wallet Connection */}
        <GlassCard className="p-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-white mb-2">Wallet Connected</h3>
              <p className="text-white/60">Your wallet is connected and ready for trading</p>
            </div>
            <Badge variant="outline" className="text-green-400 border-green-400">
              <Wallet className="w-3 h-3 mr-1" />
              Connected
            </Badge>
          </div>
        </GlassCard>

        {/* Benefits Section */}
        <GlassCard className="p-8 bg-gradient-to-br from-teal-500/10 to-purple-500/10">
          <h3 className="text-xl font-bold text-white mb-4">Verification Benefits</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-white">Higher token bonding curve prices</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-white">Verified creator badge</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-white">Priority in search and discovery</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-white">Access to exclusive creator tools</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-white">Higher referral commission rates</span>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
}