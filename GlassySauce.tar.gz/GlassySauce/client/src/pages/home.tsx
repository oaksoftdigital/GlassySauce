import { useState, useEffect } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { EnhancedCreatorCard } from "@/components/profiles/enhanced-creator-card";
import { ActivityFeed } from "@/components/activity/activity-feed";
import { NotificationPanel } from "@/components/notifications/notification-panel";
import { OnboardingFlow } from "@/components/onboarding/onboarding-flow";
import { DynamicActionCarousel } from "@/components/widgets/dynamic-action-carousel";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Bell, TrendingUp, Users, Crown, BarChart3, MessageCircle, Share, Heart, Repeat2, Eye, Bookmark, ChevronDown, ImageIcon, Video, Mic, Calendar, Globe, Search } from "lucide-react";
import { TwitterIcon, InstagramIcon, OnlyFansIcon, FansIcon } from "@/components/ui/crypto-icons";
import { TokenPerformanceChart } from "@/components/charts/token-performance-chart";
import type { Creator } from "@/types";

// Mock data for social feed posts
const mockFeedPosts = [
  {
    id: 1,
    user: {
      name: "Tya 39% 💎",
      handle: "@tyaoutside",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616c57c7f78?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=400&q=80",
      verified: true
    },
    content: "Just launched my new club! 🚀 Join the exclusive community for premium content 💪 #ClubLaunch #Community",
    timestamp: "2h",
    engagement: {
      comments: 234,
      retweets: 1200,
      likes: 3400
    },
    chart: {
      symbol: "TYA",
      price: "0.234 ETH",
      change: "+12.45%",
      changeValue: "+0.026 ETH"
    }
  },
  {
    id: 2,
    user: {
      name: "coremortgagecapital.eth",
      handle: "@coremortgagecapital",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: false
    },
    content: "My exclusive club is gaining momentum! 📈 Member perks getting better every day 💎 #ClubGrowth",
    timestamp: "3h",
    engagement: {
      comments: 45,
      retweets: 234,
      likes: 890
    },
    chart: {
      symbol: "CORE",
      price: "0.156 ETH",
      change: "+8.89%",
      changeValue: "+0.013 ETH"
    }
  },
  {
    id: 3,
    user: {
      name: "pleasehelpmechakra.eth",
      handle: "@pleasehelpmechakra",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: false
    },
    content: "Expanding my club offerings! 🚀 New tier benefits launching soon 💪 #ClubExpansion",
    timestamp: "5h",
    engagement: {
      comments: 89,
      retweets: 456,
      likes: 1200
    },
    chart: {
      symbol: "CHAKRA", 
      price: "0.089 ETH",
      change: "+6.34%",
      changeValue: "+0.005 ETH"
    }
  },
  {
    id: 4,
    user: {
      name: "Madi 🎯",
      handle: "@madi",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      verified: true
    },
    content: "Welcome to our new members! 🎉 6873 MEMBERS ON TEAM! 🚀 Get your unique invite code below 👇",
    timestamp: "1d",
    engagement: {
      comments: 167,
      retweets: 892,
      likes: 2100
    },
    special: {
      type: "welcome",
      members: "6873",
      title: "Welcome to our new members"
    }
  }
];

export default function Home() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [activeTab, setActiveTab] = useState('All feed');
  const [bookmarkedPosts, setBookmarkedPosts] = useState<number[]>([]);
  const [postContent, setPostContent] = useState("");
  const [showPlatformDropdown, setShowPlatformDropdown] = useState(false);
  const [selectedPlatforms, setSelectedPlatforms] = useState(['fans']);
  const [allPlatformsEnabled, setAllPlatformsEnabled] = useState(false);

  const { data: topCreators, isLoading } = useQuery<Creator[]>({
    queryKey: ['/api/creators/top'],
  });

  const { data: stats } = useQuery<{
    totalVolume: string;
    activeCreators: string;
    tokenHolders: string;
    satisfaction: string;
  }>({
    queryKey: ['/api/stats'],
  });

  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
    if (!hasSeenOnboarding) {
      setTimeout(() => setShowOnboarding(true), 1000);
    }
    
    // Load bookmarks from localStorage
    const savedBookmarks = localStorage.getItem('bookmarkedPosts');
    if (savedBookmarks) {
      setBookmarkedPosts(JSON.parse(savedBookmarks));
    }
  }, []);

  const handleCloseOnboarding = () => {
    setShowOnboarding(false);
    localStorage.setItem('hasSeenOnboarding', 'true');
  };

  const toggleBookmark = (postId: number) => {
    const newBookmarks = bookmarkedPosts.includes(postId)
      ? bookmarkedPosts.filter(id => id !== postId)
      : [...bookmarkedPosts, postId];
    
    setBookmarkedPosts(newBookmarks);
    localStorage.setItem('bookmarkedPosts', JSON.stringify(newBookmarks));
  };

  const togglePlatform = (platform: string) => {
    if (platform === 'all') {
      setAllPlatformsEnabled(!allPlatformsEnabled);
      if (!allPlatformsEnabled) {
        setSelectedPlatforms(['fans', 'twitter', 'instagram', 'onlyfans', 'tiktok', 'youtube']);
      } else {
        setSelectedPlatforms(['fans']);
      }
    } else {
      setSelectedPlatforms(prev => 
        prev.includes(platform) 
          ? prev.filter(p => p !== platform)
          : [...prev, platform]
      );
    }
  };

  const handlePost = () => {
    if (postContent.trim()) {
      // Handle posting logic here
      console.log('Posting to platforms:', selectedPlatforms);
      console.log('Content:', postContent);
      setPostContent("");
      setShowPlatformDropdown(false);
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };



  return (
    <div className="min-h-screen">
      {/* Main Feed Layout */}
      <div className="flex-1 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
          
          {/* Main Feed - 2 columns */}
          <div className="lg:col-span-2">
            {/* Cross-Platform Post Composer */}
            <div className="glass rounded-xl p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <h3 className="text-white text-lg font-semibold">Post</h3>
                  <div className="h-1 w-12 bg-blue-500 rounded-full"></div>
                </div>
              </div>

              {/* Platform Selection */}
              <div className="flex items-center gap-3 mb-4">
                <span className="text-white/60 text-sm">Post on:</span>
                <div className="flex items-center gap-2">
                  <FansIcon size={20} />
                  <button 
                    onClick={() => setShowPlatformDropdown(!showPlatformDropdown)}
                    className="flex items-center gap-2 px-3 py-1 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
                  >
                    <span className="text-white/80 text-sm">Add Platform</span>
                    <ChevronDown className="w-4 h-4 text-white/60" />
                  </button>
                </div>
              </div>

              {/* Platform Dropdown */}
              {showPlatformDropdown && (
                <div className="bg-gray-900 rounded-lg p-4 mb-4 border border-gray-700">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-white text-sm font-medium">All connected platforms</span>
                      <button 
                        onClick={() => togglePlatform('all')}
                        className={`w-12 h-6 rounded-full transition-colors ${
                          allPlatformsEnabled ? 'bg-blue-500' : 'bg-gray-600'
                        }`}
                      >
                        <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                          allPlatformsEnabled ? 'translate-x-6' : 'translate-x-0.5'
                        }`}></div>
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <FansIcon size={20} />
                        <span className="text-white text-sm">0xPPL</span>
                      </div>
                      <button 
                        onClick={() => togglePlatform('fans')}
                        className={`w-12 h-6 rounded-full transition-colors ${
                          selectedPlatforms.includes('fans') ? 'bg-blue-500' : 'bg-gray-600'
                        }`}
                      >
                        <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                          selectedPlatforms.includes('fans') ? 'translate-x-6' : 'translate-x-0.5'
                        }`}></div>
                      </button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <TwitterIcon size={20} />
                        <span className="text-white text-sm">Twitter</span>
                      </div>
                      <span className="text-blue-400 text-sm cursor-pointer hover:text-blue-300">Connect</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <InstagramIcon size={20} />
                        <span className="text-white text-sm">Instagram</span>
                      </div>
                      <span className="text-blue-400 text-sm cursor-pointer hover:text-blue-300">Connect</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <OnlyFansIcon size={20} />
                        <span className="text-white text-sm">OnlyFans</span>
                      </div>
                      <span className="text-blue-400 text-sm cursor-pointer hover:text-blue-300">Connect</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Post Content */}
              <div className="flex items-start gap-4">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
                  alt="Profile"
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="flex-1">
                  <textarea
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    placeholder="Share the next big thing..."
                    className="w-full bg-transparent text-white placeholder-white/50 resize-none border-none outline-none text-lg h-24"
                  />
                  
                  {/* Media & Actions */}
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center gap-4">
                      <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                        <ImageIcon className="w-5 h-5 text-white/60" />
                      </button>
                      <button className="text-white/60 hover:text-white text-sm font-medium">GIF</button>
                      <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                        <Video className="w-5 h-5 text-white/60" />
                      </button>
                      <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                        <Calendar className="w-5 h-5 text-white/60" />
                      </button>
                      <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                        <Globe className="w-5 h-5 text-white/60" />
                      </button>
                    </div>
                    <div className="flex items-center gap-3">
                      <button className="text-white/60 hover:text-white text-sm font-medium">
                        Discard
                      </button>
                      <GradientButton
                        variant="saucy"
                        onClick={handlePost}
                        disabled={!postContent.trim()}
                      >
                        Post
                      </GradientButton>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Feed Header */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-6">
                  <button
                    onClick={() => setActiveTab('All feed')}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      activeTab === 'All feed'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'text-white/60 hover:text-white'
                    }`}
                  >
                    All feed
                  </button>
                  <button
                    onClick={() => setActiveTab('Posts')}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      activeTab === 'Posts'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'text-white/60 hover:text-white'
                    }`}
                  >
                    Posts
                  </button>
                  <button
                    onClick={() => setActiveTab('Transactions')}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      activeTab === 'Transactions'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'text-white/60 hover:text-white'
                    }`}
                  >
                    Transactions
                  </button>
                  <button
                    onClick={() => setActiveTab('Trending')}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      activeTab === 'Trending'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'text-white/60 hover:text-white'
                    }`}
                  >
                    Trending
                  </button>
                </div>
                
                {/* Discover and Bookmark buttons */}
                <div className="flex items-center space-x-3">
                  <Link href="/discover">
                    <button className="flex items-center space-x-2 px-4 py-2 rounded-lg font-medium text-white/60 hover:text-white hover:bg-white/5 transition-all">
                      <Search className="w-4 h-4" />
                      <span>Discover</span>
                    </button>
                  </Link>
                  <Link href="/bookmarks">
                    <button className="flex items-center space-x-2 px-4 py-2 rounded-lg font-medium text-white/60 hover:text-white hover:bg-white/5 transition-all">
                      <Bookmark className="w-4 h-4" />
                      <span>Bookmarks</span>
                    </button>
                  </Link>
                </div>
              </div>
              

            </div>

            {/* Feed Posts */}
            <div className="space-y-4">
              {mockFeedPosts.map((post) => (
                <div key={post.id} className="glass rounded-xl p-4 hover:bg-white/5 transition-colors">
                  {/* Post Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <img
                        src={post.user.avatar}
                        alt={post.user.name}
                        className="w-14 h-14 rounded-full object-cover border-2 border-white/10 bg-gray-700"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(post.user.name)}&background=4f46e5&color=fff&size=56`;
                        }}
                      />
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-white font-medium">{post.user.name}</span>
                          {post.user.verified && (
                            <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                              <span className="text-white text-xs">✓</span>
                            </div>
                          )}
                        </div>
                        <span className="text-white/60 text-sm">{post.user.handle}</span>
                      </div>
                    </div>
                    <span className="text-white/60 text-sm">{post.timestamp}</span>
                  </div>

                  {/* Post Content */}
                  <div className="mb-4">
                    <p className="text-white mb-3">{post.content}</p>
                    
                    {/* Chart for profile value posts */}
                    {post.chart && (
                      <div className="glass rounded-lg p-4 mb-3">
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-white font-bold">{post.chart.symbol} Club</span>
                          <span className="text-green-400 text-sm font-medium">{post.chart.change}</span>
                        </div>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-white text-xl font-bold">{post.chart.price}</span>
                          <span className="text-green-400 text-sm font-medium">{post.chart.changeValue}</span>
                        </div>
                        <div className="text-xs text-white/60 mb-3">Club Trading Value</div>
                        <TokenPerformanceChart 
                          width={280} 
                          height={120} 
                          tokenSymbol={post.chart.symbol}
                          currentPrice={parseFloat(post.chart.price.replace('$', ''))}
                          changePercent={parseFloat(post.chart.change.replace('%', '').replace('+', ''))}
                          variant="compact"
                          showPrice={false}
                          timeframe="1D"
                        />
                      </div>
                    )}

                    {/* Special welcome post */}
                    {post.special && (
                      <div className="glass rounded-lg p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/20">
                        <div className="text-center">
                          <h3 className="text-white font-bold text-lg mb-2">{post.special.title}</h3>
                          <div className="text-4xl font-bold text-white mb-2">{post.special.members}</div>
                          <div className="text-white/60 text-sm">MEMBERS ON TEAM</div>
                          <div className="mt-4">
                            <GradientButton size="sm" variant="saucy">
                              Get your unique invite code
                            </GradientButton>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Post Actions */}
                  <div className="flex items-center justify-between text-white/60">
                    <button className="flex items-center space-x-2 hover:text-blue-400 transition-colors">
                      <MessageCircle className="w-4 h-4" />
                      <span className="text-sm">{formatNumber(post.engagement.comments)}</span>
                    </button>
                    <button className="flex items-center space-x-2 hover:text-green-400 transition-colors">
                      <Repeat2 className="w-4 h-4" />
                      <span className="text-sm">{formatNumber(post.engagement.retweets)}</span>
                    </button>
                    <button className="flex items-center space-x-2 hover:text-red-400 transition-colors">
                      <Heart className="w-4 h-4" />
                      <span className="text-sm">{formatNumber(post.engagement.likes)}</span>
                    </button>
                    <button 
                      onClick={() => toggleBookmark(post.id)}
                      className={`flex items-center space-x-2 transition-colors ${
                        bookmarkedPosts.includes(post.id) 
                          ? 'text-yellow-400 hover:text-yellow-300' 
                          : 'hover:text-yellow-400'
                      }`}
                    >
                      <Bookmark className={`w-4 h-4 ${bookmarkedPosts.includes(post.id) ? 'fill-current' : ''}`} />
                    </button>
                    <button className="flex items-center space-x-2 hover:text-blue-400 transition-colors">
                      <Share className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Sidebar - 1 column */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              {/* Top Holdings Widget */}
              <div className="glass rounded-xl p-4">
                <h3 className="text-white font-semibold mb-4">Top Holdings</h3>
                <div className="space-y-3">
                  {topCreators?.slice(0, 6).map((creator, index) => (
                    <div key={creator.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <img
                          src={creator.displayName === "Bella Thorne" 
                            ? "https://images.unsplash.com/photo-1494790108755-2616c57c7f78?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
                            : "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
                          }
                          alt={creator.displayName}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div>
                          <div className="text-white text-sm font-medium">{creator.displayName}</div>
                          <div className="text-white/60 text-xs">{creator.tokenSymbol}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-white text-sm font-medium">$0.{(Math.random() * 100).toFixed(0)}</div>
                        <div className="text-green-400 text-xs">+{(Math.random() * 10).toFixed(1)}%</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dynamic Action Carousel */}
              <DynamicActionCarousel />
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <OnboardingFlow 
        isOpen={showOnboarding} 
        onClose={handleCloseOnboarding} 
      />
      
      <NotificationPanel 
        isOpen={showNotifications} 
        onClose={() => setShowNotifications(false)} 
      />
    </div>
  );
}