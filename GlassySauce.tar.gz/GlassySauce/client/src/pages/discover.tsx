import { useState } from "react";
import { Link } from "wouter";
import { GlassCard } from "@/components/ui/glass-card";
import { Search, RefreshCw } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Creator } from "@/types";

export default function Discover() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("rankings");

  const { data: creators, isLoading } = useQuery<Creator[]>({
    queryKey: ['/api/creators'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen p-6">
        <div className="max-w-6xl mx-auto">
          {/* Loading Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="h-8 bg-white/10 rounded-lg w-32 animate-pulse"></div>
            <div className="h-12 bg-white/10 rounded-lg w-80 animate-pulse"></div>
          </div>
          
          {/* Loading Tabs */}
          <div className="flex items-center gap-8 mb-6">
            <div className="h-6 bg-white/10 rounded w-24 animate-pulse"></div>
            <div className="h-6 bg-white/10 rounded w-20 animate-pulse"></div>
          </div>
          
          {/* Loading Media Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="glass rounded-2xl overflow-hidden">
                <div className="aspect-square bg-white/10 animate-pulse"></div>
                <div className="p-6">
                  <div className="h-6 bg-white/10 rounded w-3/4 mb-2 animate-pulse"></div>
                  <div className="h-4 bg-white/10 rounded w-1/2 mb-4 animate-pulse"></div>
                  <div className="flex gap-4">
                    <div className="h-3 bg-white/10 rounded w-16 animate-pulse"></div>
                    <div className="h-3 bg-white/10 rounded w-20 animate-pulse"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Filter creators based on search query
  const filteredCreators = creators?.filter(creator =>
    creator.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-white">Discover</h1>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
            <input
              type="text"
              placeholder="Find friends or clubs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-80 pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-pink-500/50"
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-8 mb-6">
          <button
            onClick={() => setActiveTab("rankings")}
            className={`text-lg font-medium pb-2 border-b-2 transition-colors ${
              activeTab === "rankings"
                ? "text-white border-cyan-400"
                : "text-white/60 border-transparent hover:text-white"
            }`}
          >
            Rankings
          </button>
          <button
            onClick={() => setActiveTab("recent")}
            className={`text-lg font-medium pb-2 border-b-2 transition-colors ${
              activeTab === "recent"
                ? "text-white border-cyan-400"
                : "text-white/60 border-transparent hover:text-white"
            }`}
          >
            Recent
          </button>
          <button className="ml-auto text-white/60 hover:text-white transition-colors">
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>

        {/* Creator Media Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCreators.map((creator, index) => (
            <Link key={creator.id} href={`/creator/${creator.userId}`}>
              <div className="glass rounded-2xl overflow-hidden hover:bg-white/5 transition-all duration-300 cursor-pointer group">
                {/* Large Profile Image */}
                <div className="relative aspect-square">
                  {creator.profileImage ? (
                    <img
                      src={creator.profileImage}
                      alt={creator.displayName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <img
                      src={creator.displayName === "Bella Thorne" 
                        ? "https://images.unsplash.com/photo-1494790108755-2616c57c7f78?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                        : creator.displayName === "Tana Mongeau"
                        ? "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                        : creator.displayName === "Amouranth"
                        ? "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                        : creator.displayName === "Mia Khalifa"
                        ? "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                        : creator.displayName === "Pokimane"
                        ? "https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                        : creator.displayName === "Corinna Kopf"
                        ? "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                        : creator.displayName === "Lana Rhoades"
                        ? "https://images.unsplash.com/photo-1504439468489-c8920d796a29?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                        : creator.displayName === "Riley Reid"
                        ? "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                        : "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
                      }
                      alt={creator.displayName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  )}
                  
                  {/* Rank Badge */}
                  <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm rounded-full w-12 h-12 flex items-center justify-center border-2 border-white/20">
                    <span className="text-white font-bold text-sm">#{index + 1}</span>
                  </div>
                  
                  {/* Status Indicator */}
                  <div className="absolute top-4 right-4 bg-green-500/90 backdrop-blur-sm rounded-full w-4 h-4 flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  </div>
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Hover Action Buttons */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="flex space-x-3">
                      <button className="bg-white/20 backdrop-blur-sm rounded-full p-3 hover:bg-white/30 transition-colors">
                        <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                          <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                        </svg>
                      </button>
                      <button className="bg-cyan-500/80 backdrop-blur-sm rounded-full p-3 hover:bg-cyan-500 transition-colors">
                        <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Creator Info */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-white font-bold text-xl group-hover:text-cyan-400 transition-colors">
                      {creator.displayName}
                    </h3>
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <span className="text-green-400 text-sm font-medium">Active</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-white/60 text-sm mb-4">
                    <span>{creator.chatMemberCount} members</span>
                    <span>Price: {parseFloat(creator.currentPrice).toFixed(1)} $FRIEND</span>
                  </div>
                  
                  {/* Stats Bar */}
                  <div className="flex items-center gap-4 text-xs text-white/50">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                      <span>24h: +{(Math.random() * 20).toFixed(1)}%</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                      <span>Vol: {(Math.random() * 1000).toFixed(0)}k</span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}

          {filteredCreators.length === 0 && !isLoading && (
            <div className="col-span-full text-center py-16">
              <div className="w-20 h-20 mx-auto mb-4 bg-white/5 rounded-full flex items-center justify-center">
                <Search className="w-10 h-10 text-white/40" />
              </div>
              <div className="text-white/60 text-lg">No creators found</div>
              <div className="text-white/40 text-sm mt-2">
                {searchQuery ? "Try a different search term" : "Check back later for new creators"}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}