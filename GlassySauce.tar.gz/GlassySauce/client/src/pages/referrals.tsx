import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { 
  UserPlus, 
  Copy, 
  Users, 
  TrendingUp, 
  Award,
  Plus,
  Mail,
  Link as LinkIcon,
  Twitter,
  MessageCircle,
  Instagram,
  DollarSign,
  CheckCircle,
  X,
  Coins,
  Percent,
  Calendar,
  Gift
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Referrals() {
  const [referralCode, setReferralCode] = useState("FANS-VIP-2025");
  const [inviteLink, setInviteLink] = useState("https://fans.tech/join/FANS-VIP-2025");
  const [showWelcomeModal, setShowWelcomeModal] = useState(true);
  const [hasReferralLink, setHasReferralLink] = useState(false);
  const { toast } = useToast();

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${type} copied to clipboard`,
    });
  };

  const createReferralLink = () => {
    setHasReferralLink(true);
    setShowWelcomeModal(false);
    toast({
      title: "Success!",
      description: "Your referral link has been created and is ready to share",
    });
  };

  const referralStats = {
    invitedMembers: 0,
    totalNetworth: "$0",
    referralRank: "-",
    totalEarnings: "$0",
    pendingRewards: "$0",
    claimableAmount: "$0"
  };

  const currentVolume = {
    trading: "0 ETH",
    tokenCreated: false
  };

  const shareOptions = [
    { name: "Email", icon: Mail, color: "bg-blue-500" },
    { name: "Twitter", icon: Twitter, color: "bg-blue-400" },
    { name: "Instagram", icon: Instagram, color: "bg-pink-500" },
    { name: "Message", icon: MessageCircle, color: "bg-green-500" },
  ];

  const referralTiers = [
    {
      name: "Bronze",
      minReferrals: 1,
      commission: "5%",
      bonus: "$10",
      color: "from-amber-600 to-amber-800"
    },
    {
      name: "Silver", 
      minReferrals: 10,
      commission: "7.5%",
      bonus: "$50",
      color: "from-gray-400 to-gray-600"
    },
    {
      name: "Gold",
      minReferrals: 25,
      commission: "10%", 
      bonus: "$150",
      color: "from-yellow-400 to-yellow-600"
    },
    {
      name: "Platinum", 
      minReferrals: 50,
      commission: "15%",
      bonus: "$500",
      color: "from-purple-400 to-purple-600"
    }
  ];

  return (
    <>
      {/* Welcome Modal */}
      <Dialog open={showWelcomeModal} onOpenChange={setShowWelcomeModal}>
        <DialogContent className="max-w-2xl glass-dark border-white/20">
          <DialogHeader className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-r from-teal-500 to-purple-500 rounded-2xl flex items-center justify-center">
                <UserPlus className="w-8 h-8 text-white" />
              </div>
              <div>
                <DialogTitle className="text-3xl font-bold text-white">Join the Fans Team!</DialogTitle>
                <DialogDescription className="text-white/70 text-lg mt-2">
                  Earn rewards by bringing creators to the platform
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          <div className="space-y-6">
            {/* Earning Breakdown */}
            <div className="bg-slate-800/30 rounded-2xl p-6 space-y-4">
              <h3 className="text-xl font-bold text-white mb-4">When you invite someone, you earn:</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-teal-500/20 to-blue-500/20 rounded-xl">
                  <div className="w-12 h-12 bg-teal-500 rounded-full flex items-center justify-center">
                    <Coins className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">150 Tokens</div>
                    <div className="text-white/70 text-sm">When they create a Club</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl">
                  <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                    <Percent className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">15%</div>
                    <div className="text-white/70 text-sm">Of their trading fees for 6 months</div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-green-500/20 to-teal-500/20 rounded-xl">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <Gift className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-xl font-bold text-white">They get 30% fee discount</div>
                  <div className="text-white/70 text-sm">For a full year</div>
                </div>
              </div>
            </div>

            {/* Current Volume */}
            <div className="bg-slate-900/50 rounded-2xl p-6">
              <h4 className="text-lg font-bold text-white mb-4">Current Volume:</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-white/70">Trading:</span>
                  <span className="text-white font-semibold">{currentVolume.trading}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white/70">Token:</span>
                  <span className="text-white font-semibold">
                    {currentVolume.tokenCreated ? "Created" : "Not created"}
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                variant="outline"
                onClick={() => setShowWelcomeModal(false)}
                className="flex-1 border-white/20 text-white hover:bg-white/10"
              >
                Learn more
              </Button>
              <GradientButton
                onClick={createReferralLink}
                variant="saucy"
                className="flex-1 text-lg font-semibold py-3"
              >
                Create my referral link
              </GradientButton>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <div className="min-h-screen p-6 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-purple-500 rounded-2xl flex items-center justify-center">
              <UserPlus className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white">Refer Friends</h1>
              <p className="text-white/60">Earn rewards by bringing creators to Fans.tech</p>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto space-y-8">
          {hasReferralLink ? (
            <>
              {/* Main Referral Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Send Invite Section */}
                <GlassCard className="p-8 space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h2 className="text-2xl font-bold text-white mb-2">Send an invite to your friends</h2>
                      <p className="text-white/70 mb-6">
                        Use this link to invite awesome people to Fans.tech. Trusting you to bring great folks to our app.
                      </p>
                      
                      {/* Referral Code */}
                      <div className="space-y-4">
                        <div>
                          <label className="block text-white/70 text-sm font-medium mb-2">Your Referral Code</label>
                          <div className="flex gap-2">
                            <Input 
                              value={referralCode}
                              readOnly
                              className="bg-slate-800/50 border-slate-700 text-white"
                            />
                            <Button
                              onClick={() => copyToClipboard(referralCode, "Referral code")}
                              className="bg-gradient-to-r from-teal-500 to-purple-500 hover:opacity-90"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-white/70 text-sm font-medium mb-2">Invite Link</label>
                          <div className="flex gap-2">
                            <Input 
                              value={inviteLink}
                              readOnly
                              className="bg-slate-800/50 border-slate-700 text-white"
                            />
                            <Button
                              onClick={() => copyToClipboard(inviteLink, "Invite link")}
                              className="bg-gradient-to-r from-teal-500 to-purple-500 hover:opacity-90"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>

                      {/* Share Options */}
                      <div className="grid grid-cols-2 gap-3 mt-6">
                        {shareOptions.map((option) => {
                          const Icon = option.icon;
                          return (
                            <Button
                              key={option.name}
                              variant="outline"
                              className={`${option.color} text-white border-0 hover:opacity-90 transition-opacity`}
                            >
                              <Icon className="w-4 h-4 mr-2" />
                              {option.name}
                            </Button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </GlassCard>

                {/* Illustration Card */}
                <GlassCard className="p-8 flex items-center justify-center bg-gradient-to-br from-teal-500/10 to-purple-500/10">
                  <div className="text-center space-y-6">
                    <div className="w-32 h-32 bg-gradient-to-r from-teal-500 to-purple-500 rounded-full flex items-center justify-center mx-auto">
                      <UserPlus className="w-16 h-16 text-white" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-2">Grow Together</h3>
                      <p className="text-white/70">
                        Help creators discover the power of tokenizing their influence while earning rewards
                      </p>
                    </div>
                  </div>
                </GlassCard>
              </div>

              {/* Invite Summary Stats */}
              <GlassCard className="p-8">
                <h3 className="text-2xl font-bold text-white mb-6">Invite Summary</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Invited Members */}
                  <div className="text-center space-y-3">
                    <div className="w-16 h-16 bg-slate-800/50 rounded-2xl flex items-center justify-center mx-auto">
                      <Users className="w-8 h-8 text-teal-400" />
                    </div>
                    <div className="text-4xl font-bold text-white">{referralStats.invitedMembers}</div>
                    <div className="text-white/60 text-sm">INVITED MEMBERS</div>
                  </div>

                  {/* Total Networth */}
                  <div className="text-center space-y-3">
                    <div className="w-16 h-16 bg-slate-800/50 rounded-2xl flex items-center justify-center mx-auto">
                      <TrendingUp className="w-8 h-8 text-purple-400" />
                    </div>
                    <div className="text-4xl font-bold text-white">{referralStats.totalNetworth}</div>
                    <div className="text-white/60 text-sm">TOTAL NETWORTH OF INVITED</div>
                  </div>

                  {/* Referral Rank */}
                  <div className="text-center space-y-3">
                    <div className="w-16 h-16 bg-slate-800/50 rounded-2xl flex items-center justify-center mx-auto">
                      <Award className="w-8 h-8 text-yellow-400" />
                    </div>
                    <div className="text-4xl font-bold text-white">{referralStats.referralRank}</div>
                    <div className="text-white/60 text-sm">REFERRAL RANK</div>
                  </div>
                </div>
              </GlassCard>

              {/* Earnings & Rewards */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Current Earnings */}
                <GlassCard className="p-8 space-y-6">
                  <h3 className="text-2xl font-bold text-white">Your Earnings</h3>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center py-3 border-b border-white/10">
                      <span className="text-white/70">Total Earned</span>
                      <span className="text-2xl font-bold text-teal-400">{referralStats.totalEarnings}</span>
                    </div>
                    
                    <div className="flex justify-between items-center py-3 border-b border-white/10">
                      <span className="text-white/70">Pending Rewards</span>
                      <span className="text-xl font-semibold text-yellow-400">{referralStats.pendingRewards}</span>
                    </div>
                    
                    <div className="flex justify-between items-center py-3">
                      <span className="text-white/70">Available to Claim</span>
                      <span className="text-xl font-semibold text-green-400">{referralStats.claimableAmount}</span>
                    </div>
                  </div>

                  <GradientButton variant="saucy" className="w-full py-3 text-lg font-semibold">
                    <DollarSign className="w-5 h-5 mr-2" />
                    Claim Rewards
                  </GradientButton>
                </GlassCard>

                {/* Referral Tiers */}
                <GlassCard className="p-8 space-y-6">
                  <h3 className="text-2xl font-bold text-white">Referral Tiers</h3>
                  
                  <div className="space-y-4">
                    {referralTiers.map((tier, index) => (
                      <div key={tier.name} className="relative">
                        <div className={`p-4 rounded-xl bg-gradient-to-r ${tier.color} bg-opacity-20 border border-white/10`}>
                          <div className="flex justify-between items-center">
                            <div>
                              <h4 className="font-bold text-white">{tier.name}</h4>
                              <p className="text-white/70 text-sm">{tier.minReferrals}+ referrals</p>
                            </div>
                            <div className="text-right">
                              <div className="text-white font-semibold">{tier.commission}</div>
                              <div className="text-white/70 text-sm">+ {tier.bonus} bonus</div>
                            </div>
                          </div>
                        </div>
                        {index === 0 && (
                          <div className="absolute -top-2 -right-2">
                            <Badge className="bg-teal-500 text-white">Next Goal</Badge>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </div>
            </>
          ) : (
            <div className="text-center space-y-8">
              <GlassCard className="p-12 max-w-2xl mx-auto">
                <div className="space-y-6">
                  <div className="w-24 h-24 bg-gradient-to-r from-teal-500 to-purple-500 rounded-full flex items-center justify-center mx-auto">
                    <UserPlus className="w-12 h-12 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-white">Ready to Start Earning?</h2>
                  <p className="text-white/70 text-lg">
                    Create your referral link to start inviting friends and earning rewards from their activity.
                  </p>
                  <GradientButton
                    onClick={() => setShowWelcomeModal(true)}
                    variant="saucy"
                    className="text-lg font-semibold py-3 px-8"
                  >
                    Get Started
                  </GradientButton>
                </div>
              </GlassCard>
            </div>
          )}
        </div>
      </div>
    </>
  );
}