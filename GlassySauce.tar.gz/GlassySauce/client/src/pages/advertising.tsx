import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Home, 
  Settings, 
  Search, 
  BarChart3, 
  PenTool, 
  FileText, 
  Palette,
  Play,
  Pause,
  RotateCcw,
  TrendingUp,
  Users,
  Eye,
  MousePointer,
  DollarSign,
  Target,
  ArrowRight,
  Bell,
  User,
  ChevronDown,
  Filter,
  Plus,
  CheckCircle,
  XCircle,
  Upload,
  Image,
  Video,
  Volume2,
  Type,
  Folder,
  Calendar,
  Clock,
  Activity,
  Zap,
  Sparkles,
  ArrowUp,
  ArrowDown,
  MoreHorizontal,
  Loader2
} from "lucide-react";
import { 
  FaInstagram, 
  FaSnapchatGhost, 
  FaTiktok, 
  FaTwitter, 
  FaFacebookF, 
  FaYoutube, 
  FaLinkedinIn, 
  FaPinterestP, 
  FaTwitch, 
  FaDiscord, 
  FaRedditAlien 
} from "react-icons/fa";
import { SiOnlyfans } from "react-icons/si";

// Platform Icons using authentic social media logos
const PlatformIcon = ({ name, color, connected = false }: { name: string; color: string; connected?: boolean }) => {
  const getIcon = () => {
    switch (name) {
      case 'Instagram':
        return <FaInstagram className="w-6 h-6" />;
      case 'Snapchat':
        return <FaSnapchatGhost className="w-6 h-6" />;
      case 'TikTok':
        return <FaTiktok className="w-6 h-6" />;
      case 'Twitter':
        return <FaTwitter className="w-6 h-6" />;
      case 'Facebook':
        return <FaFacebookF className="w-6 h-6" />;
      case 'YouTube':
        return <FaYoutube className="w-6 h-6" />;
      case 'LinkedIn':
        return <FaLinkedinIn className="w-6 h-6" />;
      case 'Pinterest':
        return <FaPinterestP className="w-6 h-6" />;
      case 'OnlyFans':
        return <SiOnlyfans className="w-6 h-6" />;
      case 'Twitch':
        return <FaTwitch className="w-6 h-6" />;
      case 'Discord':
        return <FaDiscord className="w-6 h-6" />;
      case 'Reddit':
        return <FaRedditAlien className="w-6 h-6" />;
      default:
        return <div className="w-6 h-6 rounded-full bg-gray-500 flex items-center justify-center text-xs font-bold">{name.slice(0, 2)}</div>;
    }
  };

  return (
    <div className="relative">
      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${color} text-white transition-all hover:scale-110`}>
        {getIcon()}
      </div>
      {connected && (
        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-slate-900 flex items-center justify-center">
          <CheckCircle className="w-3 h-3 text-white" />
        </div>
      )}
    </div>
  );
};

export default function AdvertisingDashboard() {
  const [currentPage, setCurrentPage] = useState<'welcome' | 'social' | 'creative' | 'advertise' | 'analytics'>('welcome');
  const [creativeFormData, setCreativeFormData] = useState({
    websiteUrl: '',
    brandName: '',
    productDescription: '',
    industry: '',
    phoneNumber: '',
    language: 'English',
    offer: '',
    primaryColor: '#007BFC',
    secondaryColor: '#6B7280',
    businessLocation: ''
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedAd, setGeneratedAd] = useState<string | null>(null);
  const [connectedPlatforms, setConnectedPlatforms] = useState<string[]>([]);
  const [savedCreatives, setSavedCreatives] = useState<any[]>([]);
  const [adCampaigns, setAdCampaigns] = useState<any[]>([]);
  const [analyticsData, setAnalyticsData] = useState({
    totalSpend: 0,
    totalClicks: 0,
    totalImpressions: 0,
    totalConversions: 0,
    campaigns: []
  });

  const platforms = [
    { name: 'Instagram', color: 'bg-gradient-to-r from-purple-500 to-pink-500' }, // Instagram gradient
    { name: 'Snapchat', color: 'bg-yellow-400' }, // Snapchat yellow
    { name: 'TikTok', color: 'bg-black' }, // TikTok black
    { name: 'Twitter', color: 'bg-blue-500' }, // Twitter blue
    { name: 'Facebook', color: 'bg-blue-600' }, // Facebook blue
    { name: 'YouTube', color: 'bg-red-600' }, // YouTube red
    { name: 'LinkedIn', color: 'bg-blue-700' }, // LinkedIn blue
    { name: 'Pinterest', color: 'bg-red-600' }, // Pinterest red
    { name: 'OnlyFans', color: 'bg-blue-500' }, // OnlyFans blue
    { name: 'Twitch', color: 'bg-purple-600' }, // Twitch purple
    { name: 'Discord', color: 'bg-indigo-600' }, // Discord indigo
    { name: 'Reddit', color: 'bg-orange-500' }, // Reddit orange
  ];

  const HeaderNavigation = () => (
    <div className="bg-slate-900/50 backdrop-blur-sm border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-teal-400 to-purple-500 rounded-lg flex items-center justify-center">
              <Target className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-white">AdSuite</span>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex space-x-8">
            <button
              onClick={() => setCurrentPage('welcome')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'welcome' 
                  ? 'bg-slate-800 text-white' 
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Home className="w-4 h-4" />
              <span>Home</span>
            </button>
            <button
              onClick={() => setCurrentPage('advertise')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'advertise' 
                  ? 'bg-slate-800 text-white' 
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Target className="w-4 h-4" />
              <span>Advertise</span>
            </button>
            <button
              onClick={() => setCurrentPage('social')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'social' 
                  ? 'bg-slate-800 text-white' 
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Social</span>
            </button>
            <button
              onClick={() => setCurrentPage('creative')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'creative' 
                  ? 'bg-slate-800 text-white' 
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Palette className="w-4 h-4" />
              <span>Creative Hub</span>
            </button>
            <button
              onClick={() => setCurrentPage('analytics')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'analytics' 
                  ? 'bg-slate-800 text-white' 
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Analytics</span>
            </button>
          </nav>

          {/* User Menu */}
          <div className="flex items-center space-x-3">
            <Bell className="w-5 h-5 text-slate-400 hover:text-white cursor-pointer" />
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm text-white">Creator</span>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const WelcomePage = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <HeaderNavigation />
      
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-4">
            Welcome to AdSuite!
          </h1>
          <p className="text-xl text-slate-300 mb-8">
            Create, run, and track ads across all your social platforms in one place.
          </p>
          
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 mb-8">
            <h2 className="text-2xl font-semibold text-white mb-6">Follow these steps:</h2>
            
            <div className="space-y-4 text-left max-w-2xl mx-auto">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-teal-500 rounded-full flex items-center justify-center text-white font-semibold">1</div>
                <div>
                  <h3 className="font-semibold text-white">Connect your social accounts</h3>
                  <p className="text-slate-300">Link platforms like Instagram, TikTok, Snapchat, and more.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-semibold">2</div>
                <div>
                  <h3 className="font-semibold text-white">Use AI to create branded ads</h3>
                  <p className="text-slate-300">Generate professional ads with your logo and brand colors.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">3</div>
                <div>
                  <h3 className="font-semibold text-white">Run ads across all platforms</h3>
                  <p className="text-slate-300">Launch campaigns simultaneously on multiple channels.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-semibold">4</div>
                <div>
                  <h3 className="font-semibold text-white">Monitor performance</h3>
                  <p className="text-slate-300">Track CPM, clicks, conversions, and ROI in real-time.</p>
                </div>
              </div>
            </div>
          </div>
          
          <Button 
            onClick={() => setCurrentPage('social')}
            className="bg-gradient-to-r from-teal-400 to-purple-500 hover:from-teal-500 hover:to-purple-600 text-white font-semibold py-3 px-8 rounded-xl"
          >
            Get Started
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
        
        {/* Illustration placeholder */}
        <div className="mt-12 text-center">
          <div className="w-64 h-64 bg-slate-800/50 rounded-2xl mx-auto flex items-center justify-center">
            <div className="text-slate-400">
              <Target className="w-16 h-16 mx-auto mb-4" />
              <p className="text-sm">Cross-platform advertising made simple</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const SocialPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <HeaderNavigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Connect Your Social Accounts</h1>
          <p className="text-slate-300">Link your social media platforms to start advertising</p>
        </div>
        
        <div className="mb-6 flex justify-between items-center">
          <Button variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white">
            <Plus className="w-4 h-4 mr-2" />
            Connected Accounts
          </Button>
        </div>
        
        {/* Platform Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6 mb-8">
          {platforms.map((platform) => (
            <Card key={platform.name} className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-all">
              <CardContent className="p-4 text-center">
                <div className="mb-3 flex justify-center">
                  <PlatformIcon 
                    name={platform.name} 
                    color={platform.color} 
                    connected={connectedPlatforms.includes(platform.name)}
                  />
                </div>
                <h3 className="font-semibold text-white text-sm mb-1">{platform.name}</h3>
                <p className="text-xs text-slate-400 mb-3">
                  {connectedPlatforms.includes(platform.name) ? 'Connected' : 'Not Connected'}
                </p>
                <Button 
                  size="sm" 
                  className={`w-full ${
                    connectedPlatforms.includes(platform.name) 
                      ? 'bg-green-600 hover:bg-green-700' 
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                  onClick={() => handlePlatformConnect(platform.name)}
                >
                  {connectedPlatforms.includes(platform.name) ? 'Manage' : 'Connect'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center">
          <Button 
            onClick={() => setCurrentPage('creative')}
            className="bg-gradient-to-r from-teal-400 to-purple-500 hover:from-teal-500 hover:to-purple-600 text-white font-semibold py-3 px-8 rounded-xl"
          >
            Next: Create Ads
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );

  // Handle platform connection
  const handlePlatformConnect = (platformName: string) => {
    setConnectedPlatforms(prev => [...prev, platformName]);
  };

  // Handle creative generation
  const handleGenerateCreative = async () => {
    if (!creativeFormData.brandName || !creativeFormData.productDescription) {
      alert('Please fill in Brand Name and Product Description');
      return;
    }

    setIsGenerating(true);
    
    // Simulate AI generation
    setTimeout(() => {
      setGeneratedAd(`Generated ad for ${creativeFormData.brandName}: "${creativeFormData.offer || 'Special offer'}" - ${creativeFormData.productDescription}`);
      setIsGenerating(false);
    }, 2000);
  };

  // Creative Hub Page
  const CreativeHubPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <HeaderNavigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Creative Hub</h1>
          <p className="text-slate-300">Create AI-powered ads for your campaigns</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Creation Options */}
          <div className="lg:col-span-1">
            <Card className="bg-slate-800/50 border-slate-700 mb-6">
              <CardHeader>
                <CardTitle className="text-white">Create New</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white justify-start">
                  <Plus className="w-4 h-4 mr-2" />
                  Start New Creative Template
                </Button>
                <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white justify-start">
                  <PenTool className="w-4 h-4 mr-2" />
                  Add & Generate Content
                </Button>
                <Button className="w-full bg-green-600 hover:bg-green-700 text-white justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Audience Builder
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Folder className="w-5 h-5 mr-2" />
                  Folders
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add new folder
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Ad Creation */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Brand Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!generatedAd ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-slate-300">Website URL (Optional)</Label>
                      <Input
                        placeholder="https://yourwebsite.com"
                        className="bg-slate-700 border-slate-600 text-white"
                        value={creativeFormData.websiteUrl}
                        onChange={(e) => setCreativeFormData({...creativeFormData, websiteUrl: e.target.value})}
                      />
                    </div>
                    
                    <div>
                      <Label className="text-slate-300">Brand Name *</Label>
                      <Input
                        placeholder="Your Brand Name"
                        className="bg-slate-700 border-slate-600 text-white"
                        value={creativeFormData.brandName}
                        onChange={(e) => setCreativeFormData({...creativeFormData, brandName: e.target.value})}
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <Label className="text-slate-300">Product/Service Description *</Label>
                      <Textarea
                        placeholder="Describe your product or service..."
                        className="bg-slate-700 border-slate-600 text-white h-24"
                        value={creativeFormData.productDescription}
                        onChange={(e) => setCreativeFormData({...creativeFormData, productDescription: e.target.value})}
                      />
                    </div>
                    
                    <div>
                      <Label className="text-slate-300">Industry</Label>
                      <Select value={creativeFormData.industry} onValueChange={(value) => setCreativeFormData({...creativeFormData, industry: value})}>
                        <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                          <SelectValue placeholder="Select industry" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="adult-entertainment">Adult Entertainment</SelectItem>
                          <SelectItem value="lifestyle">Lifestyle</SelectItem>
                          <SelectItem value="fitness">Fitness</SelectItem>
                          <SelectItem value="beauty">Beauty</SelectItem>
                          <SelectItem value="gaming">Gaming</SelectItem>
                          <SelectItem value="fashion">Fashion</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label className="text-slate-300">Language</Label>
                      <Select value={creativeFormData.language} onValueChange={(value) => setCreativeFormData({...creativeFormData, language: value})}>
                        <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="English">English</SelectItem>
                          <SelectItem value="Spanish">Spanish</SelectItem>
                          <SelectItem value="French">French</SelectItem>
                          <SelectItem value="German">German</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label className="text-slate-300">Offer</Label>
                      <Input
                        placeholder="Special offer or promotion"
                        className="bg-slate-700 border-slate-600 text-white"
                        value={creativeFormData.offer}
                        onChange={(e) => setCreativeFormData({...creativeFormData, offer: e.target.value})}
                      />
                    </div>
                    
                    <div>
                      <Label className="text-slate-300">Primary Color</Label>
                      <div className="flex space-x-2">
                        <Input
                          type="color"
                          className="w-16 h-10 bg-slate-700 border-slate-600"
                          value={creativeFormData.primaryColor}
                          onChange={(e) => setCreativeFormData({...creativeFormData, primaryColor: e.target.value})}
                        />
                        <Input
                          placeholder="#007BFC"
                          className="bg-slate-700 border-slate-600 text-white"
                          value={creativeFormData.primaryColor}
                          onChange={(e) => setCreativeFormData({...creativeFormData, primaryColor: e.target.value})}
                        />
                      </div>
                    </div>
                    
                    <div className="md:col-span-2">
                      <Button 
                        onClick={handleGenerateCreative}
                        disabled={isGenerating}
                        className="w-full bg-gradient-to-r from-teal-400 to-purple-500 hover:from-teal-500 hover:to-purple-600 text-white"
                      >
                        {isGenerating ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Generate AI Ad
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="bg-slate-700/50 rounded-xl p-8 mb-4">
                      <h3 className="text-white text-lg font-semibold mb-4">Generated Ad Preview</h3>
                      <div className="bg-slate-600/50 rounded-lg p-4 text-white">
                        {generatedAd}
                      </div>
                    </div>
                    
                    <div className="flex space-x-4 justify-center">
                      <Button 
                        onClick={() => setGeneratedAd(null)}
                        variant="outline"
                        className="border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Regenerate
                      </Button>
                      <Button 
                        onClick={() => setCurrentPage('advertise')}
                        className="bg-gradient-to-r from-teal-400 to-purple-500 hover:from-teal-500 hover:to-purple-600 text-white"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Run Ads
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );

  // Advertise Page
  const AdvertisePage = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <HeaderNavigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Advertise</h1>
          <p className="text-slate-300">Launch ads across all connected platforms</p>
        </div>
        
        <div className="mb-6">
          <div className="flex space-x-4 mb-4">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">Recent Ads</Button>
            <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">Draft</Button>
            <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">Scheduled</Button>
          </div>
        </div>
        
        {/* Platform Grid for Running Ads */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6 mb-8">
          {platforms.map((platform) => (
            <Card key={platform.name} className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-4 text-center">
                <div className="mb-3 flex justify-center">
                  <PlatformIcon 
                    name={platform.name} 
                    color={platform.color} 
                    connected={connectedPlatforms.includes(platform.name)}
                  />
                </div>
                <h3 className="font-semibold text-white text-sm mb-1">{platform.name}</h3>
                <p className="text-xs text-slate-400 mb-3">
                  {connectedPlatforms.includes(platform.name) ? 'Connected' : 'Not Connected'}
                </p>
                
                {connectedPlatforms.includes(platform.name) && (
                  <Select>
                    <SelectTrigger className="w-full mb-2 bg-slate-700 border-slate-600 text-white text-xs">
                      <SelectValue placeholder="Select Creative" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="creative1">Ad Creative #1</SelectItem>
                      <SelectItem value="creative2">Ad Creative #2</SelectItem>
                    </SelectContent>
                  </Select>
                )}
                
                <Button 
                  size="sm" 
                  className={`w-full ${
                    connectedPlatforms.includes(platform.name) 
                      ? 'bg-green-600 hover:bg-green-700' 
                      : 'bg-slate-600 cursor-not-allowed'
                  }`}
                  disabled={!connectedPlatforms.includes(platform.name)}
                >
                  {connectedPlatforms.includes(platform.name) ? 'Run Ad' : 'Connect First'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center space-x-4">
          <Button 
            onClick={() => setCurrentPage('creative')}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            Back to Creative Hub
          </Button>
          <Button 
            onClick={() => setCurrentPage('analytics')}
            className="bg-gradient-to-r from-teal-400 to-purple-500 hover:from-teal-500 hover:to-purple-600 text-white"
          >
            View Analytics
          </Button>
        </div>
      </div>
    </div>
  );

  // Analytics Page
  const AnalyticsPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <HeaderNavigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Analytics</h1>
          <p className="text-slate-300">Track performance across all platforms</p>
        </div>
        
        {/* Media Spend Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Total Spend</p>
                  <p className="text-2xl font-bold text-white">${analyticsData.totalSpend}</p>
                </div>
                <DollarSign className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Total Clicks</p>
                  <p className="text-2xl font-bold text-white">{analyticsData.totalClicks}</p>
                </div>
                <MousePointer className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Impressions</p>
                  <p className="text-2xl font-bold text-white">{analyticsData.totalImpressions}</p>
                </div>
                <Eye className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Campaign Performance Table */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center justify-between">
              <span>Campaign Performance</span>
              <div className="flex items-center space-x-2">
                <Input
                  placeholder="Search campaigns..."
                  className="bg-slate-700 border-slate-600 text-white w-64"
                />
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                  <Filter className="w-4 h-4 mr-2" />
                  Customize Columns
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-slate-700">
                  <tr className="text-slate-400">
                    <th className="text-left py-3 px-4">Campaign</th>
                    <th className="text-left py-3 px-4">Clicks</th>
                    <th className="text-left py-3 px-4">Conversions</th>
                    <th className="text-left py-3 px-4">CTR</th>
                    <th className="text-left py-3 px-4">Impressions</th>
                    <th className="text-left py-3 px-4">CPM</th>
                    <th className="text-left py-3 px-4">CPC</th>
                    <th className="text-left py-3 px-4">Spend</th>
                  </tr>
                </thead>
                <tbody>
                  {analyticsData.campaigns.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center py-8 text-slate-400">
                        <BarChart3 className="w-12 h-12 mx-auto mb-4 text-slate-500" />
                        <p>No campaigns found</p>
                        <p className="text-sm">Start advertising to see performance data</p>
                      </td>
                    </tr>
                  ) : (
                    analyticsData.campaigns.map((campaign: any, index: number) => (
                      <tr key={index} className="border-b border-slate-700/50 hover:bg-slate-700/20">
                        <td className="py-3 px-4 text-white">{campaign.name}</td>
                        <td className="py-3 px-4 text-white">{campaign.clicks}</td>
                        <td className="py-3 px-4 text-white">{campaign.conversions}</td>
                        <td className="py-3 px-4 text-white">{campaign.ctr}%</td>
                        <td className="py-3 px-4 text-white">{campaign.impressions}</td>
                        <td className="py-3 px-4 text-white">${campaign.cpm}</td>
                        <td className="py-3 px-4 text-white">${campaign.cpc}</td>
                        <td className="py-3 px-4 text-white">${campaign.spend}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
        
        <div className="text-center mt-8">
          <Button 
            onClick={() => setCurrentPage('advertise')}
            className="bg-gradient-to-r from-teal-400 to-purple-500 hover:from-teal-500 hover:to-purple-600 text-white"
          >
            Back to Advertise
          </Button>
        </div>
      </div>
    </div>
  );

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'welcome':
        return <WelcomePage />;
      case 'social':
        return <SocialPage />;
      case 'creative':
        return <CreativeHubPage />;
      case 'advertise':
        return <AdvertisePage />;
      case 'analytics':
        return <AnalyticsPage />;
      default:
        return <WelcomePage />;
    }
  };

  return renderCurrentPage();
}