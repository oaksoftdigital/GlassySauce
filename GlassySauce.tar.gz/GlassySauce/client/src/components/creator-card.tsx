import { Link } from "wouter";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Users, Shield, Twitter, Instagram, Globe } from "lucide-react";
import type { Creator } from "@/types";

interface CreatorCardProps {
  creator: Creator;
  rank?: number;
}

export function CreatorCard({ creator, rank }: CreatorCardProps) {
  const formatPrice = (price: string) => {
    return parseFloat(price).toFixed(3);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  const getGradientVariant = (ranking: number) => {
    if (ranking <= 3) return "saucy";
    if (ranking <= 10) return "coral";
    return "purple";
  };

  return (
    <Link href={`/creator/${creator.userId}`}>
      <GlassCard hover className="overflow-hidden cursor-pointer transition-transform hover:scale-[1.02]">
        <div className="relative">
          <img
            src={creator.profileImage || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"}
            alt={creator.displayName}
            className="w-full h-48 object-cover"
          />
          {creator.isOnline && (
            <div className="absolute top-4 left-4 flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-white text-sm font-medium glass px-2 py-1 rounded-full">
                Online
              </span>
            </div>
          )}
          {rank && (
            <div className="absolute top-4 right-4">
              <span className="text-white font-bold text-lg chart-gradient px-2 py-1 rounded-lg">#{rank}</span>
            </div>
          )}
          
          {/* Social Verification Badges */}
          <div className="absolute bottom-4 left-4 flex items-center gap-2">
            <Badge variant="secondary" className="bg-blue-500/20 border-blue-400 text-blue-400">
              <Twitter className="w-3 h-3 mr-1" />
              24M
            </Badge>
            <Badge variant="secondary" className="bg-pink-500/20 border-pink-400 text-pink-400">
              <Instagram className="w-3 h-3 mr-1" />
              15M
            </Badge>
            <Badge variant="secondary" className="bg-purple-500/20 border-purple-400 text-purple-400">
              <Globe className="w-3 h-3 mr-1" />
              OnlyFans
            </Badge>
          </div>
        </div>
      
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white">{creator.displayName}</h3>
          <span className="text-sm text-white/60">{creator.tokenSymbol}</span>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="text-2xl font-bold gradient-text">
              ${formatNumber(parseFloat(creator.totalVolume))}
            </div>
            <div className="text-sm text-white/60">Token Value</div>
          </div>
          <div>
            <div className="text-2xl font-bold gradient-text">
              {formatNumber(creator.holderCount)}
            </div>
            <div className="text-sm text-white/60">Holders</div>
          </div>
        </div>
        
        <GradientButton
          variant={getGradientVariant(creator.ranking)}
          className="w-full mb-4"
        >
          Buy Key - {formatPrice(creator.currentPrice)} ETH
        </GradientButton>
        
        <div className="text-center text-white/70 text-sm flex items-center justify-center">
          <Users size={16} className="mr-1" />
          {formatNumber(creator.chatMemberCount)} members in chat
        </div>
      </div>
      </GlassCard>
    </Link>
  );
}
