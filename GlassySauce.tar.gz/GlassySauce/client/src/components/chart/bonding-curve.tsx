import { GlassCard } from "@/components/ui/glass-card";

export function BondingCurve() {
  return (
    <GlassCard className="p-8">
      <h3 className="text-2xl font-bold text-white mb-6">Price Chart</h3>
      <div className="relative h-64 mb-6">
        {/* Mock chart visualization */}
        <div className="absolute inset-0 flex items-end justify-center space-x-1">
          {[12, 16, 20, 32, 28, 36, 44, 40, 48, 52].map((height, index) => (
            <div
              key={index}
              className={`w-4 bg-gradient-to-t from-pink-500 to-transparent transition-all duration-300 hover:from-pink-400`}
              style={{ height: `${height}px` }}
            />
          ))}
        </div>
        <div className="absolute top-0 left-0 text-white/50 text-sm">0.08 ETH</div>
        <div className="absolute bottom-0 left-0 text-white/50 text-sm">0.01 ETH</div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <GlassCard className="p-4 text-center">
          <div className="text-2xl font-bold gradient-text">0.045</div>
          <div className="text-white/70 text-sm">Current Price</div>
        </GlassCard>
        <GlassCard className="p-4 text-center">
          <div className="text-2xl font-bold text-green-400">+12.5%</div>
          <div className="text-white/70 text-sm">24h Change</div>
        </GlassCard>
      </div>
    </GlassCard>
  );
}
