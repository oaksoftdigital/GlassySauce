import { Link } from "wouter";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Users, Eye, MessageCircle, TrendingUp, Star, Heart } from "lucide-react";
import type { Creator } from "@/types";

interface EnhancedCreatorCardProps {
  creator: Creator;
  rank?: number;
  showStats?: boolean;
}

export function EnhancedCreatorCard({ creator, rank, showStats = true }: EnhancedCreatorCardProps) {
  const formatPrice = (price: string) => {
    return parseFloat(price).toFixed(3);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  const getGradientVariant = (ranking: number) => {
    if (ranking <= 3) return "saucy";
    if (ranking <= 10) return "coral";
    return "purple";
  };

  const getRankBadge = (ranking: number) => {
    if (ranking === 1) return { label: "👑 #1", class: "bg-gradient-to-r from-yellow-400 to-yellow-600" };
    if (ranking <= 3) return { label: `🥇 #${ranking}`, class: "bg-gradient-to-r from-pink-500 to-purple-600" };
    if (ranking <= 10) return { label: `⭐ #${ranking}`, class: "bg-gradient-to-r from-purple-500 to-blue-600" };
    return { label: `#${ranking}`, class: "bg-gradient-to-r from-gray-500 to-gray-700" };
  };

  const rankBadge = getRankBadge(creator.ranking);

  return (
    <Link href={`/creator/${creator.userId}`}>
      <GlassCard hover className="overflow-hidden group cursor-pointer transition-transform hover:scale-[1.02]">
        <div className="relative">
        {/* Cover Image */}
        <div className="h-32 bg-gradient-to-r from-pink-500/20 to-purple-600/20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50"></div>
          {creator.isOnline && (
            <div className="absolute top-3 left-3 flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-white text-xs font-medium glass px-2 py-1 rounded-full">
                LIVE
              </span>
            </div>
          )}
          {rank && (
            <div className="absolute top-3 right-3">
              <Badge className={`${rankBadge.class} text-white border-0 font-bold`}>
                {rankBadge.label}
              </Badge>
            </div>
          )}
        </div>

        {/* Profile Image */}
        <div className="absolute -bottom-12 left-6">
          <div className="w-24 h-24 rounded-full border-4 border-white/20 overflow-hidden">
            <img
              src={creator.profileImage || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"}
              alt={creator.displayName}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
      
      <div className="pt-16 p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-white group-hover:gradient-text transition-all">
              {creator.displayName}
            </h3>
            <div className="flex items-center space-x-2 mt-1">
              <span className="text-sm text-white/60">@{creator.tokenSymbol.toLowerCase()}</span>
              <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
              <span className="text-xs text-white/60">4.9</span>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <Heart className="w-4 h-4 text-pink-400" />
            <span className="text-sm text-white/70">{Math.floor(Math.random() * 500) + 100}</span>
          </div>
        </div>

        {/* Bio */}
        {creator.bio && (
          <p className="text-sm text-white/70 mb-4 line-clamp-2">
            {creator.bio}
          </p>
        )}

        {/* Stats Grid */}
        {showStats && (
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="glass rounded-xl p-3 text-center">
              <div className="text-lg font-bold gradient-text">
                {formatPrice(creator.currentPrice)}
              </div>
              <div className="text-xs text-white/60">ETH</div>
            </div>
            <div className="glass rounded-xl p-3 text-center">
              <div className="text-lg font-bold gradient-text">
                {formatNumber(creator.holderCount)}
              </div>
              <div className="text-xs text-white/60">Holders</div>
            </div>
            <div className="glass rounded-xl p-3 text-center">
              <div className="text-lg font-bold text-green-400">
                +{Math.floor(Math.random() * 20) + 5}%
              </div>
              <div className="text-xs text-white/60">24h</div>
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="flex items-center justify-between text-xs text-white/60 mb-4">
          <div className="flex items-center space-x-1">
            <Eye className="w-3 h-3" />
            <span>{formatNumber(Math.floor(Math.random() * 10000) + 1000)} views</span>
          </div>
          <div className="flex items-center space-x-1">
            <MessageCircle className="w-3 h-3" />
            <span>{formatNumber(creator.chatMemberCount)} in chat</span>
          </div>
          <div className="flex items-center space-x-1">
            <TrendingUp className="w-3 h-3" />
            <span>${formatNumber(parseFloat(creator.totalVolume))}</span>
          </div>
        </div>
        
        {/* Action Button */}
        <GradientButton
          variant={getGradientVariant(creator.ranking)}
          className="w-full group-hover:shadow-lg transition-all"
          size="sm"
        >
          Buy Key - {formatPrice(creator.currentPrice)} ETH
        </GradientButton>
      </div>
    </GlassCard>
    </Link>
  );
}