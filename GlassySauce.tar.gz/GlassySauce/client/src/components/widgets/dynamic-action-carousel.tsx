import { useState, useEffect } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { 
  Users, 
  MessageSquare, 
  UserPlus, 
  Mail,
  Send,
  Copy,
  Star,
  Calendar
} from "lucide-react";

const carouselItems = [
  {
    id: 1,
    icon: Calendar,
    title: "Follow your favourite creators",
    subtitle: "See all their posts & onchain activities",
    type: "follow",
    content: {
      creators: [
        { id: 1, name: "Bella", avatar: "https://images.unsplash.com/photo-1494790108755-2616c57c7f78?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" },
        { id: 2, name: "Tana", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" },
        { id: 3, name: "Alex", avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" },
        { id: 4, name: "Sarah", avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" },
        { id: 5, name: "Emma", avatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" },
        { id: 6, name: "Jack", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" }
      ]
    }
  },
  {
    id: 2,
    icon: Send,
    title: "Connect your telegram handle",
    subtitle: "Streams Fans.tech notifications on telegram",
    type: "telegram",
    content: {
      telegramIcon: "https://telegram.org/img/t_logo.png"
    }
  },
  {
    id: 3,
    icon: Users,
    title: "Get your friends on Fans.tech",
    subtitle: "Discover Alpha, Ape, Shill, FUD together",
    type: "network",
    content: {
      connections: [
        { id: 1, x: 50, y: 50, size: "large", color: "bg-purple-500" },
        { id: 2, x: 20, y: 30, size: "medium", color: "bg-blue-500" },
        { id: 3, x: 80, y: 25, size: "small", color: "bg-green-500" },
        { id: 4, x: 30, y: 70, size: "small", color: "bg-pink-500" },
        { id: 5, x: 75, y: 65, size: "medium", color: "bg-yellow-500" },
        { id: 6, x: 15, y: 55, size: "tiny", color: "bg-red-500" },
        { id: 7, x: 85, y: 45, size: "tiny", color: "bg-indigo-500" }
      ]
    }
  },
  {
    id: 4,
    icon: UserPlus,
    title: "Refer Friends",
    subtitle: "Send an invite to your friends",
    type: "refer",
    content: {
      description: "Use this link to invite awesome people to Fans.tech. Trusting you to bring great folks to our app.",
      inviteCode: "FANS2025X"
    }
  }
];

export function DynamicActionCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Auto-advance carousel
  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % carouselItems.length);
    }, 5000); // Change every 5 seconds

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const currentItem = carouselItems[currentIndex];

  const handleDotClick = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
    // Resume auto-play after 10 seconds
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const copyInviteCode = () => {
    navigator.clipboard.writeText(currentItem.content.inviteCode || "FANS2025X");
  };

  const renderContent = () => {
    switch (currentItem.type) {
      case "follow":
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              {currentItem.content.creators?.map((creator) => (
                <div key={creator.id} className="relative group">
                  <img
                    src={creator.avatar}
                    alt={creator.name}
                    className="w-full aspect-square rounded-xl object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 rounded-xl transition-colors"></div>
                </div>
              ))}
            </div>
            <GradientButton size="sm" variant="glass" className="w-full">
              Follow people
            </GradientButton>
          </div>
        );

      case "telegram":
        return (
          <div className="space-y-4 text-center">
            <div className="w-24 h-24 mx-auto bg-blue-500 rounded-full flex items-center justify-center">
              <Send className="w-12 h-12 text-white" />
            </div>
            <GradientButton size="sm" variant="glass" className="w-full">
              Connect your handle
            </GradientButton>
          </div>
        );

      case "network":
        return (
          <div className="space-y-4">
            <div className="relative h-32 bg-gradient-to-br from-blue-900/20 to-purple-900/20 rounded-lg overflow-hidden">
              {currentItem.content.connections?.map((connection) => {
                const sizeClasses: Record<string, string> = {
                  large: "w-8 h-8",
                  medium: "w-6 h-6", 
                  small: "w-4 h-4",
                  tiny: "w-3 h-3"
                };
                
                return (
                  <div
                    key={connection.id}
                    className={`absolute ${connection.color} ${sizeClasses[connection.size]} rounded-full`}
                    style={{
                      left: `${connection.x}%`,
                      top: `${connection.y}%`,
                      transform: 'translate(-50%, -50%)'
                    }}
                  />
                );
              })}
              
              {/* Connection lines */}
              <svg className="absolute inset-0 w-full h-full">
                <defs>
                  <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.3" />
                  </linearGradient>
                </defs>
                <path
                  d="M 20,30 Q 50,20 80,25 M 30,70 Q 50,50 75,65"
                  stroke="url(#lineGradient)"
                  strokeWidth="1"
                  fill="none"
                  strokeDasharray="2,2"
                />
              </svg>
            </div>
            <GradientButton size="sm" variant="glass" className="w-full">
              Use your unique invite code
            </GradientButton>
          </div>
        );

      case "refer":
        return (
          <div className="space-y-4">
            <div className="flex items-center space-x-3 p-3 glass rounded-lg">
              <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                1
              </div>
              <div className="flex-1">
                <div className="text-white text-sm font-medium">Send an invite to your friends</div>
              </div>
            </div>
            <p className="text-white/60 text-xs leading-relaxed">
              {currentItem.content.description}
            </p>
            <div className="flex items-center space-x-2">
              <GradientButton size="sm" variant="saucy" className="flex-1">
                <Copy className="w-4 h-4 mr-2" />
                Copy code
              </GradientButton>
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <UserPlus className="w-8 h-8 text-white" />
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <GlassCard className="p-6 space-y-4">
      {/* Header */}
      <div className="flex items-start space-x-3">
        <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center mt-1">
          <currentItem.icon className="w-4 h-4 text-blue-400" />
        </div>
        <div className="flex-1">
          <h3 className="text-white font-semibold text-sm leading-tight mb-1">
            {currentItem.title} ({currentIndex + 1}/{carouselItems.length})
          </h3>
          <p className="text-white/60 text-xs leading-relaxed">
            {currentItem.subtitle}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="min-h-[200px]">
        {renderContent()}
      </div>

      {/* Pagination Dots */}
      <div className="flex items-center justify-center space-x-2">
        {carouselItems.map((_, index) => (
          <button
            key={index}
            onClick={() => handleDotClick(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentIndex
                ? 'bg-blue-500 w-6'
                : 'bg-white/20 hover:bg-white/40'
            }`}
          />
        ))}
      </div>
    </GlassCard>
  );
}