import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { X, Sparkles, Users, TrendingUp, Crown, Star, Zap } from "lucide-react";

interface OnboardingFlowProps {
  isOpen: boolean;
  onClose: () => void;
}

export function OnboardingFlow({ isOpen, onClose }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedCreatorType, setSelectedCreatorType] = useState<string>("");
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);

  if (!isOpen) return null;

  const steps = [
    {
      id: "welcome",
      title: "Welcome to Fans.tech",
      description: "The future of creator monetization",
      component: WelcomeStep,
    },
    {
      id: "creator-type",
      title: "What type of creator are you?",
      description: "Help us personalize your experience",
      component: CreatorTypeStep,
    },
    {
      id: "goals",
      title: "What are your goals?",
      description: "Select all that apply",
      component: GoalsStep,
    },
    {
      id: "complete",
      title: "You're all set!",
      description: "Let's start building your creator economy",
      component: CompleteStep,
    },
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const CurrentStepComponent = steps[currentStep].component;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <GlassCard className="max-w-2xl w-full p-8 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white/60 hover:text-white transition-colors"
        >
          <X size={24} />
        </button>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-white/60">
              Step {currentStep + 1} of {steps.length}
            </span>
            <span className="text-sm text-white/60">
              {Math.round(((currentStep + 1) / steps.length) * 100)}%
            </span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-pink-500 to-purple-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        <CurrentStepComponent 
          step={steps[currentStep]}
          selectedCreatorType={selectedCreatorType}
          setSelectedCreatorType={setSelectedCreatorType}
          selectedGoals={selectedGoals}
          setSelectedGoals={setSelectedGoals}
          onNext={nextStep}
          onPrev={prevStep}
          canGoBack={currentStep > 0}
          canGoNext={currentStep < steps.length - 1}
        />
      </GlassCard>
    </div>
  );
}

function WelcomeStep({ step, onNext }: any) {
  return (
    <div className="text-center">
      <div className="mb-6">
        <Sparkles className="w-20 h-20 text-pink-400 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-white mb-4">{step.title}</h2>
        <p className="text-white/70 text-lg">{step.description}</p>
      </div>
      
      <div className="space-y-4 mb-8">
        <div className="flex items-center justify-center space-x-4">
          <div className="glass-dark rounded-2xl p-4 flex-1">
            <Crown className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <p className="text-white text-sm">Tokenize Your Influence</p>
          </div>
          <div className="glass-dark rounded-2xl p-4 flex-1">
            <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <p className="text-white text-sm">Build Communities</p>
          </div>
          <div className="glass-dark rounded-2xl p-4 flex-1">
            <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <p className="text-white text-sm">Earn More</p>
          </div>
        </div>
      </div>

      <GradientButton onClick={onNext} className="w-full" size="lg">
        Get Started
      </GradientButton>
    </div>
  );
}

function CreatorTypeStep({ step, selectedCreatorType, setSelectedCreatorType, onNext, onPrev }: any) {
  const creatorTypes = [
    {
      id: "onlyfans",
      name: "OnlyFans Creator",
      icon: "🔥",
      description: "Adult content creator",
    },
    {
      id: "instagram",
      name: "Instagram Influencer",
      icon: "📸",
      description: "Social media influencer",
    },
    {
      id: "tiktok",
      name: "TikTok Creator",
      icon: "🎵",
      description: "Short-form video creator",
    },
    {
      id: "youtube",
      name: "YouTuber",
      icon: "🎬",
      description: "Long-form content creator",
    },
    {
      id: "twitch",
      name: "Twitch Streamer",
      icon: "🎮",
      description: "Live streaming creator",
    },
    {
      id: "other",
      name: "Other",
      icon: "✨",
      description: "Different type of creator",
    },
  ];

  return (
    <div className="text-center">
      <h2 className="text-3xl font-bold text-white mb-4">{step.title}</h2>
      <p className="text-white/70 text-lg mb-8">{step.description}</p>
      
      <div className="grid grid-cols-2 gap-4 mb-8">
        {creatorTypes.map((type) => (
          <button
            key={type.id}
            onClick={() => setSelectedCreatorType(type.id)}
            className={`glass-dark rounded-2xl p-6 text-left transition-all hover:scale-105 ${
              selectedCreatorType === type.id 
                ? 'ring-2 ring-pink-500 bg-gradient-to-br from-pink-500/20 to-purple-500/20' 
                : 'hover:bg-white/5'
            }`}
          >
            <div className="text-3xl mb-2">{type.icon}</div>
            <h3 className="text-white font-semibold mb-1">{type.name}</h3>
            <p className="text-white/60 text-sm">{type.description}</p>
          </button>
        ))}
      </div>

      <div className="flex space-x-4">
        <GradientButton onClick={onPrev} variant="glass" className="flex-1">
          Back
        </GradientButton>
        <GradientButton 
          onClick={onNext} 
          className="flex-1" 
          disabled={!selectedCreatorType}
        >
          Continue
        </GradientButton>
      </div>
    </div>
  );
}

function GoalsStep({ step, selectedGoals, setSelectedGoals, onNext, onPrev }: any) {
  const goals = [
    { id: "monetize", name: "Monetize my content", icon: "💸" },
    { id: "community", name: "Build a stronger community", icon: "👥" },
    { id: "exclusive", name: "Create exclusive experiences", icon: "🎭" },
    { id: "passive", name: "Generate passive income", icon: "💰" },
    { id: "grow", name: "Grow my audience", icon: "📈" },
    { id: "interact", name: "Better fan interaction", icon: "💬" },
  ];

  const toggleGoal = (goalId: string) => {
    setSelectedGoals((prev: string[]) =>
      prev.includes(goalId)
        ? prev.filter(id => id !== goalId)
        : [...prev, goalId]
    );
  };

  return (
    <div className="text-center">
      <h2 className="text-3xl font-bold text-white mb-4">{step.title}</h2>
      <p className="text-white/70 text-lg mb-8">{step.description}</p>
      
      <div className="grid grid-cols-2 gap-4 mb-8">
        {goals.map((goal) => (
          <button
            key={goal.id}
            onClick={() => toggleGoal(goal.id)}
            className={`glass-dark rounded-2xl p-6 text-left transition-all hover:scale-105 ${
              selectedGoals.includes(goal.id)
                ? 'ring-2 ring-pink-500 bg-gradient-to-br from-pink-500/20 to-purple-500/20' 
                : 'hover:bg-white/5'
            }`}
          >
            <div className="text-3xl mb-2">{goal.icon}</div>
            <h3 className="text-white font-semibold">{goal.name}</h3>
            {selectedGoals.includes(goal.id) && (
              <Badge className="mt-2 bg-gradient-to-r from-pink-500 to-purple-500">
                Selected
              </Badge>
            )}
          </button>
        ))}
      </div>

      <div className="flex space-x-4">
        <GradientButton onClick={onPrev} variant="glass" className="flex-1">
          Back
        </GradientButton>
        <GradientButton 
          onClick={onNext} 
          className="flex-1" 
          disabled={selectedGoals.length === 0}
        >
          Continue
        </GradientButton>
      </div>
    </div>
  );
}

function CompleteStep({ step, onNext }: any) {
  return (
    <div className="text-center">
      <div className="mb-6">
        <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <Star className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-white mb-4">{step.title}</h2>
        <p className="text-white/70 text-lg">{step.description}</p>
      </div>
      
      <div className="glass-dark rounded-2xl p-6 mb-8">
        <h3 className="text-white font-semibold mb-4">What's next?</h3>
        <div className="space-y-3 text-left">
          <div className="flex items-center space-x-3">
            <Zap className="w-5 h-5 text-yellow-400" />
            <span className="text-white/80">Create your creator profile</span>
          </div>
          <div className="flex items-center space-x-3">
            <Crown className="w-5 h-5 text-yellow-400" />
            <span className="text-white/80">Launch your first token</span>
          </div>
          <div className="flex items-center space-x-3">
            <Users className="w-5 h-5 text-blue-400" />
            <span className="text-white/80">Invite your community</span>
          </div>
        </div>
      </div>

      <GradientButton onClick={onNext} className="w-full" size="lg">
        Enter Fans.tech
      </GradientButton>
    </div>
  );
}