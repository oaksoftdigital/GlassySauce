import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { X, Sparkles, Users, TrendingUp } from "lucide-react";

interface WelcomeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WelcomeModal({ isOpen, onClose }: WelcomeModalProps) {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const steps = [
    {
      icon: <Sparkles className="w-16 h-16 text-pink-400" />,
      title: "Welcome to Fans.tech",
      description: "Transform your influence into digital assets with our revolutionary creator token platform.",
    },
    {
      icon: <Users className="w-16 h-16 text-purple-400" />,
      title: "Build Your Community",
      description: "Create exclusive token-gated experiences for your most loyal fans and supporters.",
    },
    {
      icon: <TrendingUp className="w-16 h-16 text-pink-400" />,
      title: "Monetize Your Presence",
      description: "Use bonding curves to fairly price your tokens and let your community invest in your success.",
    },
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <GlassCard className="max-w-md w-full p-8 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white/60 hover:text-white transition-colors"
        >
          <X size={24} />
        </button>

        <div className="text-center">
          <div className="flex justify-center mb-6">
            {steps[currentStep].icon}
          </div>

          <h2 className="text-2xl font-bold text-white mb-4">
            {steps[currentStep].title}
          </h2>

          <p className="text-white/80 mb-8 leading-relaxed">
            {steps[currentStep].description}
          </p>

          <div className="flex justify-center space-x-2 mb-8">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentStep ? "bg-pink-400" : "bg-white/30"
                }`}
              />
            ))}
          </div>

          <div className="space-y-4">
            <GradientButton
              variant="saucy"
              onClick={nextStep}
              className="w-full"
              size="lg"
            >
              {currentStep === steps.length - 1 ? "Get Started" : "Continue"}
            </GradientButton>

            {currentStep === 0 && (
              <GradientButton
                variant="glass"
                onClick={onClose}
                className="w-full"
                size="lg"
              >
                Skip Tutorial
              </GradientButton>
            )}
          </div>
        </div>
      </GlassCard>
    </div>
  );
}