import { Link, useLocation } from "wouter";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Flame, Menu, X } from "lucide-react";
import { useState } from "react";

export function Navigation() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/discover", label: "Discover" },
    { href: "/trading", label: "Trading" },
    { href: "/wallet", label: "Wallet" },
    { href: "/chat", label: "Chat" },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 p-4">
      <GlassCard className="max-w-7xl mx-auto flex justify-between items-center p-4">
        <Link href="/" className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
          <div className="w-10 h-10 rounded-full gradient-saucy flex items-center justify-center">
            <Flame className="text-white" size={20} />
          </div>
          <span className="text-2xl font-bold text-white text-shadow">Fans.tech</span>
        </Link>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`text-white transition-colors hover:text-pink-300 ${
                location === item.href ? "text-pink-300" : ""
              }`}
            >
              {item.label}
            </Link>
          ))}
          <GradientButton variant="glass" size="sm">
            <i className="fab fa-google mr-2"></i>
            Login
          </GradientButton>
        </div>
        
        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="absolute top-full left-4 right-4 mt-2 md:hidden">
            <GlassCard className="p-4 space-y-4">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`block text-white transition-colors hover:text-pink-300 ${
                    location === item.href ? "text-pink-300" : ""
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <GradientButton variant="glass" size="sm" className="w-full">
                <i className="fab fa-google mr-2"></i>
                Login
              </GradientButton>
            </GlassCard>
          </div>
        )}
      </GlassCard>
    </nav>
  );
}
