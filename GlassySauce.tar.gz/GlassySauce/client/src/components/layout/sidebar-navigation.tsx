import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { GlassCard } from "@/components/ui/glass-card";
import { Badge } from "@/components/ui/badge";
import { NewClubModal } from "@/components/chat/new-club-modal";
import { 
  Home, 
  Search, 
  TrendingUp, 
  Wallet, 
  MessageCircle, 
  User, 
  Settings, 
  Bell,
  Crown,
  Users,
  BarChart3,
  Zap,
  Menu,
  X,
  ArrowLeftRight,
  Edit3,
  UserPlus,
  Bookmark,
  Plus,
  Video,
  DollarSign,
  FileText,
  Radio,
  Coins,
  Handshake,
  ShoppingBag,
  Megaphone,

} from "lucide-react";

export function SidebarNavigation() {
  const [location] = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const [showLaunchTokenModal, setShowLaunchTokenModal] = useState(false);
  const createMenuRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (createMenuRef.current && !createMenuRef.current.contains(event.target as Node)) {
        setShowCreateMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navigationItems = [
    {
      section: "Main",
      items: [
        { name: "Home", path: "/", icon: Home, badge: null },
        { name: "Chat", path: "/chat", icon: MessageCircle, badge: null },
        { name: "Wallet", path: "/wallet", icon: Wallet, badge: null },
        { name: "Marketplace", path: "/alpha", icon: ShoppingBag, badge: null },
        { name: "Ads", path: "/advertising", icon: Megaphone, badge: null },
        { name: "Create", path: "#", icon: Plus, badge: null, isDropdown: true },
      ]
    },
    {
      section: "DeFi",
      items: [
        { name: "Trade", path: "/bridge", icon: TrendingUp, badge: null },
        { name: "Staking", path: "/staking", icon: Zap, badge: null },
        { name: "Loans", path: "/loans", icon: DollarSign, badge: null },
      ]
    },
    {
      section: "Creator",
      items: [
        { name: "Profile", path: "/profile", icon: User, badge: null },
        { name: "Referrals", path: "/referrals", icon: UserPlus, badge: null },
        { name: "Notifications", path: "/notifications", icon: Bell, badge: null },
        { name: "Settings", path: "/settings", icon: Settings, badge: null },
      ]
    },
    {
      section: "Campaigns",
      items: [
        { name: "Dashboard", path: "/campaigns", icon: BarChart3, badge: null },
      ]
    }
  ];

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo Section */}
      <div className={`p-2 border-b border-white/10 ${isCollapsed ? 'px-1' : ''}`}>
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl flex items-center justify-center">
            <Crown className="w-6 h-6 text-white" />
          </div>
          {!isCollapsed && (
            <div>
              <h1 className="text-xl font-bold text-white">Fans.tech</h1>
              <p className="text-xs text-white/60">Creator Economy</p>
            </div>
          )}
        </div>
      </div>



      {/* Navigation Sections */}
      <div className="flex-1 overflow-y-auto py-4">
        <div className="space-y-6">
          {navigationItems.map((section) => (
            <div key={section.section} className="px-3">
              {!isCollapsed && (
                <h2 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                  {section.section}
                </h2>
              )}
              <div className="space-y-2">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item.path);
                  
                  // Handle Create button
                  if (item.isDropdown && item.name === "Create") {
                    return (
                      <button
                        key={item.name}
                        onClick={() => setShowCreateMenu(true)}
                        className={`
                          w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group
                          text-white/60 hover:text-white hover:bg-slate-800/30
                          ${isCollapsed ? 'justify-center px-2' : ''}
                        `}
                      >
                        <Icon 
                          className="w-5 h-5 group-hover:scale-105 transition-transform" 
                        />
                        {!isCollapsed && (
                          <span className="font-medium flex-1 text-left">{item.name}</span>
                        )}
                      </button>
                    );
                  }
                  
                  // Regular navigation item
                  return (
                    <Link key={item.path} href={item.path}>
                      <a
                        className={`
                          flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group
                          ${active 
                            ? 'chart-gradient text-white shadow-lg' 
                            : 'text-white/60 hover:text-white hover:bg-slate-800/30'
                          }
                          ${isCollapsed ? 'justify-center px-2' : ''}
                        `}
                        onClick={() => setIsMobileOpen(false)}
                      >
                        <Icon 
                          className={`w-5 h-5 ${active ? 'text-white' : ''} group-hover:scale-105 transition-transform`} 
                        />
                        {!isCollapsed && (
                          <>
                            <span className="font-medium flex-1">{item.name}</span>
                            {item.badge && (
                              <Badge 
                                variant={active ? "default" : "secondary"}
                                className={`text-xs px-2 py-1 ${
                                  active 
                                    ? 'bg-white/20' 
                                    : 'bg-slate-800/50'
                                }`}
                              >
                                {item.badge}
                              </Badge>
                            )}
                          </>
                        )}
                      </a>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* User Profile Section */}
      <div className={`p-4 border-t border-white/10 ${isCollapsed ? 'px-2' : ''}`}>
        <div className={`flex items-center space-x-3 p-3 rounded-2xl glass-dark hover:bg-white/5 transition-all cursor-pointer ${isCollapsed ? 'justify-center' : ''}`}>
          <div className="relative">
            <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-black"></div>
          </div>
          {!isCollapsed && (
            <div className="flex-1">
              <p className="text-white font-medium text-sm">Guest User</p>
              <p className="text-white/60 text-xs">Connect Wallet</p>
            </div>
          )}
        </div>
      </div>

      {/* Collapse Toggle */}
      <div className="p-4 border-t border-white/10">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="w-full flex items-center justify-center p-3 rounded-2xl glass-dark hover:bg-white/5 transition-all"
        >
          <Menu className={`w-5 h-5 text-white/70 transition-transform ${isCollapsed ? 'rotate-180' : ''}`} />
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileOpen(true)}
        className="lg:hidden fixed top-6 left-6 z-50 p-3 glass-dark rounded-2xl text-white/70 hover:text-white transition-all"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="lg:hidden fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Desktop Sidebar */}
      <div className={`hidden lg:flex flex-col fixed left-0 top-0 h-full z-30 transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-48'
      }`}>
        <GlassCard className="h-full rounded-none border-r border-white/10 bg-black/20 backdrop-blur-xl">
          <SidebarContent />
        </GlassCard>
      </div>

      {/* Mobile Sidebar */}
      <div className={`lg:hidden fixed left-0 top-0 h-full z-50 w-72 transition-transform duration-300 ${
        isMobileOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <GlassCard className="h-full rounded-none bg-black/40 backdrop-blur-xl">
          <div className="absolute top-6 right-6">
            <button
              onClick={() => setIsMobileOpen(false)}
              className="p-2 text-white/70 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <SidebarContent />
        </GlassCard>
      </div>

      {/* Create Modal */}
      {showCreateMenu && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setShowCreateMenu(false)}
          />
          
          {/* Modal Content */}
          <div className="relative glass rounded-2xl p-8 max-w-md w-full mx-4 border border-white/20 shadow-2xl">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-teal-400 to-purple-500 rounded-lg flex items-center justify-center">
                  <Plus className="w-5 h-5 text-white" />
                </div>
                <h2 className="text-xl font-bold text-white">Create</h2>
              </div>
              <button
                onClick={() => setShowCreateMenu(false)}
                className="text-white/60 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Create Options */}
            <div className="space-y-3">
              <Link href="/post">
                <a
                  onClick={() => {
                    setShowCreateMenu(false);
                    setIsMobileOpen(false);
                  }}
                  className="flex items-center gap-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-white group-hover:text-white">Post</h3>
                    <p className="text-sm text-white/60">Share content across platforms</p>
                  </div>
                </a>
              </Link>

              <button
                onClick={() => {
                  setShowCreateMenu(false);
                  setIsMobileOpen(false);
                }}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all group"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-red-500 to-red-600 flex items-center justify-center">
                  <Radio className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <h3 className="font-semibold text-white group-hover:text-white">Live video</h3>
                  <p className="text-sm text-white/60">Start a live stream</p>
                </div>
              </button>

              <button
                onClick={() => {
                  setShowCreateMenu(false);
                  setIsMobileOpen(false);
                  setShowLaunchTokenModal(true);
                }}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all group"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-teal-400 to-purple-500 flex items-center justify-center">
                  <Coins className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <h3 className="font-semibold text-white group-hover:text-white">Launch Influencer Token</h3>
                  <p className="text-sm text-white/60">Tokenize your influence!</p>
                </div>
              </button>

              <button
                onClick={() => {
                  setShowCreateMenu(false);
                  setIsMobileOpen(false);
                }}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all group"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <h3 className="font-semibold text-white group-hover:text-white">Advertise</h3>
                  <p className="text-sm text-white/60">Promote your content</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Launch Influencer Token Modal */}
      <NewClubModal 
        isOpen={showLaunchTokenModal} 
        onClose={() => setShowLaunchTokenModal(false)}
        title="Launch Influencer Token"
        subtitle="Create your personal $FANS token and start monetizing your influence"
      />
    </>
  );
}