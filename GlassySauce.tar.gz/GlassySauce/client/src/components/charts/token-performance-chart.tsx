import { useMemo } from 'react';

interface TokenPerformanceChartProps {
  width?: number;
  height?: number;
  tokenSymbol?: string;
  currentPrice?: number;
  change?: number;
  changePercent?: number;
  showGrid?: boolean;
  showPrice?: boolean;
  timeframe?: string;
  className?: string;
  variant?: 'default' | 'compact' | 'detailed';
}

export function TokenPerformanceChart({ 
  width = 320, 
  height = 180, 
  tokenSymbol = "BELLA",
  currentPrice = 0.156,
  change = 0.012,
  changePercent = 8.3,
  showGrid = true,
  showPrice = true,
  timeframe = "6M",
  className = "",
  variant = 'default'
}: TokenPerformanceChartProps) {
  
  // Generate realistic token performance data
  const chartData = useMemo(() => {
    const points = variant === 'compact' ? 30 : 60;
    const basePrice = currentPrice * 0.7; // Start lower to show growth
    const result = [];
    let price = basePrice;
    
    for (let i = 0; i < points; i++) {
      const progress = i / (points - 1);
      
      // Create realistic token price movement with phases
      let trend = 0;
      let volatility = 0;
      
      // Phase 1: Initial launch and discovery (0-20%)
      if (progress < 0.2) {
        trend = basePrice * 0.3 * (progress / 0.2); // Gradual initial growth
        volatility = (Math.random() - 0.5) * basePrice * 0.1;
      }
      // Phase 2: Early adoption and hype (20-40%)
      else if (progress < 0.4) {
        const phaseProgress = (progress - 0.2) / 0.2;
        trend = basePrice * (0.3 + 0.4 * phaseProgress); // Steeper growth
        volatility = (Math.random() - 0.5) * basePrice * 0.15;
      }
      // Phase 3: Correction and consolidation (40-60%)
      else if (progress < 0.6) {
        const phaseProgress = (progress - 0.4) / 0.2;
        trend = basePrice * (0.7 - 0.1 * phaseProgress); // Slight pullback
        volatility = (Math.random() - 0.5) * basePrice * 0.12;
      }
      // Phase 4: Mature growth and current rally (60-100%)
      else {
        const phaseProgress = (progress - 0.6) / 0.4;
        trend = basePrice * (0.6 + 0.6 * phaseProgress); // Strong rally to current price
        volatility = (Math.random() - 0.5) * basePrice * 0.08;
      }
      
      price = basePrice + trend + volatility;
      
      // Ensure price doesn't go negative and stays realistic
      price = Math.max(price, basePrice * 0.1);
      result.push(price);
    }
    
    // Ensure the last point matches current price
    result[result.length - 1] = currentPrice;
    return result;
  }, [currentPrice, variant]);

  // Calculate chart boundaries
  const minPrice = Math.min(...chartData);
  const maxPrice = Math.max(...chartData);
  const priceRange = maxPrice - minPrice;
  const padding = priceRange * 0.1;

  // Generate SVG path for price line
  const pathData = useMemo(() => {
    const points = chartData.map((price, index) => {
      const x = (index / (chartData.length - 1)) * width;
      const y = height - ((price - minPrice + padding) / (priceRange + padding * 2)) * height;
      return `${x},${y}`;
    }).join(' L ');
    
    return `M ${points}`;
  }, [chartData, width, height, minPrice, priceRange, padding]);

  // Generate area fill path
  const areaPath = useMemo(() => {
    const points = chartData.map((price, index) => {
      const x = (index / (chartData.length - 1)) * width;
      const y = height - ((price - minPrice + padding) / (priceRange + padding * 2)) * height;
      return `${x},${y}`;
    }).join(' L ');
    
    return `M 0,${height} L ${points} L ${width},${height} Z`;
  }, [chartData, width, height, minPrice, priceRange, padding]);

  // Generate grid lines
  const gridLines = useMemo(() => {
    if (!showGrid) return [];
    
    const lines = [];
    
    // Horizontal grid lines (price levels)
    for (let i = 1; i <= 4; i++) {
      const y = (i / 5) * height;
      lines.push(
        <line 
          key={`h-${i}`} 
          x1={0} 
          y1={y} 
          x2={width} 
          y2={y} 
          stroke="rgba(255,255,255,0.06)" 
          strokeWidth={0.5}
          strokeDasharray="3,3"
        />
      );
    }
    
    // Vertical grid lines (time)
    const verticalCount = variant === 'compact' ? 4 : 6;
    for (let i = 1; i <= verticalCount - 1; i++) {
      const x = (i / verticalCount) * width;
      lines.push(
        <line 
          key={`v-${i}`} 
          x1={x} 
          y1={0} 
          x2={x} 
          y2={height} 
          stroke="rgba(255,255,255,0.06)" 
          strokeWidth={0.5}
          strokeDasharray="3,3"
        />
      );
    }
    
    return lines;
  }, [width, height, showGrid, variant]);

  // Time labels based on timeframe
  const timeLabels = useMemo(() => {
    if (timeframe === '1D') return ['9AM', '12PM', '3PM', '6PM', 'Now'];
    if (timeframe === '1W') return ['Mon', 'Wed', 'Fri', 'Now'];
    if (timeframe === '1M') return ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Now'];
    if (timeframe === '3M') return ['3M', '2M', '1M', 'Now'];
    if (timeframe === '6M') return ['6M', '4M', '2M', 'Now'];
    return ['1Y', '8M', '6M', '4M', '2M', 'Now'];
  }, [timeframe]);

  // Color scheme based on performance
  const isPositive = changePercent > 0;
  const lineColor = isPositive ? "#10b981" : "#ef4444"; // Green for positive, red for negative
  const areaColor = isPositive ? "rgba(16, 185, 129, 0.1)" : "rgba(239, 68, 68, 0.1)";

  return (
    <div className={`relative ${className}`}>
      <svg width={width} height={height} className="overflow-visible">
        {/* Gradient definitions */}
        <defs>
          <linearGradient id={`areaGradient-${tokenSymbol}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={lineColor} stopOpacity={0.2} />
            <stop offset="100%" stopColor={lineColor} stopOpacity={0.0} />
          </linearGradient>
          <linearGradient id={`lineGradient-${tokenSymbol}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={lineColor} stopOpacity={0.8} />
            <stop offset="50%" stopColor={lineColor} stopOpacity={1} />
            <stop offset="100%" stopColor={lineColor} stopOpacity={0.8} />
          </linearGradient>
        </defs>
        
        {/* Grid lines */}
        {gridLines}
        
        {/* Area fill */}
        <path
          d={areaPath}
          fill={`url(#areaGradient-${tokenSymbol})`}
        />
        
        {/* Main price line */}
        <path
          d={pathData}
          fill="none"
          stroke={`url(#lineGradient-${tokenSymbol})`}
          strokeWidth={2}
          className="drop-shadow-sm"
        />
        
        {/* Current price point */}
        <circle
          cx={width}
          cy={height - ((currentPrice - minPrice + padding) / (priceRange + padding * 2)) * height}
          r={3}
          fill={lineColor}
          stroke="white"
          strokeWidth={2}
          className="drop-shadow-sm"
        />
      </svg>
      
      {/* Current price display */}
      {showPrice && (
        <div className="absolute -top-8 right-0">
          <div className={`text-white text-xs font-bold px-2 py-1 rounded ${
            isPositive ? 'bg-green-500' : 'bg-red-500'
          }`}>
            ${currentPrice.toFixed(3)}
          </div>
        </div>
      )}
      
      {/* Performance metrics */}
      {variant === 'detailed' && (
        <div className="absolute top-2 left-2 space-y-1">
          <div className="text-white font-bold text-sm">${tokenSymbol}</div>
          <div className={`text-xs font-medium ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
            {isPositive ? '+' : ''}{change.toFixed(3)} ({isPositive ? '+' : ''}{changePercent.toFixed(1)}%)
          </div>
        </div>
      )}
      
      {/* Time labels */}
      {variant !== 'compact' && (
        <div className="flex justify-between mt-3 text-xs text-white/40 px-1">
          {timeLabels.map((label, index) => (
            <span key={index} className={index === timeLabels.length - 1 ? 'text-white/60 font-medium' : ''}>
              {label}
            </span>
          ))}
        </div>
      )}
      
      {/* Price axis labels */}
      {showGrid && variant === 'detailed' && (
        <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-white/40 -ml-12">
          <span>${maxPrice.toFixed(3)}</span>
          <span>${((maxPrice + minPrice) / 2).toFixed(3)}</span>
          <span>${minPrice.toFixed(3)}</span>
        </div>
      )}
    </div>
  );
}