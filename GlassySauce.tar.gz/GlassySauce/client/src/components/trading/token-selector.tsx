import { useState, useEffect } from 'react';
import { Search, ChevronDown, X, Star } from 'lucide-react';
import { Token, SUPPORTED_CHAINS, getTokensByChain, getPopularTokens, searchTokens, getTokensByCategory } from '@/lib/tokens';
import { GlassCard } from '@/components/ui/glass-card';
import { cn } from '@/lib/utils';

interface TokenSelectorProps {
  selectedToken?: Token;
  onTokenSelect: (token: Token) => void;
  onClose: () => void;
  chainId?: number;
  excludeTokens?: string[];
}

export function TokenSelector({ 
  selectedToken, 
  onTokenSelect, 
  onClose, 
  chainId = 1,
  excludeTokens = []
}: TokenSelectorProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedChain, setSelectedChain] = useState(chainId);
  const [activeTab, setActiveTab] = useState<'popular' | 'all' | 'defi' | 'meme' | 'gaming' | 'ai'>('popular');
  const [tokens, setTokens] = useState<Token[]>([]);
  const [favoriteTokens, setFavoriteTokens] = useState<string[]>([]);

  // Load favorite tokens from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('favoriteTokens');
    if (saved) {
      setFavoriteTokens(JSON.parse(saved));
    }
  }, []);

  // Load tokens based on filters
  useEffect(() => {
    let filteredTokens: Token[] = [];

    if (searchQuery) {
      filteredTokens = searchTokens(searchQuery, selectedChain);
    } else if (activeTab === 'popular') {
      filteredTokens = getPopularTokens(selectedChain);
    } else if (activeTab === 'all') {
      filteredTokens = getTokensByChain(selectedChain);
    } else {
      filteredTokens = getTokensByCategory(activeTab, selectedChain);
    }

    // Filter out excluded tokens
    filteredTokens = filteredTokens.filter(token => 
      !excludeTokens.includes(token.address)
    );

    // Sort by popularity and favorites
    filteredTokens.sort((a, b) => {
      const aIsFavorite = favoriteTokens.includes(a.address);
      const bIsFavorite = favoriteTokens.includes(b.address);
      
      if (aIsFavorite && !bIsFavorite) return -1;
      if (!aIsFavorite && bIsFavorite) return 1;
      if (a.isPopular && !b.isPopular) return -1;
      if (!a.isPopular && b.isPopular) return 1;
      
      return a.symbol.localeCompare(b.symbol);
    });

    setTokens(filteredTokens.slice(0, 100)); // Limit to 100 for performance
  }, [searchQuery, selectedChain, activeTab, excludeTokens, favoriteTokens]);

  const toggleFavorite = (tokenAddress: string) => {
    const newFavorites = favoriteTokens.includes(tokenAddress)
      ? favoriteTokens.filter(addr => addr !== tokenAddress)
      : [...favoriteTokens, tokenAddress];
    
    setFavoriteTokens(newFavorites);
    localStorage.setItem('favoriteTokens', JSON.stringify(newFavorites));
  };

  const handleTokenSelect = (token: Token) => {
    onTokenSelect(token);
    onClose();
  };

  const tabs = [
    { id: 'popular', label: 'Popular' },
    { id: 'all', label: 'All' },
    { id: 'defi', label: 'DeFi' },
    { id: 'meme', label: 'Meme' },
    { id: 'gaming', label: 'Gaming' },
    { id: 'ai', label: 'AI' },
  ] as const;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <GlassCard className="w-full max-w-md max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <h3 className="text-lg font-semibold text-white">Select Token</h3>
          <button
            onClick={onClose}
            className="text-white/60 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
            <input
              type="text"
              placeholder="Search tokens..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-pink-500/50"
            />
          </div>
        </div>

        {/* Chain Selector */}
        <div className="px-4 pb-4">
          <div className="flex gap-2 overflow-x-auto scrollbar-hide">
            {SUPPORTED_CHAINS.map((chain) => (
              <button
                key={chain.id}
                onClick={() => setSelectedChain(chain.id)}
                className={cn(
                  "flex items-center gap-2 px-3 py-2 rounded-lg whitespace-nowrap transition-colors",
                  selectedChain === chain.id
                    ? "bg-pink-500/20 text-pink-400 border border-pink-500/30"
                    : "bg-white/5 text-white/60 hover:text-white hover:bg-white/10"
                )}
              >
                <img src={chain.logoURI} alt={chain.name} className="w-4 h-4" />
                <span className="text-sm">{chain.symbol}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Category Tabs */}
        <div className="px-4 pb-4">
          <div className="flex gap-1 bg-white/5 rounded-lg p-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex-1 px-3 py-2 rounded-md text-xs font-medium transition-colors",
                  activeTab === tab.id
                    ? "bg-pink-500/20 text-pink-400"
                    : "text-white/60 hover:text-white"
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Token List */}
        <div className="flex-1 overflow-y-auto">
          {tokens.length > 0 ? (
            <div className="space-y-1 px-4 pb-4">
              {tokens.map((token) => (
                <div
                  key={`${token.address}-${token.chainId}`}
                  onClick={() => handleTokenSelect(token)}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 cursor-pointer transition-colors group"
                >
                  <div className="relative">
                    <img
                      src={token.logoURI}
                      alt={token.symbol}
                      className="w-8 h-8 rounded-full"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = '/icons/default-token.svg';
                      }}
                    />
                    {token.isPopular && (
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-500 rounded-full flex items-center justify-center">
                        <Star className="w-1.5 h-1.5 text-white" />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-white">{token.symbol}</span>
                      {token.category && (
                        <span className="text-xs px-1.5 py-0.5 bg-white/10 rounded text-white/60">
                          {token.category}
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-white/60 truncate">{token.name}</div>
                    <div className="text-xs text-white/40">{token.chainName}</div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(token.address);
                    }}
                    className={cn(
                      "p-1 rounded transition-colors opacity-0 group-hover:opacity-100",
                      favoriteTokens.includes(token.address)
                        ? "text-yellow-400 opacity-100"
                        : "text-white/40 hover:text-yellow-400"
                    )}
                  >
                    <Star className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-white/60">
              <Search className="w-8 h-8 mb-3" />
              <p>No tokens found</p>
              <p className="text-sm text-white/40">Try adjusting your search or filters</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10">
          <div className="text-center text-xs text-white/40">
            Showing {tokens.length} tokens on {SUPPORTED_CHAINS.find(c => c.id === selectedChain)?.name}
          </div>
        </div>
      </GlassCard>
    </div>
  );
}

// Token Display Component for Trading Interface
export function TokenDisplay({ 
  token, 
  onClick, 
  showBalance = false, 
  balance = '0',
  showChain = false 
}: {
  token?: Token;
  onClick?: () => void;
  showBalance?: boolean;
  balance?: string;
  showChain?: boolean;
}) {
  if (!token) {
    return (
      <button
        onClick={onClick}
        className="flex items-center gap-2 px-3 py-2 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors"
      >
        <div className="w-6 h-6 bg-white/20 rounded-full" />
        <span className="text-white/60">Select Token</span>
        <ChevronDown className="w-4 h-4 text-white/40" />
      </button>
    );
  }

  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 px-3 py-2 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors group"
    >
      <img
        src={token.logoURI}
        alt={token.symbol}
        className="w-6 h-6 rounded-full"
        onError={(e) => {
          const target = e.target as HTMLImageElement;
          target.src = '/icons/default-token.svg';
        }}
      />
      <div className="flex-1 text-left">
        <div className="flex items-center gap-2">
          <span className="font-medium text-white">{token.symbol}</span>
          {showChain && (
            <span className="text-xs text-white/40">{token.chainName}</span>
          )}
        </div>
        {showBalance && (
          <div className="text-xs text-white/60">{balance}</div>
        )}
      </div>
      <ChevronDown className="w-4 h-4 text-white/40 group-hover:text-white/60" />
    </button>
  );
}