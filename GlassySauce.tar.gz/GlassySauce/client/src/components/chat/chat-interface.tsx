import { useState, useEffect, useRef } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Input } from "@/components/ui/input";
import { Send, Users } from "lucide-react";
import { wsManager } from "@/lib/websocket";
import type { ChatMessage, ChatRoom } from "@/types";

interface ChatInterfaceProps {
  room: ChatRoom;
  messages: ChatMessage[];
  onSendMessage: (content: string) => void;
}

export function ChatInterface({ room, messages, onSendMessage }: ChatInterfaceProps) {
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      onSendMessage(newMessage);
      setNewMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  return (
    <div className="lg:col-span-2">
      <GlassCard className="overflow-hidden">
        {/* Chat Header */}
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full gradient-saucy flex items-center justify-center">
              <span className="text-white font-bold">
                {room.creator?.displayName?.substring(0, 2).toUpperCase() || 'CR'}
              </span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">{room.name}</h3>
              <div className="text-white/60 text-sm flex items-center">
                <Users size={14} className="mr-1" />
                {room.memberCount} members • {Math.floor(Math.random() * 50) + 10} online
              </div>
            </div>
          </div>
        </div>
        
        {/* Messages */}
        <div className="h-80 p-6 space-y-4 overflow-y-auto">
          {messages.map((message) => (
            <div key={message.id} className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-full gradient-saucy flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-xs">
                  {message.sender?.username?.charAt(0).toUpperCase() || 'U'}
                </span>
              </div>
              <div className="glass rounded-2xl px-4 py-3 max-w-sm">
                <div className="text-white">{message.content}</div>
                <div className="text-white/50 text-xs mt-1">
                  {formatTime(message.createdAt)}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        {/* Message Input */}
        <div className="p-6 border-t border-white/10">
          <div className="flex items-center space-x-4">
            <div className="flex-1 glass rounded-2xl px-4 py-3">
              <Input
                type="text"
                placeholder="Type your message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                className="bg-transparent text-white border-none outline-none w-full"
              />
            </div>
            <GradientButton
              variant="saucy"
              size="sm"
              onClick={handleSendMessage}
              className="w-12 h-12 rounded-full p-0 flex items-center justify-center"
            >
              <Send size={16} />
            </GradientButton>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}
