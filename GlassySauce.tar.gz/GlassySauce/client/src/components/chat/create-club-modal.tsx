import { useState } from "react";
import { X, Upload } from "lucide-react";
import { GradientButton } from "@/components/ui/gradient-button";
import { FansIcon } from "@/components/ui/crypto-icons";
import { BondingCurve } from "@/components/ui/bonding-curve";

interface CreateClubModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
}

export function CreateClubModal({ isOpen, onClose, title }: CreateClubModalProps) {
  const [clubName, setClubName] = useState("");
  const [clubTicker, setClubTicker] = useState("");
  const [description, setDescription] = useState("");
  const [selectedCurve, setSelectedCurve] = useState("Standard");
  const [keyQuantity, setKeyQuantity] = useState(1);
  const [clubImage, setClubImage] = useState<File | null>(null);

  const priceCurves = [
    { name: "Casual", color: "from-green-400 to-green-600", description: "Lower growth curve" },
    { name: "Standard", color: "from-purple-400 to-purple-600", description: "Balanced growth curve" },
    { name: "Exclusive", color: "from-yellow-400 to-orange-500", description: "Steeper growth curve" }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setClubImage(file);
    }
  };

  const handleCreateClub = () => {
    // Here you would implement the actual club creation logic
    console.log({
      name: clubName,
      ticker: clubTicker,
      description,
      curve: selectedCurve,
      keyQuantity,
      image: clubImage
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full mx-4 overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="text-xl font-semibold text-gray-900">
            {title === "Launch Influencer Token" ? "Launch Token" : "Create club"}
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Club Image Upload */}
          <div className="flex justify-center">
            <div className="relative">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="club-image-upload"
              />
              <label
                htmlFor="club-image-upload"
                className="w-32 h-32 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-gray-400 transition-colors"
              >
                {clubImage ? (
                  <img
                    src={URL.createObjectURL(clubImage)}
                    alt="Club"
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  <>
                    <Upload className="w-6 h-6 text-gray-400 mb-2" />
                    <span className="text-sm text-gray-500 text-center">
                      Tap to add<br />photo
                    </span>
                  </>
                )}
              </label>
            </div>
          </div>

          {/* Name and Ticker */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <input
                type="text"
                placeholder={title === "Launch Influencer Token" ? "Token Name" : "Name"}
                value={clubName}
                onChange={(e) => setClubName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
            <div>
              <input
                type="text"
                placeholder="$TICKER"
                value={clubTicker}
                onChange={(e) => setClubTicker(e.target.value.toUpperCase())}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <textarea
              placeholder={title === "Launch Influencer Token" ? "Describe your token utility and benefits (optional)" : "Add a description for your club (optional)"}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              rows={3}
            />
          </div>

          {/* Price Curve Selection */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Select price curve</h3>
            <div className="grid grid-cols-3 gap-4">
              {priceCurves.map((curve) => (
                <button
                  key={curve.name}
                  onClick={() => setSelectedCurve(curve.name)}
                  className={`p-6 border-2 rounded-xl transition-all ${
                    selectedCurve === curve.name
                      ? "border-purple-500 bg-purple-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  {/* Bonding Curve Visualization */}
                  <div className="w-full h-20 mb-3 flex items-end justify-center">
                    <BondingCurve 
                      type={curve.name as "Casual" | "Standard" | "Exclusive"}
                      width={100}
                      height={60}
                      strokeWidth={4}
                    />
                  </div>
                  <div className="text-base font-semibold text-gray-900">{curve.name}</div>
                </button>
              ))}
            </div>
            <p className="text-sm text-gray-500 mt-3">
              How the price of your club key changes as people trade.
            </p>
            <p className="text-sm text-gray-500">
              Select a curve to estimate price at 50 members.
            </p>
          </div>

          {/* Buy Club Keys */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Buy club keys</h3>
            <p className="text-sm text-gray-500 mb-3">
              Be the first holder of your club key. The first key is free.
            </p>
            
            <div className="flex items-center justify-between py-2">
              <span className="text-gray-700">Quantity:</span>
              <input
                type="number"
                min="1"
                value={keyQuantity}
                onChange={(e) => setKeyQuantity(parseInt(e.target.value) || 1)}
                className="w-20 px-3 py-1 border border-gray-300 rounded text-center focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex justify-between">
                <span>You will spend:</span>
                <div className="flex items-center gap-1">
                  <FansIcon size={16} />
                  <span>--</span>
                </div>
              </div>
              <div className="flex justify-between">
                <span>Your balance:</span>
                <div className="flex items-center gap-1">
                  <FansIcon size={16} />
                  <span>173.0107</span>
                </div>
              </div>
            </div>
          </div>

          {/* Create Button */}
          <GradientButton
            variant="saucy"
            className="w-full"
            onClick={handleCreateClub}
            disabled={!clubName || !clubTicker}
          >
            Create your club
          </GradientButton>

          <p className="text-xs text-gray-500 text-center">
            Once you create your club, you cannot change these details
          </p>
        </div>
      </div>
    </div>
  );
}