import { useState } from "react";
import { X } from "lucide-react";
import { GradientButton } from "@/components/ui/gradient-button";
import { FansIcon } from "@/components/ui/crypto-icons";
import { CreateClubModal } from "./create-club-modal";

interface NewClubModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
}

export function NewClubModal({ isOpen, onClose, title = "Introducing Clubs", subtitle }: NewClubModalProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);

  const handleGotIt = () => {
    setShowCreateForm(true);
  };

  const handleCloseAll = () => {
    setShowCreateForm(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="glass rounded-3xl max-w-lg w-full mx-4 overflow-hidden border border-white/20">
        {/* Header */}
        <div className="flex items-center justify-between p-8 border-b border-white/10">
          <h2 className="text-2xl font-bold text-white">{title}</h2>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-2xl glass hover:bg-white/10 flex items-center justify-center transition-colors"
          >
            <X className="w-6 h-6 text-white/70" />
          </button>
        </div>

        {/* Content */}
        <div className="p-8">
          {/* Icon */}
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 chart-gradient rounded-3xl flex items-center justify-center">
              <FansIcon size={40} className="text-white" />
            </div>
          </div>

          {/* Text Content */}
          <div className="space-y-6 text-center mb-10">
            {title === "Launch Influencer Token" ? (
              <>
                <p className="text-white/80 leading-relaxed text-lg">
                  Launch your personal influencer token and monetize your social media presence like never before.
                </p>
                
                <p className="text-white/80 leading-relaxed text-lg">
                  Your token price increases with each purchase using a bonding curve algorithm that rewards early supporters.
                </p>
                
                <p className="text-white/80 leading-relaxed text-lg">
                  Token holders get exclusive access to your content, private chats, and special perks based on their holdings.
                </p>
                
                <p className="text-white/80 leading-relaxed text-lg">
                  All transactions are powered by <span className="inline-flex items-center gap-2">
                    <FansIcon size={18} />
                    <span className="font-bold chart-gradient text-transparent bg-clip-text">$FANS</span>
                  </span> with transparent fees distributed to creators and the platform.
                </p>
              </>
            ) : (
              <>
                <p className="text-white/80 leading-relaxed text-lg">
                  Clubs are private spaces owned and moderated by keyholders.
                </p>
                
                <p className="text-white/80 leading-relaxed text-lg">
                  Keyholders vote for the club president, who manages the club and chooses moderators.
                </p>
                
                <p className="text-white/80 leading-relaxed text-lg">
                  Club keys are transacted in <span className="inline-flex items-center gap-2">
                    <FansIcon size={18} />
                    <span className="font-bold chart-gradient text-transparent bg-clip-text">$FANS</span>
                  </span>. Each transaction has 1.5% fees that are distributed to farmers and Fans.tech.
                </p>
                
                <p className="text-white/80 leading-relaxed text-lg">
                  Clubs can have the same name, so make sure to always check for its unique FT#
                </p>
              </>
            )}
          </div>

          {/* Got it Button */}
          <GradientButton
            variant="saucy"
            size="lg"
            className="w-full text-lg py-4"
            onClick={handleGotIt}
          >
            {title === "Launch Influencer Token" ? "Launch My Token" : "Got it"}
          </GradientButton>
        </div>
      </div>

      {/* Create Club Modal */}
      <CreateClubModal
        isOpen={showCreateForm}
        onClose={handleCloseAll}
        title={title}
      />
    </div>
  );
}