import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, DollarSign, X } from "lucide-react";

interface BookCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  creator: {
    id: number;
    name: string;
    username: string;
    image: string;
    platform: string;
    responseTime: string;
    averageROI: string;
  };
}

export default function BookCallModal({ isOpen, onClose, creator }: BookCallModalProps) {
  const [formData, setFormData] = useState({
    companyName: "",
    contactEmail: "",
    callType: "",
    preferredDate: "",
    preferredTime: "",
    campaignBudget: "",
    projectDescription: "",
    urgency: "normal"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle booking submission
    console.log("Booking call with:", creator.name, formData);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-gray-900 border-gray-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold flex items-center gap-3">
            <img 
              src={creator.image} 
              alt={creator.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <div>Book Call with {creator.name}</div>
              <div className="text-sm text-gray-400 font-normal">{creator.username} • {creator.platform}</div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Company & Contact Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="companyName" className="text-sm font-medium text-gray-300">
                Company Name *
              </Label>
              <Input
                id="companyName"
                value={formData.companyName}
                onChange={(e) => setFormData({...formData, companyName: e.target.value})}
                placeholder="Your company name"
                className="bg-gray-800 border-gray-600 text-white"
                required
              />
            </div>
            <div>
              <Label htmlFor="contactEmail" className="text-sm font-medium text-gray-300">
                Contact Email *
              </Label>
              <Input
                id="contactEmail"
                type="email"
                value={formData.contactEmail}
                onChange={(e) => setFormData({...formData, contactEmail: e.target.value})}
                placeholder="your.email@company.com"
                className="bg-gray-800 border-gray-600 text-white"
                required
              />
            </div>
          </div>

          {/* Call Type */}
          <div>
            <Label htmlFor="callType" className="text-sm font-medium text-gray-300">
              Call Type *
            </Label>
            <Select value={formData.callType} onValueChange={(value) => setFormData({...formData, callType: value})}>
              <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                <SelectValue placeholder="Select call type" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value="discovery">Discovery Call (30 min)</SelectItem>
                <SelectItem value="strategy">Strategy Session (45 min)</SelectItem>
                <SelectItem value="campaign">Campaign Planning (60 min)</SelectItem>
                <SelectItem value="partnership">Partnership Discussion (30 min)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Scheduling */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="preferredDate" className="text-sm font-medium text-gray-300">
                Preferred Date *
              </Label>
              <Input
                id="preferredDate"
                type="date"
                value={formData.preferredDate}
                onChange={(e) => setFormData({...formData, preferredDate: e.target.value})}
                className="bg-gray-800 border-gray-600 text-white"
                required
              />
            </div>
            <div>
              <Label htmlFor="preferredTime" className="text-sm font-medium text-gray-300">
                Preferred Time *
              </Label>
              <Select value={formData.preferredTime} onValueChange={(value) => setFormData({...formData, preferredTime: value})}>
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue placeholder="Select time" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="9am">9:00 AM</SelectItem>
                  <SelectItem value="10am">10:00 AM</SelectItem>
                  <SelectItem value="11am">11:00 AM</SelectItem>
                  <SelectItem value="12pm">12:00 PM</SelectItem>
                  <SelectItem value="1pm">1:00 PM</SelectItem>
                  <SelectItem value="2pm">2:00 PM</SelectItem>
                  <SelectItem value="3pm">3:00 PM</SelectItem>
                  <SelectItem value="4pm">4:00 PM</SelectItem>
                  <SelectItem value="5pm">5:00 PM</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Campaign Budget */}
          <div>
            <Label htmlFor="campaignBudget" className="text-sm font-medium text-gray-300">
              Campaign Budget Range
            </Label>
            <Select value={formData.campaignBudget} onValueChange={(value) => setFormData({...formData, campaignBudget: value})}>
              <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                <SelectValue placeholder="Select budget range" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value="5k-10k">$5,000 - $10,000</SelectItem>
                <SelectItem value="10k-25k">$10,000 - $25,000</SelectItem>
                <SelectItem value="25k-50k">$25,000 - $50,000</SelectItem>
                <SelectItem value="50k-100k">$50,000 - $100,000</SelectItem>
                <SelectItem value="100k+">$100,000+</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Project Description */}
          <div>
            <Label htmlFor="projectDescription" className="text-sm font-medium text-gray-300">
              Project Description
            </Label>
            <Textarea
              id="projectDescription"
              value={formData.projectDescription}
              onChange={(e) => setFormData({...formData, projectDescription: e.target.value})}
              placeholder="Tell us about your project, goals, and what you're looking for..."
              className="bg-gray-800 border-gray-600 text-white min-h-[100px]"
            />
          </div>

          {/* Urgency */}
          <div>
            <Label htmlFor="urgency" className="text-sm font-medium text-gray-300">
              Urgency Level
            </Label>
            <Select value={formData.urgency} onValueChange={(value) => setFormData({...formData, urgency: value})}>
              <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                <SelectValue placeholder="Select urgency" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value="low">Low - Flexible timing</SelectItem>
                <SelectItem value="normal">Normal - Within 1-2 weeks</SelectItem>
                <SelectItem value="high">High - Within 3-5 days</SelectItem>
                <SelectItem value="urgent">Urgent - ASAP</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Creator Info Summary */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-white">Creator Response Info</h4>
              <div className="text-sm text-gray-400">Expected ROI: {creator.averageROI}</div>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-300">
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                Response Time: {creator.responseTime}
              </div>
              <div className="flex items-center gap-1">
                <DollarSign className="w-4 h-4" />
                Platform Fee: 0.05 ETH
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Book Call
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}