import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  X, 
  Upload, 
  Calendar as CalendarIcon, 
  Users, 
  DollarSign, 
  Target, 
  Clock, 
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Plus,
  Minus
} from "lucide-react";
import { format } from "date-fns";

interface CampaignBuilderModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableCreators: any[];
}

export function CampaignBuilderModal({ isOpen, onClose, availableCreators }: CampaignBuilderModalProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [campaignData, setCampaignData] = useState({
    // Step 1: Basic Info
    title: '',
    description: '',
    campaignType: '',
    objectives: [] as string[],
    targetAudience: '',
    
    // Step 2: Creator Selection
    selectedCreators: [] as any[],
    totalBudget: '',
    budgetAllocation: 'equal',
    
    // Step 3: Timeline & Deliverables
    startDate: undefined as Date | undefined,
    endDate: undefined as Date | undefined,
    deliverables: [] as any[],
    milestones: [] as any[],
    
    // Step 4: Campaign Settings
    paymentTerms: 'milestone',
    contentApproval: true,
    crossPromotion: false,
    performanceTracking: true
  });

  const totalSteps = 4;

  const campaignTypes = [
    { value: 'event', label: 'Event Campaign' },
    { value: 'product', label: 'Product Launch' },
    { value: 'brand', label: 'Brand Awareness' },
    { value: 'influencer', label: 'Influencer Partnership' },
    { value: 'giveaway', label: 'Giveaway Campaign' },
    { value: 'content', label: 'Content Series' }
  ];

  const objectiveOptions = [
    'Brand Awareness',
    'User Acquisition',
    'Engagement',
    'Conversions',
    'App Downloads',
    'Event Attendance',
    'Community Building',
    'Product Launch'
  ];

  const deliverableTypes = [
    { value: 'post', label: 'Social Media Post' },
    { value: 'story', label: 'Story/Highlight' },
    { value: 'video', label: 'Video Content' },
    { value: 'live', label: 'Live Stream' },
    { value: 'review', label: 'Product Review' },
    { value: 'tutorial', label: 'Tutorial/Guide' }
  ];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleCreatorSelect = (creator: any) => {
    const isSelected = campaignData.selectedCreators.find(c => c.id === creator.id);
    if (isSelected) {
      setCampaignData({
        ...campaignData,
        selectedCreators: campaignData.selectedCreators.filter(c => c.id !== creator.id)
      });
    } else {
      setCampaignData({
        ...campaignData,
        selectedCreators: [...campaignData.selectedCreators, creator]
      });
    }
  };

  const addDeliverable = () => {
    const newDeliverable = {
      id: Date.now(),
      type: '',
      description: '',
      dueDate: undefined,
      platform: ''
    };
    setCampaignData({
      ...campaignData,
      deliverables: [...campaignData.deliverables, newDeliverable]
    });
  };

  const removeDeliverable = (id: number) => {
    setCampaignData({
      ...campaignData,
      deliverables: campaignData.deliverables.filter(d => d.id !== id)
    });
  };

  const toggleObjective = (objective: string) => {
    const isSelected = campaignData.objectives.includes(objective);
    if (isSelected) {
      setCampaignData({
        ...campaignData,
        objectives: campaignData.objectives.filter(o => o !== objective)
      });
    } else {
      setCampaignData({
        ...campaignData,
        objectives: [...campaignData.objectives, objective]
      });
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-2">Campaign Basics</h3>
              <p className="text-gray-400">Set up your campaign foundation</p>
            </div>

            {/* Campaign Photo Upload */}
            <div className="space-y-2">
              <Label>Campaign Banner</Label>
              <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center bg-gradient-to-r from-blue-500/10 to-purple-500/10 hover:from-blue-500/20 hover:to-purple-500/20 transition-all cursor-pointer">
                <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-400 mb-2">Upload campaign banner</p>
                <p className="text-sm text-gray-500">PNG, JPG up to 10MB</p>
              </div>
            </div>

            {/* Title */}
            <div className="space-y-2">
              <Label>Campaign Title</Label>
              <Input
                value={campaignData.title}
                onChange={(e) => setCampaignData({...campaignData, title: e.target.value})}
                placeholder="Enter campaign title..."
                className="bg-gray-800 border-gray-700"
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label>Campaign Description</Label>
              <Textarea
                value={campaignData.description}
                onChange={(e) => setCampaignData({...campaignData, description: e.target.value})}
                placeholder="Describe your campaign goals and requirements..."
                className="bg-gray-800 border-gray-700 min-h-[100px]"
              />
            </div>

            {/* Campaign Type */}
            <div className="space-y-2">
              <Label>Campaign Type</Label>
              <Select value={campaignData.campaignType} onValueChange={(value) => setCampaignData({...campaignData, campaignType: value})}>
                <SelectTrigger className="bg-gray-800 border-gray-700">
                  <SelectValue placeholder="Select campaign type" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {campaignTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Objectives */}
            <div className="space-y-2">
              <Label>Campaign Objectives</Label>
              <div className="grid grid-cols-2 gap-2">
                {objectiveOptions.map(objective => (
                  <button
                    key={objective}
                    onClick={() => toggleObjective(objective)}
                    className={`p-3 rounded-lg border text-sm transition-all ${
                      campaignData.objectives.includes(objective)
                        ? 'bg-gradient-to-r from-purple-500 to-teal-500 border-purple-500'
                        : 'bg-gray-800 border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    {objective}
                  </button>
                ))}
              </div>
            </div>

            {/* Target Audience */}
            <div className="space-y-2">
              <Label>Target Audience</Label>
              <Textarea
                value={campaignData.targetAudience}
                onChange={(e) => setCampaignData({...campaignData, targetAudience: e.target.value})}
                placeholder="Describe your target audience demographics, interests, etc..."
                className="bg-gray-800 border-gray-700"
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-2">Creator Selection</h3>
              <p className="text-gray-400">Choose creators for your campaign</p>
            </div>

            {/* Budget Input */}
            <div className="space-y-2">
              <Label>Total Campaign Budget (ETH)</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  type="number"
                  step="0.01"
                  value={campaignData.totalBudget}
                  onChange={(e) => setCampaignData({...campaignData, totalBudget: e.target.value})}
                  placeholder="0.00"
                  className="bg-gray-800 border-gray-700 pl-10"
                />
              </div>
            </div>

            {/* Budget Allocation */}
            <div className="space-y-2">
              <Label>Budget Allocation</Label>
              <Select value={campaignData.budgetAllocation} onValueChange={(value) => setCampaignData({...campaignData, budgetAllocation: value})}>
                <SelectTrigger className="bg-gray-800 border-gray-700">
                  <SelectValue placeholder="Select allocation method" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="equal">Equal Distribution</SelectItem>
                  <SelectItem value="performance">Performance-Based</SelectItem>
                  <SelectItem value="followers">Follower-Based</SelectItem>
                  <SelectItem value="custom">Custom Allocation</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Selected Creators */}
            {campaignData.selectedCreators.length > 0 && (
              <div className="space-y-2">
                <Label>Selected Creators ({campaignData.selectedCreators.length})</Label>
                <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
                  {campaignData.selectedCreators.map(creator => (
                    <div key={creator.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <img src={creator.image} alt={creator.name} className="w-8 h-8 rounded-full" />
                        <div>
                          <p className="font-medium">{creator.name}</p>
                          <p className="text-sm text-gray-400">{creator.followers} followers</p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleCreatorSelect(creator)}
                        className="text-red-400 hover:text-red-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Available Creators */}
            <div className="space-y-2">
              <Label>Available Creators</Label>
              <div className="grid grid-cols-1 gap-2 max-h-64 overflow-y-auto">
                {availableCreators.filter(creator => !campaignData.selectedCreators.find(c => c.id === creator.id)).slice(0, 10).map(creator => (
                  <div key={creator.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                    <div className="flex items-center gap-3">
                      <img src={creator.image} alt={creator.name} className="w-8 h-8 rounded-full" />
                      <div>
                        <p className="font-medium">{creator.name}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-400">
                          <span>{creator.followers} followers</span>
                          <span>•</span>
                          <span>{creator.engagementRate} engagement</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleCreatorSelect(creator)}
                      variant="outline"
                      size="sm"
                      className="border-gray-600"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-2">Timeline & Deliverables</h3>
              <p className="text-gray-400">Set campaign schedule and requirements</p>
            </div>

            {/* Campaign Dates */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left bg-gray-800 border-gray-700"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {campaignData.startDate ? format(campaignData.startDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-gray-800 border-gray-700">
                    <Calendar
                      mode="single"
                      selected={campaignData.startDate}
                      onSelect={(date) => setCampaignData({...campaignData, startDate: date})}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>End Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left bg-gray-800 border-gray-700"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {campaignData.endDate ? format(campaignData.endDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-gray-800 border-gray-700">
                    <Calendar
                      mode="single"
                      selected={campaignData.endDate}
                      onSelect={(date) => setCampaignData({...campaignData, endDate: date})}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Deliverables */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Campaign Deliverables</Label>
                <Button
                  onClick={addDeliverable}
                  variant="outline"
                  size="sm"
                  className="border-gray-600"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add Deliverable
                </Button>
              </div>
              
              {campaignData.deliverables.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <Target className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No deliverables added yet</p>
                  <p className="text-sm">Click "Add Deliverable" to get started</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {campaignData.deliverables.map((deliverable, index) => (
                    <Card key={deliverable.id} className="bg-gray-800/50 border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <h4 className="font-medium">Deliverable {index + 1}</h4>
                          <button
                            onClick={() => removeDeliverable(deliverable.id)}
                            className="text-red-400 hover:text-red-300"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <Label className="text-sm">Type</Label>
                            <Select>
                              <SelectTrigger className="bg-gray-800 border-gray-700">
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                              <SelectContent className="bg-gray-800 border-gray-700">
                                {deliverableTypes.map(type => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label className="text-sm">Platform</Label>
                            <Select>
                              <SelectTrigger className="bg-gray-800 border-gray-700">
                                <SelectValue placeholder="Select platform" />
                              </SelectTrigger>
                              <SelectContent className="bg-gray-800 border-gray-700">
                                <SelectItem value="instagram">Instagram</SelectItem>
                                <SelectItem value="tiktok">TikTok</SelectItem>
                                <SelectItem value="youtube">YouTube</SelectItem>
                                <SelectItem value="twitter">Twitter</SelectItem>
                                <SelectItem value="onlyfans">OnlyFans</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="mt-3 space-y-2">
                          <Label className="text-sm">Description</Label>
                          <Textarea
                            placeholder="Describe the deliverable requirements..."
                            className="bg-gray-800 border-gray-700 text-sm"
                            rows={2}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-2">Campaign Settings</h3>
              <p className="text-gray-400">Configure campaign preferences</p>
            </div>

            {/* Payment Terms */}
            <div className="space-y-2">
              <Label>Payment Terms</Label>
              <Select value={campaignData.paymentTerms} onValueChange={(value) => setCampaignData({...campaignData, paymentTerms: value})}>
                <SelectTrigger className="bg-gray-800 border-gray-700">
                  <SelectValue placeholder="Select payment terms" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="upfront">50% Upfront, 50% on Completion</SelectItem>
                  <SelectItem value="milestone">Milestone-Based Payments</SelectItem>
                  <SelectItem value="completion">Payment on Completion</SelectItem>
                  <SelectItem value="performance">Performance-Based</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Campaign Summary */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-lg">Campaign Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">Campaign Type</p>
                    <p className="font-medium">{campaignTypes.find(t => t.value === campaignData.campaignType)?.label || 'Not selected'}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Total Budget</p>
                    <p className="font-medium">{campaignData.totalBudget || '0'} ETH</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Selected Creators</p>
                    <p className="font-medium">{campaignData.selectedCreators.length} creators</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Deliverables</p>
                    <p className="font-medium">{campaignData.deliverables.length} items</p>
                  </div>
                </div>
                
                {campaignData.objectives.length > 0 && (
                  <div>
                    <p className="text-gray-400 text-sm mb-2">Objectives</p>
                    <div className="flex flex-wrap gap-2">
                      {campaignData.objectives.map(objective => (
                        <Badge key={objective} variant="outline" className="bg-purple-500/20 border-purple-500/50">
                          {objective}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <Separator className="bg-gray-700" />

                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Platform Fees</h4>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Campaign Budget</span>
                    <span>{campaignData.totalBudget || '0'} ETH</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Platform Fee (5%)</span>
                    <span>{(parseFloat(campaignData.totalBudget || '0') * 0.05).toFixed(3)} ETH</span>
                  </div>
                  <div className="flex justify-between font-medium pt-2 border-t border-gray-700">
                    <span>Total Cost</span>
                    <span>{(parseFloat(campaignData.totalBudget || '0') * 1.05).toFixed(3)} ETH</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return campaignData.title && campaignData.campaignType && campaignData.objectives.length > 0;
      case 2:
        return campaignData.selectedCreators.length > 0 && campaignData.totalBudget;
      case 3:
        return campaignData.startDate && campaignData.endDate;
      case 4:
        return true;
      default:
        return false;
    }
  };

  const handleCreateCampaign = () => {
    console.log('Creating campaign:', campaignData);
    // Here you would typically send the data to your backend
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[90vh] overflow-hidden bg-gray-900 border-gray-800">
        <DialogHeader className="border-b border-gray-800 pb-4">
          <DialogTitle className="text-2xl font-bold">Create New Campaign</DialogTitle>
          
          {/* Progress Steps */}
          <div className="flex items-center justify-between mt-4">
            {Array.from({ length: totalSteps }, (_, i) => (
              <div key={i} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  i + 1 <= currentStep 
                    ? 'bg-gradient-to-r from-purple-500 to-teal-500 text-white' 
                    : 'bg-gray-700 text-gray-400'
                }`}>
                  {i + 1 <= currentStep ? (
                    <CheckCircle className="w-4 h-4" />
                  ) : (
                    i + 1
                  )}
                </div>
                {i < totalSteps - 1 && (
                  <div className={`w-12 h-px mx-2 ${
                    i + 1 < currentStep ? 'bg-gradient-to-r from-purple-500 to-teal-500' : 'bg-gray-700'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </DialogHeader>

        {/* Step Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {renderStepContent()}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-800 p-4 flex justify-between">
          <Button
            onClick={handleBack}
            variant="outline"
            className="border-gray-600"
            disabled={currentStep === 1}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="flex gap-2">
            <Button
              onClick={onClose}
              variant="outline"
              className="border-gray-600"
            >
              Cancel
            </Button>
            
            {currentStep < totalSteps ? (
              <Button
                onClick={handleNext}
                disabled={!canProceed()}
                className="bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600"
              >
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button
                onClick={handleCreateCampaign}
                disabled={!canProceed()}
                className="bg-gradient-to-r from-purple-500 to-teal-500 hover:from-purple-600 hover:to-teal-600"
              >
                Create Campaign
                <CheckCircle className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}