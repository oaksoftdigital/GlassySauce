import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Calendar, 
  Users, 
  TrendingUp, 
  DollarSign, 
  Eye, 
  MessageSquare, 
  Share2, 
  MoreHorizontal,
  Play,
  Pause,
  CheckCircle,
  Clock,
  Target,
  BarChart3
} from "lucide-react";
import { format } from "date-fns";

export function CampaignDashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  // Sample campaign data
  const campaigns = [
    {
      id: 1,
      title: "Understanding Web3",
      type: "Event Campaign",
      status: "active",
      budget: "2.5 ETH",
      spent: "1.2 ETH",
      progress: 48,
      startDate: new Date("2024-11-13"),
      endDate: new Date("2024-11-30"),
      creators: [
        { name: "Logan Paul", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop" },
        { name: "Charli D'Amelio", avatar: "https://images.unsplash.com/photo-1494790108755-2616b332446c?w=40&h=40&fit=crop" },
        { name: "Belle Delphine", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=40&h=40&fit=crop" }
      ],
      metrics: {
        reach: "2.4M",
        engagement: "186K",
        conversions: "3.2K",
        roi: "420%"
      },
      deliverables: {
        completed: 8,
        total: 15
      }
    },
    {
      id: 2,
      title: "NFT Collection Launch",
      type: "Product Launch",
      status: "pending",
      budget: "5.0 ETH",
      spent: "0 ETH",
      progress: 0,
      startDate: new Date("2024-12-01"),
      endDate: new Date("2024-12-15"),
      creators: [
        { name: "MrBeast", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop" },
        { name: "Pokimane", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop" }
      ],
      metrics: {
        reach: "0",
        engagement: "0",
        conversions: "0",
        roi: "0%"
      },
      deliverables: {
        completed: 0,
        total: 12
      }
    },
    {
      id: 3,
      title: "DeFi Education Series",
      type: "Content Series",
      status: "completed",
      budget: "3.2 ETH",
      spent: "3.2 ETH",
      progress: 100,
      startDate: new Date("2024-10-15"),
      endDate: new Date("2024-11-10"),
      creators: [
        { name: "Emma Chamberlain", avatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=40&h=40&fit=crop" },
        { name: "James Charles", avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop" }
      ],
      metrics: {
        reach: "5.8M",
        engagement: "340K",
        conversions: "8.1K",
        roi: "680%"
      },
      deliverables: {
        completed: 20,
        total: 20
      }
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'pending': return 'bg-yellow-500';
      case 'completed': return 'bg-blue-500';
      case 'paused': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Play className="w-3 h-3" />;
      case 'pending': return <Clock className="w-3 h-3" />;
      case 'completed': return <CheckCircle className="w-3 h-3" />;
      case 'paused': return <Pause className="w-3 h-3" />;
      default: return <Clock className="w-3 h-3" />;
    }
  };

  const totalBudget = campaigns.reduce((sum, c) => sum + parseFloat(c.budget.replace(' ETH', '')), 0);
  const totalSpent = campaigns.reduce((sum, c) => sum + parseFloat(c.spent.replace(' ETH', '')), 0);
  const activeCampaigns = campaigns.filter(c => c.status === 'active').length;
  const totalReach = campaigns.reduce((sum, c) => {
    const reach = parseFloat(c.metrics.reach.replace('M', '').replace('K', '')) * (c.metrics.reach.includes('M') ? 1000000 : 1000);
    return sum + (isNaN(reach) ? 0 : reach);
  }, 0);

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Total Budget</p>
                <p className="text-2xl font-bold">{totalBudget.toFixed(1)} ETH</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Total Spent</p>
                <p className="text-2xl font-bold">{totalSpent.toFixed(1)} ETH</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Active Campaigns</p>
                <p className="text-2xl font-bold">{activeCampaigns}</p>
              </div>
              <Target className="w-8 h-8 text-teal-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Total Reach</p>
                <p className="text-2xl font-bold">{(totalReach / 1000000).toFixed(1)}M</p>
              </div>
              <Eye className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Campaigns List */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Campaign Management
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-0">
              <div className="p-6">
                <div className="space-y-4">
                  {campaigns.map((campaign) => (
                    <Card key={campaign.id} className="bg-gray-900/50 border-gray-700">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-lg font-semibold">{campaign.title}</h3>
                              <Badge variant="outline" className={`${getStatusColor(campaign.status)} text-white border-0`}>
                                <div className="flex items-center gap-1">
                                  {getStatusIcon(campaign.status)}
                                  {campaign.status}
                                </div>
                              </Badge>
                              <Badge variant="outline" className="border-gray-600 text-gray-300">
                                {campaign.type}
                              </Badge>
                            </div>
                            <p className="text-gray-400 text-sm mb-3">
                              {format(campaign.startDate, "MMM dd")} - {format(campaign.endDate, "MMM dd, yyyy")}
                            </p>
                          </div>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-4">
                          {/* Budget & Progress */}
                          <div className="space-y-2">
                            <p className="text-sm text-gray-400">Budget Progress</p>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{campaign.spent}</span>
                              <span className="text-xs text-gray-400">/ {campaign.budget}</span>
                            </div>
                            <Progress value={campaign.progress} className="h-2" />
                          </div>

                          {/* Deliverables */}
                          <div className="space-y-2">
                            <p className="text-sm text-gray-400">Deliverables</p>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{campaign.deliverables.completed}</span>
                              <span className="text-xs text-gray-400">/ {campaign.deliverables.total}</span>
                            </div>
                            <Progress 
                              value={(campaign.deliverables.completed / campaign.deliverables.total) * 100} 
                              className="h-2" 
                            />
                          </div>

                          {/* Metrics */}
                          <div className="space-y-1">
                            <p className="text-sm text-gray-400">Performance</p>
                            <div className="flex items-center gap-4 text-xs">
                              <div className="flex items-center gap-1">
                                <Eye className="w-3 h-3 text-blue-400" />
                                <span>{campaign.metrics.reach}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <MessageSquare className="w-3 h-3 text-green-400" />
                                <span>{campaign.metrics.engagement}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <TrendingUp className="w-3 h-3 text-purple-400" />
                                <span>{campaign.metrics.roi}</span>
                              </div>
                            </div>
                          </div>

                          {/* Creators */}
                          <div className="space-y-2">
                            <p className="text-sm text-gray-400">Creators ({campaign.creators.length})</p>
                            <div className="flex -space-x-2">
                              {campaign.creators.slice(0, 3).map((creator, index) => (
                                <img
                                  key={index}
                                  src={creator.avatar}
                                  alt={creator.name}
                                  className="w-8 h-8 rounded-full border-2 border-gray-800"
                                  title={creator.name}
                                />
                              ))}
                              {campaign.creators.length > 3 && (
                                <div className="w-8 h-8 rounded-full bg-gray-700 border-2 border-gray-800 flex items-center justify-center text-xs">
                                  +{campaign.creators.length - 3}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex justify-between items-center pt-4 border-t border-gray-700">
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" className="border-gray-600">
                              <Eye className="w-4 h-4 mr-2" />
                              View Details
                            </Button>
                            {campaign.status === 'active' && (
                              <Button variant="outline" size="sm" className="border-gray-600">
                                <Pause className="w-4 h-4 mr-2" />
                                Pause
                              </Button>
                            )}
                            {campaign.status === 'pending' && (
                              <Button variant="outline" size="sm" className="border-gray-600">
                                <Play className="w-4 h-4 mr-2" />
                                Start
                              </Button>
                            )}
                          </div>
                          <div className="text-sm text-gray-400">
                            ROI: <span className="text-green-400 font-medium">{campaign.metrics.roi}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="active" className="mt-0">
              <div className="p-6">
                <div className="space-y-4">
                  {campaigns.filter(c => c.status === 'active').map((campaign) => (
                    <Card key={campaign.id} className="bg-gray-900/50 border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold">{campaign.title}</h3>
                            <p className="text-sm text-gray-400">{campaign.type}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{campaign.spent} / {campaign.budget}</p>
                            <p className="text-xs text-gray-400">{campaign.progress}% complete</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="pending" className="mt-0">
              <div className="p-6">
                <div className="space-y-4">
                  {campaigns.filter(c => c.status === 'pending').map((campaign) => (
                    <Card key={campaign.id} className="bg-gray-900/50 border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold">{campaign.title}</h3>
                            <p className="text-sm text-gray-400">Starts {format(campaign.startDate, "MMM dd, yyyy")}</p>
                          </div>
                          <Button size="sm" className="bg-gradient-to-r from-purple-500 to-teal-500">
                            <Play className="w-4 h-4 mr-2" />
                            Launch
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="completed" className="mt-0">
              <div className="p-6">
                <div className="space-y-4">
                  {campaigns.filter(c => c.status === 'completed').map((campaign) => (
                    <Card key={campaign.id} className="bg-gray-900/50 border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold">{campaign.title}</h3>
                            <p className="text-sm text-gray-400">Completed {format(campaign.endDate, "MMM dd, yyyy")}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-green-400">{campaign.metrics.roi} ROI</p>
                            <p className="text-xs text-gray-400">{campaign.metrics.reach} reach</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}