import { useState } from "react";
import { X, Upload, Calendar, Link as LinkIcon, FileText, Users, Target, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GradientButton } from "@/components/ui/gradient-button";
import { GlassCard } from "@/components/ui/glass-card";
import { Badge } from "@/components/ui/badge";

interface CreateCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CreateCampaignModal({ isOpen, onClose }: CreateCampaignModalProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    title: "",
    spaceLink: "",
    agenda: "",
    date: "",
    time: "",
    duration: "",
    budget: "",
    targetAudience: "",
    campaignType: "",
    description: "",
    requirements: "",
    deliverables: ""
  });

  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Handle campaign creation
      alert("Campaign created successfully!");
      onClose();
    }
  };

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <GlassCard className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div>
            <h2 className="text-2xl font-bold text-white">CREATE A NEW CAMPAIGN</h2>
            <p className="text-white/60 mt-1">Connect with creators and build your brand presence</p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-2xl glass hover:bg-white/10 flex items-center justify-center transition-colors"
          >
            <X className="w-6 h-6 text-white/70" />
          </button>
        </div>

        {/* Progress Indicator */}
        <div className="px-6 py-4 border-b border-white/10">
          <div className="flex items-center gap-4">
            {[1, 2, 3].map((stepNum) => (
              <div key={stepNum} className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  stepNum <= step 
                    ? 'chart-gradient text-white' 
                    : 'bg-white/10 text-white/40'
                }`}>
                  {stepNum}
                </div>
                <span className={`text-sm ${
                  stepNum <= step ? 'text-white' : 'text-white/40'
                }`}>
                  {stepNum === 1 ? 'Basic Info' : stepNum === 2 ? 'Details' : 'Review'}
                </span>
                {stepNum < 3 && (
                  <div className={`w-8 h-0.5 ${
                    stepNum < step ? 'bg-gradient-to-r from-teal-400 to-purple-500' : 'bg-white/10'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Step 1: Basic Information */}
        {step === 1 && (
          <div className="p-6 space-y-6">
            {/* Photo Upload */}
            <div>
              <Label className="text-white/80 text-sm font-medium mb-3 block">CAMPAIGN BANNER</Label>
              <div className="relative">
                <div className={`w-full h-32 rounded-xl border-2 border-dashed border-white/20 flex items-center justify-center cursor-pointer hover:border-white/30 transition-colors ${
                  uploadedImage ? 'bg-cover bg-center' : 'bg-white/5'
                }`}
                style={uploadedImage ? { backgroundImage: `url(${uploadedImage})` } : {}}
                onClick={() => document.getElementById('campaign-image')?.click()}
                >
                  {!uploadedImage && (
                    <div className="text-center">
                      <Upload className="w-8 h-8 text-white/40 mx-auto mb-2" />
                      <p className="text-white/60 text-sm">ADD PHOTO</p>
                    </div>
                  )}
                  <input
                    id="campaign-image"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
                {uploadedImage && (
                  <div className="absolute top-2 right-2 p-2 bg-black/50 rounded-lg">
                    <Upload className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>
            </div>

            {/* Campaign Title */}
            <div>
              <Label className="text-white/80 text-sm font-medium mb-3 block">CAMPAIGN TITLE</Label>
              <Input
                value={formData.title}
                onChange={(e) => updateFormData('title', e.target.value)}
                placeholder="Enter campaign title"
                className="bg-white/5 border-white/10 text-white placeholder-white/40"
              />
            </div>

            {/* Space Link */}
            <div>
              <Label className="text-white/80 text-sm font-medium mb-3 block">SPACE LINK</Label>
              <div className="relative">
                <LinkIcon className="absolute left-3 top-3 w-5 h-5 text-white/40" />
                <Input
                  value={formData.spaceLink}
                  onChange={(e) => updateFormData('spaceLink', e.target.value)}
                  placeholder="https://spaces.fans.tech/..."
                  className="bg-white/5 border-white/10 text-white placeholder-white/40 pl-10"
                />
              </div>
            </div>

            {/* Campaign Type */}
            <div>
              <Label className="text-white/80 text-sm font-medium mb-3 block">CAMPAIGN TYPE</Label>
              <Select value={formData.campaignType} onValueChange={(value) => updateFormData('campaignType', value)}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue placeholder="Select campaign type" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-white/10">
                  <SelectItem value="product-launch">Product Launch</SelectItem>
                  <SelectItem value="brand-awareness">Brand Awareness</SelectItem>
                  <SelectItem value="community-building">Community Building</SelectItem>
                  <SelectItem value="token-promotion">Token Promotion</SelectItem>
                  <SelectItem value="educational">Educational Content</SelectItem>
                  <SelectItem value="ama">AMA Session</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Agenda */}
            <div>
              <Label className="text-white/80 text-sm font-medium mb-3 block">AGENDA</Label>
              <Textarea
                value={formData.agenda}
                onChange={(e) => updateFormData('agenda', e.target.value)}
                placeholder="Describe the campaign agenda and key talking points"
                className="bg-white/5 border-white/10 text-white placeholder-white/40 min-h-[100px]"
              />
            </div>
          </div>
        )}

        {/* Step 2: Campaign Details */}
        {step === 2 && (
          <div className="p-6 space-y-6">
            {/* Date & Time */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white/80 text-sm font-medium mb-3 block">DATE</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 w-5 h-5 text-white/40" />
                  <Input
                    type="date"
                    value={formData.date}
                    onChange={(e) => updateFormData('date', e.target.value)}
                    className="bg-white/5 border-white/10 text-white pl-10"
                  />
                </div>
              </div>
              <div>
                <Label className="text-white/80 text-sm font-medium mb-3 block">TIME</Label>
                <Input
                  type="time"
                  value={formData.time}
                  onChange={(e) => updateFormData('time', e.target.value)}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
            </div>

            {/* Duration & Budget */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white/80 text-sm font-medium mb-3 block">DURATION</Label>
                <Select value={formData.duration} onValueChange={(value) => updateFormData('duration', value)}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="Select duration" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-white/10">
                    <SelectItem value="30min">30 minutes</SelectItem>
                    <SelectItem value="1hour">1 hour</SelectItem>
                    <SelectItem value="1.5hours">1.5 hours</SelectItem>
                    <SelectItem value="2hours">2 hours</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white/80 text-sm font-medium mb-3 block">BUDGET (ETH)</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-3 w-5 h-5 text-white/40" />
                  <Input
                    value={formData.budget}
                    onChange={(e) => updateFormData('budget', e.target.value)}
                    placeholder="0.00"
                    className="bg-white/5 border-white/10 text-white pl-10"
                  />
                </div>
              </div>
            </div>

            {/* Target Audience */}
            <div>
              <Label className="text-white/80 text-sm font-medium mb-3 block">TARGET AUDIENCE</Label>
              <div className="relative">
                <Users className="absolute left-3 top-3 w-5 h-5 text-white/40" />
                <Input
                  value={formData.targetAudience}
                  onChange={(e) => updateFormData('targetAudience', e.target.value)}
                  placeholder="DeFi enthusiasts, NFT collectors, Web3 developers..."
                  className="bg-white/5 border-white/10 text-white placeholder-white/40 pl-10"
                />
              </div>
            </div>

            {/* Campaign Description */}
            <div>
              <Label className="text-white/80 text-sm font-medium mb-3 block">DESCRIPTION</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => updateFormData('description', e.target.value)}
                placeholder="Detailed campaign description, goals, and expectations"
                className="bg-white/5 border-white/10 text-white placeholder-white/40 min-h-[120px]"
              />
            </div>

            {/* Requirements */}
            <div>
              <Label className="text-white/80 text-sm font-medium mb-3 block">CREATOR REQUIREMENTS</Label>
              <Textarea
                value={formData.requirements}
                onChange={(e) => updateFormData('requirements', e.target.value)}
                placeholder="Minimum followers, engagement rate, content style, etc."
                className="bg-white/5 border-white/10 text-white placeholder-white/40 min-h-[80px]"
              />
            </div>
          </div>
        )}

        {/* Step 3: Review & Submit */}
        {step === 3 && (
          <div className="p-6 space-y-6">
            <div className="text-center mb-6">
              <h3 className="text-xl font-semibold text-white mb-2">Review Your Campaign</h3>
              <p className="text-white/60">Make sure all details are correct before launching</p>
            </div>

            <div className="space-y-4">
              {/* Campaign Overview */}
              <div className="bg-white/5 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 chart-gradient rounded-lg flex items-center justify-center">
                    <Target className="w-5 h-5 text-white" />
                  </div>
                  <h4 className="text-white font-medium">Campaign Overview</h4>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60">Title:</span>
                    <span className="text-white">{formData.title || "Not set"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Type:</span>
                    <Badge className="bg-white/10 text-white">{formData.campaignType || "Not set"}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Budget:</span>
                    <span className="text-white">{formData.budget ? `${formData.budget} ETH` : "Not set"}</span>
                  </div>
                </div>
              </div>

              {/* Schedule */}
              <div className="bg-white/5 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 chart-gradient rounded-lg flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-white" />
                  </div>
                  <h4 className="text-white font-medium">Schedule</h4>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60">Date:</span>
                    <span className="text-white">{formData.date || "Not set"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Time:</span>
                    <span className="text-white">{formData.time || "Not set"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Duration:</span>
                    <span className="text-white">{formData.duration || "Not set"}</span>
                  </div>
                </div>
              </div>

              {/* Estimated Reach */}
              <div className="bg-white/5 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 chart-gradient rounded-lg flex items-center justify-center">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                  <h4 className="text-white font-medium">Estimated Reach</h4>
                </div>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-white">12K+</div>
                    <div className="text-xs text-white/60">Potential Viewers</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">85%</div>
                    <div className="text-xs text-white/60">Engagement Rate</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">24</div>
                    <div className="text-xs text-white/60">Matching Creators</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-6 border-t border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {step > 1 && (
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  className="border-white/20 text-white hover:bg-white/10"
                >
                  Previous
                </Button>
              )}
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm text-white/60">
                Step {step} of 3
              </div>
              <GradientButton
                onClick={handleNext}
                className="px-8"
                disabled={!formData.title && step === 1}
              >
                {step === 3 ? 'Launch Campaign' : 'Next'}
              </GradientButton>
            </div>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}