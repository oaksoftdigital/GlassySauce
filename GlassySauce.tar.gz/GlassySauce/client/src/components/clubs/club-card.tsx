import { Link } from "wouter";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Users, TrendingUp, MessageCircle, Star } from "lucide-react";

interface ClubCardProps {
  club: {
    id: number;
    name: string;
    creator: string;
    creatorId: number;
    description: string;
    profileImage: string;
    memberCount: number;
    keyPrice: string;
    priceChange24h: number;
    totalValue: string;
    isActive: boolean;
  };
  rank?: number;
}

export function ClubCard({ club, rank }: ClubCardProps) {
  const formatPrice = (price: string) => {
    return parseFloat(price).toFixed(3);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  return (
    <Link href={`/club/${club.id}`}>
      <GlassCard hover className="overflow-hidden group cursor-pointer transition-transform hover:scale-[1.02]">
        <div className="relative">
          {/* Club Banner */}
          <div className="h-32 bg-gradient-to-r from-cyan-500/20 to-purple-600/20 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50"></div>
            {club.isActive && (
              <div className="absolute top-3 left-3 flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-white text-xs font-medium glass px-2 py-1 rounded-full">
                  ACTIVE
                </span>
              </div>
            )}
            {rank && (
              <div className="absolute top-3 right-3">
                <Badge className="bg-gradient-to-r from-cyan-500 to-purple-600 text-white border-0 font-bold">
                  #{rank}
                </Badge>
              </div>
            )}
          </div>

          {/* Club Avatar */}
          <div className="absolute -bottom-12 left-6">
            <div className="w-24 h-24 rounded-2xl border-4 border-white/20 overflow-hidden">
              <img
                src={club.profileImage}
                alt={club.name}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
        
        <div className="pt-16 p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="flex items-center space-x-2 mb-1">
                <h3 className="text-lg font-bold text-white group-hover:gradient-text transition-all">
                  {club.name}
                </h3>
                <Badge className="bg-gradient-to-r from-pink-500 to-purple-600 text-white border-0 text-xs">
                  CLUB
                </Badge>
              </div>
              <p className="text-sm text-white/60">@{club.creator}</p>
              <p className="text-sm text-white/70 mt-1">{club.description}</p>
            </div>
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-sm text-white/70">{Math.floor(Math.random() * 50) + 20}</span>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <div>
                <span className="text-white font-medium">{formatNumber(club.memberCount)}</span>
                <span className="text-white/60 text-sm ml-1">members</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              <div>
                <span className="text-white font-medium">{formatPrice(club.keyPrice)} ETH</span>
                <span className="text-white/60 text-sm ml-1">per key</span>
              </div>
            </div>
          </div>

          {/* Price Change */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <span className="text-white/60 text-sm">24h change:</span>
              <span className={`text-sm font-medium ${
                club.priceChange24h > 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {club.priceChange24h > 0 ? '+' : ''}{club.priceChange24h.toFixed(1)}%
              </span>
            </div>
            <div className="text-right">
              <span className="text-white/60 text-sm">Total Value:</span>
              <span className="text-white font-medium text-sm ml-1">{club.totalValue} ETH</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex space-x-2">
            <GradientButton size="sm" className="flex-1 flex items-center justify-center space-x-1">
              <MessageCircle className="w-4 h-4" />
              <span>Join Chat</span>
            </GradientButton>
            <GradientButton size="sm" variant="glass" className="flex-1 flex items-center justify-center space-x-1">
              <TrendingUp className="w-4 h-4" />
              <span>Buy Keys</span>
            </GradientButton>
          </div>
        </div>
      </GlassCard>
    </Link>
  );
}