import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { Badge } from "@/components/ui/badge";
import { GradientButton } from "@/components/ui/gradient-button";
import { 
  Bell, 
  X, 
  Heart, 
  MessageCircle, 
  TrendingUp, 
  Users, 
  Crown,
  Zap,
  DollarSign,
  Star
} from "lucide-react";

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NotificationPanel({ isOpen, onClose }: NotificationPanelProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'trading' | 'social' | 'system'>('all');

  if (!isOpen) return null;

  const notifications = [
    {
      id: 1,
      type: 'trading',
      icon: TrendingUp,
      title: 'Token Price Alert',
      message: 'Sophia Rose token increased by 15%',
      time: '2 min ago',
      unread: true,
      color: 'text-green-400',
      bgColor: 'bg-green-500/20'
    },
    {
      id: 2,
      type: 'social',
      icon: Heart,
      title: 'New Like',
      message: 'Emma liked your message in Sophia Rose chat',
      time: '5 min ago',
      unread: true,
      color: 'text-pink-400',
      bgColor: 'bg-pink-500/20'
    },
    {
      id: 3,
      type: 'trading',
      icon: DollarSign,
      title: 'Trade Executed',
      message: 'Successfully bought 50 tokens of Ava Chen',
      time: '10 min ago',
      unread: false,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    },
    {
      id: 4,
      type: 'social',
      icon: MessageCircle,
      title: 'New Message',
      message: 'Luna Martinez sent you a private message',
      time: '15 min ago',
      unread: true,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20'
    },
    {
      id: 5,
      type: 'system',
      icon: Crown,
      title: 'VIP Status',
      message: 'You\'ve been upgraded to VIP member!',
      time: '1 hour ago',
      unread: false,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-500/20'
    },
    {
      id: 6,
      type: 'social',
      icon: Users,
      title: 'Community Milestone',
      message: 'Sophia Rose community reached 1000 members',
      time: '2 hours ago',
      unread: false,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    },
  ];

  const tabs = [
    { id: 'all', name: 'All', count: notifications.length },
    { id: 'trading', name: 'Trading', count: notifications.filter(n => n.type === 'trading').length },
    { id: 'social', name: 'Social', count: notifications.filter(n => n.type === 'social').length },
    { id: 'system', name: 'System', count: notifications.filter(n => n.type === 'system').length },
  ];

  const filteredNotifications = activeTab === 'all' 
    ? notifications 
    : notifications.filter(n => n.type === activeTab);

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end p-4 bg-black/30 backdrop-blur-sm">
      <GlassCard className="w-full max-w-md h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Bell className="w-6 h-6 text-white" />
              {unreadCount > 0 && (
                <div className="absolute -top-2 -right-2 w-5 h-5 bg-pink-500 rounded-full flex items-center justify-center">
                  <span className="text-xs text-white font-bold">{unreadCount}</span>
                </div>
              )}
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Notifications</h2>
              <p className="text-white/60 text-sm">{unreadCount} unread</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/60 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex space-x-1 p-4 border-b border-white/10">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-pink-500/20 to-purple-500/20 text-white ring-1 ring-pink-500/30'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.name}
              {tab.count > 0 && (
                <Badge className="ml-2 text-xs bg-white/10">
                  {tab.count}
                </Badge>
              )}
            </button>
          ))}
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto">
          {filteredNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-8">
              <Bell className="w-12 h-12 text-white/30 mb-4" />
              <p className="text-white/60 text-center">No notifications yet</p>
              <p className="text-white/40 text-sm text-center mt-2">
                We'll notify you when something happens
              </p>
            </div>
          ) : (
            <div className="p-4 space-y-3">
              {filteredNotifications.map((notification) => {
                const Icon = notification.icon;
                return (
                  <div
                    key={notification.id}
                    className={`glass-dark rounded-2xl p-4 hover:bg-white/5 transition-all cursor-pointer border-l-4 ${
                      notification.unread 
                        ? 'border-pink-500 bg-gradient-to-r from-pink-500/5 to-purple-500/5' 
                        : 'border-transparent'
                    }`}
                  >
                    <div className="flex space-x-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${notification.bgColor}`}>
                        <Icon className={`w-5 h-5 ${notification.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <h3 className="text-white font-medium text-sm">
                            {notification.title}
                            {notification.unread && (
                              <span className="ml-2 w-2 h-2 bg-pink-500 rounded-full inline-block"></span>
                            )}
                          </h3>
                          <span className="text-white/40 text-xs whitespace-nowrap ml-2">
                            {notification.time}
                          </span>
                        </div>
                        <p className="text-white/70 text-sm mt-1 leading-snug">
                          {notification.message}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-white/10 space-y-3">
          <div className="flex space-x-3">
            <GradientButton variant="glass" size="sm" className="flex-1">
              Mark All Read
            </GradientButton>
            <GradientButton variant="saucy" size="sm" className="flex-1">
              Settings
            </GradientButton>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}