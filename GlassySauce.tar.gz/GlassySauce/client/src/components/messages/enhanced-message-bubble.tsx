import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Heart, Reply, MoreHorizontal } from "lucide-react";
import { useState } from "react";
import type { ChatMessage, User } from "@/types";

interface EnhancedMessageBubbleProps {
  message: ChatMessage;
  sender: User;
  isOwnMessage?: boolean;
  showAvatar?: boolean;
}

export function EnhancedMessageBubble({ 
  message, 
  sender, 
  isOwnMessage = false,
  showAvatar = true 
}: EnhancedMessageBubbleProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likes] = useState(Math.floor(Math.random() * 12) + 1);

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  const getCreatorBadge = (sender: User) => {
    if (sender.isCreator) {
      return <Badge className="bg-gradient-to-r from-pink-500 to-purple-600 text-white text-xs ml-2">Creator</Badge>;
    }
    return null;
  };

  const getMessageStyle = () => {
    if (isOwnMessage) {
      return "bg-gradient-to-r from-pink-500 to-purple-600 text-white ml-auto";
    }
    return "glass text-white";
  };

  return (
    <div className={`flex items-start space-x-3 group ${isOwnMessage ? 'flex-row-reverse space-x-reverse' : ''}`}>
      {showAvatar && !isOwnMessage && (
        <Avatar className="w-12 h-12 flex-shrink-0">
          <AvatarImage src={sender.avatar} />
          <AvatarFallback className="bg-gradient-to-r from-pink-500 to-purple-600 text-white text-sm">
            {sender.username?.charAt(0).toUpperCase() || 'U'}
          </AvatarFallback>
        </Avatar>
      )}
      
      <div className={`max-w-sm ${isOwnMessage ? 'ml-auto' : ''}`}>
        {!isOwnMessage && (
          <div className="flex items-center mb-1">
            <span className="text-sm font-medium text-white/90">
              {sender.username}
            </span>
            {getCreatorBadge(sender)}
          </div>
        )}
        
        <div className={`rounded-2xl px-4 py-3 relative group/message ${getMessageStyle()}`}>
          <div className="text-sm leading-relaxed">
            {message.content}
          </div>
          
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs opacity-70">
              {formatTime(message.createdAt)}
            </span>
            
            <div className="flex items-center space-x-2 opacity-0 group-hover/message:opacity-100 transition-opacity">
              <button
                onClick={() => setIsLiked(!isLiked)}
                className={`flex items-center space-x-1 text-xs transition-colors ${
                  isLiked ? 'text-pink-400' : 'text-white/60 hover:text-pink-400'
                }`}
              >
                <Heart className={`w-3 h-3 ${isLiked ? 'fill-pink-400' : ''}`} />
                <span>{likes + (isLiked ? 1 : 0)}</span>
              </button>
              
              <button className="text-white/60 hover:text-white transition-colors">
                <Reply className="w-3 h-3" />
              </button>
              
              <button className="text-white/60 hover:text-white transition-colors">
                <MoreHorizontal className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {showAvatar && isOwnMessage && (
        <Avatar className="w-12 h-12 flex-shrink-0">
          <AvatarImage src={sender.avatar} />
          <AvatarFallback className="bg-gradient-to-r from-pink-500 to-purple-600 text-white text-sm">
            {sender.username?.charAt(0).toUpperCase() || 'U'}
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
}