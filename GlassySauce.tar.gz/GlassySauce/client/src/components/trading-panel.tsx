import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { ArrowUpDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { EthereumIcon, FansIcon } from "@/components/ui/crypto-icons";

export function TradingPanel() {
  const [isBuying, setIsBuying] = useState(true);
  const [payAmount, setPayAmount] = useState("");
  const [receiveAmount, setReceiveAmount] = useState("");

  const handleSwap = () => {
    setIsBuying(!isBuying);
    const temp = payAmount;
    setPayAmount(receiveAmount);
    setReceiveAmount(temp);
  };

  return (
    <GlassCard className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-bold text-white">Trade Tokens</h3>
        <div className="flex space-x-2">
          <GradientButton
            variant={isBuying ? "saucy" : "glass"}
            size="sm"
            onClick={() => setIsBuying(true)}
          >
            Buy
          </GradientButton>
          <GradientButton
            variant={!isBuying ? "saucy" : "glass"}
            size="sm"
            onClick={() => setIsBuying(false)}
          >
            Sell
          </GradientButton>
        </div>
      </div>
      
      <div className="space-y-6">
        <div>
          <label className="block text-white/70 mb-2">You Pay</label>
          <div className="glass rounded-2xl p-4 flex justify-between items-center">
            <Input
              type="text"
              placeholder="0.0"
              value={payAmount}
              onChange={(e) => setPayAmount(e.target.value)}
              className="bg-transparent text-white text-xl font-semibold border-none outline-none flex-1"
            />
            <div className="flex items-center space-x-2">
              <span className="text-white font-medium">ETH</span>
              <EthereumIcon size={24} />
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <button
            onClick={handleSwap}
            className="w-12 h-12 glass rounded-full text-white hover:bg-white/20 transition-all flex items-center justify-center"
          >
            <ArrowUpDown size={20} />
          </button>
        </div>
        
        <div>
          <label className="block text-white/70 mb-2">You Get</label>
          <div className="glass rounded-2xl p-4 flex justify-between items-center">
            <Input
              type="text"
              placeholder="0.0"
              value={receiveAmount}
              onChange={(e) => setReceiveAmount(e.target.value)}
              className="bg-transparent text-white text-xl font-semibold border-none outline-none flex-1"
            />
            <div className="flex items-center space-x-2">
              <span className="text-white font-medium">$FANS</span>
              <FansIcon size={24} />
            </div>
          </div>
        </div>
        
        <GradientButton variant="saucy" className="w-full" size="lg">
          {isBuying ? "Buy Tokens" : "Sell Tokens"}
        </GradientButton>
        
        <GlassCard className="p-4 space-y-2 text-sm">
          <div className="flex justify-between text-white/70">
            <span>Price Impact</span>
            <span className="gradient-text">~2.1%</span>
          </div>
          <div className="flex justify-between text-white/70">
            <span>Trading Fee</span>
            <span>0.5%</span>
          </div>
          <div className="flex justify-between text-white/70">
            <span>Creator Fee</span>
            <span>5%</span>
          </div>
        </GlassCard>
      </div>
    </GlassCard>
  );
}
