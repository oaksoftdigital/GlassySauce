import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Upload, X } from "lucide-react";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";

interface CreateEventModalProps {
  onClose: () => void;
}

export function CreateEventModal({ onClose }: CreateEventModalProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    title: "",
    spaceLink: "",
    agenda: "",
    date: undefined as Date | undefined,
    time: "20:00",
    duration: "60",
    maxSlots: "20",
    pricePerSlot: "10",
    imageUrl: ""
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (step === 1) {
      setStep(2);
    } else {
      // Handle form submission
      console.log("Creating event:", formData);
      onClose();
    }
  };

  const handleImageUpload = () => {
    // Mock image upload - in real app would handle file upload
    const mockImageUrl = "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=200&fit=crop";
    setFormData(prev => ({ ...prev, imageUrl: mockImageUrl }));
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold">
              CREATE A NEW CAMPAIGN
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        {step === 1 && (
          <div className="space-y-6">
            {/* Image Upload */}
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-300">ADD PHOTO</Label>
              <div
                className="relative h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                onClick={handleImageUpload}
              >
                {formData.imageUrl ? (
                  <img
                    src={formData.imageUrl}
                    alt="Event banner"
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Upload className="h-6 w-6 text-white" />
                  </div>
                )}
                <div className="absolute top-3 right-3 bg-black/50 rounded-full p-2">
                  <Upload className="h-4 w-4 text-white" />
                </div>
              </div>
            </div>

            {/* Title */}
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-300">TITLE</Label>
              <Input
                value={formData.title}
                onChange={(e) => handleInputChange("title", e.target.value)}
                placeholder="Understanding Web3"
                className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              />
            </div>

            {/* Space Link */}
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-300">SPACE LINK</Label>
              <Input
                value={formData.spaceLink}
                onChange={(e) => handleInputChange("spaceLink", e.target.value)}
                placeholder="https://x.com/v_j_yuw"
                className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              />
            </div>

            {/* Agenda */}
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-300">AGENDA</Label>
              <Textarea
                value={formData.agenda}
                onChange={(e) => handleInputChange("agenda", e.target.value)}
                placeholder="Web3 Demo"
                className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 min-h-[100px]"
              />
            </div>

            {/* Date */}
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-300">DATE</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal bg-gray-700 border-gray-600 text-white hover:bg-gray-600"
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {formData.date ? format(formData.date, "dd/MM/yyyy") : "dd/mm/yyyy"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-gray-800 border-gray-700">
                  <CalendarComponent
                    mode="single"
                    selected={formData.date}
                    onSelect={(date) => setFormData(prev => ({ ...prev, date }))}
                    initialFocus
                    className="bg-gray-800 text-white"
                  />
                </PopoverContent>
              </Popover>
            </div>

            <Button 
              onClick={handleNext}
              className="w-full bg-white text-black hover:bg-gray-200 font-medium"
            >
              NEXT
            </Button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h3 className="text-lg font-semibold mb-2">Event Details</h3>
              <p className="text-gray-400">Configure your event settings</p>
            </div>

            {/* Time & Duration */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-300">TIME (UTC)</Label>
                <Input
                  type="time"
                  value={formData.time}
                  onChange={(e) => handleInputChange("time", e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-300">DURATION (MINUTES)</Label>
                <Input
                  type="number"
                  value={formData.duration}
                  onChange={(e) => handleInputChange("duration", e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            {/* Slots & Price */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-300">AMOUNT OF SLOTS</Label>
                <Input
                  type="number"
                  value={formData.maxSlots}
                  onChange={(e) => handleInputChange("maxSlots", e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-300">PRICE/SLOT</Label>
                <Input
                  type="number"
                  value={formData.pricePerSlot}
                  onChange={(e) => handleInputChange("pricePerSlot", e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button 
                onClick={() => setStep(1)}
                variant="outline"
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Back
              </Button>
              <Button 
                onClick={handleNext}
                className="flex-1 bg-white text-black hover:bg-gray-200 font-medium"
              >
                Create Event
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}