import { useState } from "react";
import { X, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { GlassCard } from "@/components/ui/glass-card";

interface ReviewModalProps {
  host: {
    id: number;
    name: string;
    username: string;
    bio: string;
    image: string;
    followers: string;
    posts: string;
    holders: string;
    rating: number;
    categories: string[];
    verified: boolean;
  };
  onClose: () => void;
}

export function ReviewModal({ host, onClose }: ReviewModalProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [review, setReview] = useState("");

  const handleSubmit = () => {
    if (rating === 0) {
      alert("Please select a rating");
      return;
    }
    
    // Handle review submission
    console.log("Review submitted:", {
      hostId: host.id,
      rating,
      review,
      timestamp: new Date().toISOString()
    });
    
    alert("Review submitted successfully!");
    onClose();
  };

  const reviewCriteria = [
    "Moderation",
    "Speaker quality", 
    "Value gain"
  ];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <GlassCard className="w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <h2 className="text-xl font-bold text-white">LEAVE REVIEW</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-white/10 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5 text-white/70" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Host Info */}
          <div className="flex items-center gap-3">
            <div className="text-lg font-semibold text-white">{host.name}</div>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/50 text-xs">
              Host
            </Badge>
          </div>

          {/* Star Rating */}
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                className="transition-all duration-200 hover:scale-110"
              >
                <Star
                  className={`w-8 h-8 ${
                    star <= (hoveredRating || rating)
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-white/30 hover:text-white/50"
                  }`}
                />
              </button>
            ))}
          </div>

          {/* Review Criteria */}
          <div>
            <h3 className="text-white/80 text-sm mb-3">Some things to think about in your review</h3>
            <div className="flex flex-wrap gap-2">
              {reviewCriteria.map((criterion) => (
                <span
                  key={criterion}
                  className="px-3 py-1 bg-white/10 rounded-full text-white/70 text-sm"
                >
                  {criterion}
                </span>
              ))}
            </div>
          </div>

          {/* Review Text */}
          <div>
            <Textarea
              value={review}
              onChange={(e) => setReview(e.target.value)}
              placeholder="Write your review here"
              className="bg-white/5 border-white/10 text-white placeholder-white/40 min-h-[120px] resize-none"
            />
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            className="w-full bg-white text-black hover:bg-gray-200 font-medium py-3 rounded-lg"
            disabled={rating === 0}
          >
            SUBMIT
          </Button>
        </div>
      </GlassCard>
    </div>
  );
}