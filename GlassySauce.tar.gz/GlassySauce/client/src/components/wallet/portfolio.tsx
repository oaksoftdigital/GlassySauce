import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Plus } from "lucide-react";
import type { Portfolio } from "@/types";

interface PortfolioProps {
  portfolio: Portfolio;
}

export function PortfolioComponent({ portfolio }: PortfolioProps) {
  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(amount));
  };

  const formatPercentage = (change: string) => {
    const num = parseFloat(change);
    return `${num >= 0 ? '+' : ''}${num.toFixed(1)}%`;
  };

  return (
    <GlassCard className="p-8 mb-8">
      <div className="flex justify-between items-center mb-8">
        <h3 className="text-2xl font-bold text-white">Portfolio Balance</h3>
        <GradientButton variant="glass" size="sm">
          <Plus size={16} className="mr-2" />
          Add Funds
        </GradientButton>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <GlassCard className="p-6 text-center">
          <div className="text-3xl font-bold gradient-text mb-2">
            {formatCurrency(portfolio.totalValue)}
          </div>
          <div className="text-white/70">Total Value</div>
        </GlassCard>
        <GlassCard className="p-6 text-center">
          <div className={`text-3xl font-bold mb-2 ${
            parseFloat(portfolio.dayChange) >= 0 ? 'text-green-400' : 'text-red-400'
          }`}>
            {formatPercentage(portfolio.dayChange)}
          </div>
          <div className="text-white/70">24h Change</div>
        </GlassCard>
        <GlassCard className="p-6 text-center">
          <div className="text-3xl font-bold gradient-text mb-2">
            {portfolio.keysOwned}
          </div>
          <div className="text-white/70">Keys Owned</div>
        </GlassCard>
      </div>
      
      {/* Token Holdings */}
      <div>
        <h4 className="text-xl font-bold text-white mb-4">Your Holdings</h4>
        <div className="space-y-4">
          {portfolio.holdings.map((holding, index) => (
            <GlassCard key={index} className="p-4 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-full gradient-saucy flex items-center justify-center">
                  <span className="text-white font-bold">
                    {holding.creator.displayName.substring(0, 2).toUpperCase()}
                  </span>
                </div>
                <div>
                  <div className="text-white font-semibold">{holding.creator.displayName}</div>
                  <div className="text-white/60 text-sm">{holding.tokens} keys</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white font-semibold">{formatCurrency(holding.value)}</div>
                <div className={`text-sm ${
                  parseFloat(holding.change) >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  {formatPercentage(holding.change)}
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </GlassCard>
  );
}
