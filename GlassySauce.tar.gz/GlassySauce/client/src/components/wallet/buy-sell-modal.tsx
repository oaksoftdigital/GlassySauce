import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { X, ShoppingCart, TrendingDown, ArrowUpDown } from "lucide-react";
import { FansIcon, EthereumIcon } from "@/components/ui/crypto-icons";

interface BuySellModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BuySellModal({ isOpen, onClose }: BuySellModalProps) {
  const [buyAmount, setBuyAmount] = useState("");
  const [sellAmount, setSellAmount] = useState("");
  const [activeTab, setActiveTab] = useState("buy");

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <GlassCard className="w-full max-w-md p-6 relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Swap for $FANS</h2>
          <button
            onClick={onClose}
            className="text-white/60 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="buy" className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              Buy
            </TabsTrigger>
            <TabsTrigger value="sell" className="flex items-center gap-2">
              <TrendingDown className="w-4 h-4" />
              Sell
            </TabsTrigger>
          </TabsList>

          <TabsContent value="buy" className="space-y-4">
            {/* Price Info */}
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/70">Current Price</span>
                <span className="text-cyan-400 font-bold">$0.03</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/70">24h Change</span>
                <span className="text-green-400">+12.5%</span>
              </div>
            </div>

            {/* ETH Amount Input */}
            <div>
              <label className="text-white/70 text-sm mb-2 block">Pay with ETH</label>
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <input
                    type="text"
                    placeholder="0.0"
                    value={buyAmount}
                    onChange={(e) => setBuyAmount(e.target.value)}
                    className="bg-transparent text-2xl font-bold text-white placeholder-white/40 outline-none flex-1"
                  />
                  <div className="flex items-center gap-2">
                    <EthereumIcon size={24} />
                    <span className="text-white font-medium">ETH</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-white/60 text-sm">
                    <div className="w-3 h-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full"></div>
                    <span>0.005 available</span>
                  </div>
                  <button 
                    onClick={() => setBuyAmount("0.005")}
                    className="text-pink-400 hover:text-pink-300 text-sm"
                  >
                    Max
                  </button>
                </div>
              </div>
            </div>

            {/* Estimated FRIEND */}
            <div className="bg-white/5 border border-white/10 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <span className="text-white/70">You'll receive</span>
                <div className="flex items-center gap-2">
                  <span className="text-cyan-400 font-bold">
                    {buyAmount ? (parseFloat(buyAmount) * 33.33).toFixed(2) : "0.00"}
                  </span>
                  <FansIcon size={20} className="inline-block" />
                  <span className="text-white">$FANS</span>
                </div>
              </div>
            </div>

            {/* Buy Button */}
            <GradientButton 
              variant="saucy" 
              className="w-full h-12 text-lg font-semibold"
              onClick={() => {
                alert(`Buying ${buyAmount} ETH worth of $FRIEND tokens`);
                onClose();
              }}
            >
              Buy $FANS
            </GradientButton>
          </TabsContent>

          <TabsContent value="sell" className="space-y-4">
            {/* Price Info */}
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/70">Current Price</span>
                <span className="text-cyan-400 font-bold">$0.03</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/70">Your Balance</span>
                <span className="text-cyan-400">173.01 $FRIEND</span>
              </div>
            </div>

            {/* FRIEND Amount Input */}
            <div>
              <label className="text-white/70 text-sm mb-2 block">Sell $FRIEND</label>
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <input
                    type="text"
                    placeholder="0.0"
                    value={sellAmount}
                    onChange={(e) => setSellAmount(e.target.value)}
                    className="bg-transparent text-2xl font-bold text-white placeholder-white/40 outline-none flex-1"
                  />
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-gradient-to-br from-cyan-400 to-cyan-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-xs">F</span>
                    </div>
                    <span className="text-white font-medium">$FRIEND</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-white/60 text-sm">
                    <div className="w-3 h-3 bg-gradient-to-br from-cyan-400 to-cyan-500 rounded-full"></div>
                    <span>173.01 available</span>
                  </div>
                  <button 
                    onClick={() => setSellAmount("173.01")}
                    className="text-pink-400 hover:text-pink-300 text-sm"
                  >
                    Max
                  </button>
                </div>
              </div>
            </div>

            {/* Estimated ETH */}
            <div className="bg-white/5 border border-white/10 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <span className="text-white/70">You'll receive</span>
                <div className="flex items-center gap-2">
                  <span className="text-blue-400 font-bold">
                    {sellAmount ? (parseFloat(sellAmount) * 0.03).toFixed(4) : "0.0000"}
                  </span>
                  <span className="text-white">ETH</span>
                </div>
              </div>
            </div>

            {/* Sell Button */}
            <GradientButton 
              variant="saucy" 
              className="w-full h-12 text-lg font-semibold"
              onClick={() => {
                alert(`Selling ${sellAmount} $FRIEND tokens`);
                onClose();
              }}
            >
              Sell $FRIEND
            </GradientButton>
          </TabsContent>
        </Tabs>
      </GlassCard>
    </div>
  );
}