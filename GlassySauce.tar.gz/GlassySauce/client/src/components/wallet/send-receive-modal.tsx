import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { X, Send, ArrowDownLeft, Copy, QrCode } from "lucide-react";
import { EthereumIcon } from "@/components/ui/crypto-icons";

interface SendReceiveModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SendReceiveModal({ isOpen, onClose }: SendReceiveModalProps) {
  const [sendAmount, setSendAmount] = useState("");
  const [sendAddress, setSendAddress] = useState("");

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md p-0 relative overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 pb-4">
          <h2 className="text-xl font-semibold text-gray-700">Wallet balance</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Balance Display */}
        <div className="px-6 pb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <EthereumIcon size={32} />
              <span className="text-3xl font-bold text-gray-900">0.005</span>
            </div>
            <button className="bg-blue-100 hover:bg-blue-200 text-blue-600 px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 transition-colors">
              <ArrowDownLeft className="w-4 h-4" />
              Withdraw ETH
            </button>
          </div>

          {/* Fund your wallet from */}
          <div className="mb-6">
            <h3 className="text-gray-700 font-medium mb-4">Fund your wallet from</h3>
            
            <div className="space-y-3">
              {/* BASE */}
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-xl p-4 flex items-center justify-center gap-3 transition-colors">
                <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">─</span>
                  </div>
                </div>
                <span className="text-xl font-bold">BASE</span>
              </button>

              {/* Coinbase Pay */}
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-xl p-4 flex items-center justify-center gap-3 transition-colors">
                <div className="text-2xl font-bold">coinbase</div>
                <div className="text-sm font-medium">PAY</div>
              </button>

              {/* Ethereum */}
              <button className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-xl p-4 flex items-center justify-center gap-3 transition-colors">
                <EthereumIcon size={32} />
                <span className="text-xl font-medium">ethereum</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}