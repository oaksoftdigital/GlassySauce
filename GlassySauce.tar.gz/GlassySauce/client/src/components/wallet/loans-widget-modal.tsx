import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { X, Search, ChevronUp, ChevronDown } from "lucide-react";

interface LoansWidgetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function LoansWidgetModal({ isOpen, onClose }: LoansWidgetModalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isExpanded, setIsExpanded] = useState(false);

  const collateralTokens = [
    {
      name: "1INCH",
      symbol: "1INCH",
      network: "Ethereum",
      icon: "🦄",
      color: "bg-gradient-to-r from-blue-500 to-purple-600"
    },
    {
      name: "AAVE",
      symbol: "AAVE",
      network: "Ethereum",
      icon: "👻",
      color: "bg-gradient-to-r from-purple-500 to-pink-600"
    },
    {
      name: "APE",
      symbol: "APE",
      network: "Ethereum",
      icon: "🐵",
      color: "bg-gradient-to-r from-blue-600 to-indigo-600"
    },
    {
      name: "APU",
      symbol: "APU",
      network: "Ethereum",
      icon: "🐸",
      color: "bg-gradient-to-r from-green-500 to-teal-600"
    },
    {
      name: "ARKM",
      symbol: "ARKM",
      network: "Ethereum",
      icon: "🤖",
      color: "bg-gradient-to-r from-gray-700 to-gray-900"
    },
    {
      name: "ASF",
      symbol: "ASF",
      network: "Ethereum",
      icon: "🔥",
      color: "bg-gradient-to-r from-red-500 to-orange-600"
    }
  ];

  const visibleTokens = isExpanded ? collateralTokens : collateralTokens.slice(0, 3);

  const filteredTokens = visibleTokens.filter(token => 
    token.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    token.symbol.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[400px] bg-white text-gray-900">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-lg font-semibold text-gray-900">Borrow</DialogTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="rounded-full">
              <div className="w-4 h-4 bg-blue-600 rounded-full flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-4 mt-4">
          {/* Tabs */}
          <Tabs defaultValue="borrow" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-gray-100">
              <TabsTrigger value="borrow" className="data-[state=active]:bg-white">
                Borrow
              </TabsTrigger>
              <TabsTrigger value="my-loans" className="data-[state=active]:bg-white">
                My Loans
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="borrow" className="space-y-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Collateral to deposit for loan"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-50 border-gray-200 focus:border-gray-300"
                />
              </div>

              {/* Collateral Tokens */}
              <div className="space-y-2">
                {filteredTokens.map((token, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${token.color}`}>
                        <span className="text-white text-sm font-bold">
                          {token.symbol.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{token.name}</div>
                        <div className="text-sm text-gray-500">{token.network}</div>
                      </div>
                    </div>
                    <div className="text-gray-400">
                      ⭐
                    </div>
                  </div>
                ))}
              </div>

              {/* Expand/Collapse Button */}
              {!searchQuery && (
                <div className="flex justify-center">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setIsExpanded(!isExpanded)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    {isExpanded ? (
                      <>
                        <ChevronUp className="w-4 h-4 mr-1" />
                        Show Less
                      </>
                    ) : (
                      <>
                        <ChevronDown className="w-4 h-4 mr-1" />
                        Show More
                      </>
                    )}
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="my-loans" className="space-y-4">
              <div className="text-center py-8">
                <div className="text-gray-400 text-sm">No active loans</div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}