import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, TrendingUp, TrendingDown, Eye, MoreHorizontal, Send, Download } from "lucide-react";
import type { Portfolio } from "@/types";

interface EnhancedPortfolioProps {
  portfolio: Portfolio;
}

export function EnhancedPortfolio({ portfolio }: EnhancedPortfolioProps) {
  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(amount));
  };

  const formatPercentage = (change: string) => {
    const num = parseFloat(change);
    return `${num >= 0 ? '+' : ''}${num.toFixed(1)}%`;
  };

  const formatETH = (amount: string) => {
    return `${parseFloat(amount).toFixed(4)} ETH`;
  };

  const mockTransactions = [
    { id: 1, type: 'buy', creator: 'Sophia Rose', amount: '2.5', value: '$156.50', time: '2h ago', change: '+8.2%' },
    { id: 2, type: 'sell', creator: 'Luna Star', amount: '1.0', value: '$89.30', time: '5h ago', change: '+12.1%' },
    { id: 3, type: 'buy', creator: 'Aria Divine', amount: '3.2', value: '$201.80', time: '1d ago', change: '+5.7%' },
  ];

  return (
    <div className="space-y-6">
      {/* Portfolio Overview */}
      <GlassCard className="p-8">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Portfolio Balance</h2>
            <div className="text-4xl font-bold gradient-text mb-2">
              {formatCurrency(portfolio.totalValue)}
            </div>
            <div className={`flex items-center space-x-2 ${
              parseFloat(portfolio.dayChange) >= 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {parseFloat(portfolio.dayChange) >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
              <span className="font-semibold">{formatPercentage(portfolio.dayChange)}</span>
              <span className="text-white/60">24h</span>
            </div>
          </div>
          
          <div className="flex space-x-3">
            <GradientButton variant="glass" size="sm">
              <Send size={16} className="mr-2" />
              Send
            </GradientButton>
            <GradientButton variant="glass" size="sm">
              <Download size={16} className="mr-2" />
              Receive
            </GradientButton>
            <GradientButton variant="saucy" size="sm">
              <Plus size={16} className="mr-2" />
              Add Funds
            </GradientButton>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <GlassCard className="p-4">
            <div className="text-2xl font-bold gradient-text">
              {portfolio.keysOwned}
            </div>
            <div className="text-white/70 text-sm">Keys Owned</div>
          </GlassCard>
          <GlassCard className="p-4">
            <div className="text-2xl font-bold gradient-text">
              {formatETH("2.847")}
            </div>
            <div className="text-white/70 text-sm">ETH Balance</div>
          </GlassCard>
          <GlassCard className="p-4">
            <div className="text-2xl font-bold text-green-400">
              +24.8%
            </div>
            <div className="text-white/70 text-sm">Total Return</div>
          </GlassCard>
          <GlassCard className="p-4">
            <div className="text-2xl font-bold gradient-text">
              {formatCurrency("1,247")}
            </div>
            <div className="text-white/70 text-sm">Today's P&L</div>
          </GlassCard>
        </div>
      </GlassCard>

      {/* Detailed View */}
      <Tabs defaultValue="holdings" className="w-full">
        <TabsList className="grid w-full grid-cols-3 glass">
          <TabsTrigger value="holdings" className="text-white data-[state=active]:gradient-saucy">
            Holdings
          </TabsTrigger>
          <TabsTrigger value="transactions" className="text-white data-[state=active]:gradient-saucy">
            Transactions
          </TabsTrigger>
          <TabsTrigger value="analytics" className="text-white data-[state=active]:gradient-saucy">
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="holdings" className="mt-6">
          <GlassCard className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-white">Your Holdings</h3>
              <GradientButton variant="glass" size="sm">
                <Eye size={16} className="mr-2" />
                View All
              </GradientButton>
            </div>
            
            <div className="space-y-4">
              {portfolio.holdings.map((holding, index) => (
                <div key={index} className="glass rounded-xl p-4 hover:bg-white/10 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full gradient-saucy flex items-center justify-center">
                        <span className="text-white font-bold text-sm">
                          {holding.creator.displayName.substring(0, 2).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <div className="text-white font-semibold">{holding.creator.displayName}</div>
                        <div className="text-white/60 text-sm flex items-center space-x-2">
                          <span>{holding.tokens} keys</span>
                          <Badge className="bg-gradient-to-r from-pink-500/20 to-purple-600/20 text-white text-xs">
                            #{holding.creator.ranking}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right flex items-center space-x-4">
                      <div>
                        <div className="text-white font-semibold">{formatCurrency(holding.value)}</div>
                        <div className={`text-sm flex items-center ${
                          parseFloat(holding.change) >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {parseFloat(holding.change) >= 0 ? <TrendingUp size={12} className="mr-1" /> : <TrendingDown size={12} className="mr-1" />}
                          {formatPercentage(holding.change)}
                        </div>
                      </div>
                      <button className="text-white/60 hover:text-white transition-colors">
                        <MoreHorizontal size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </TabsContent>

        <TabsContent value="transactions" className="mt-6">
          <GlassCard className="p-6">
            <h3 className="text-xl font-bold text-white mb-6">Recent Transactions</h3>
            
            <div className="space-y-4">
              {mockTransactions.map((tx) => (
                <div key={tx.id} className="glass rounded-xl p-4 hover:bg-white/10 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        tx.type === 'buy' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {tx.type === 'buy' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                      </div>
                      <div>
                        <div className="text-white font-semibold">
                          {tx.type === 'buy' ? 'Bought' : 'Sold'} {tx.creator}
                        </div>
                        <div className="text-white/60 text-sm">{tx.time}</div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-white font-semibold">{tx.amount} keys</div>
                      <div className="text-white/60 text-sm">{tx.value}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </TabsContent>

        <TabsContent value="analytics" className="mt-6">
          <GlassCard className="p-6">
            <h3 className="text-xl font-bold text-white mb-6">Portfolio Analytics</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <GlassCard className="p-4">
                <h4 className="text-lg font-semibold text-white mb-4">Performance</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-white/70">7d Return</span>
                    <span className="text-green-400 font-semibold">+18.3%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">30d Return</span>
                    <span className="text-green-400 font-semibold">+45.7%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">Best Performer</span>
                    <span className="text-white font-semibold">Sophia Rose</span>
                  </div>
                </div>
              </GlassCard>
              
              <GlassCard className="p-4">
                <h4 className="text-lg font-semibold text-white mb-4">Allocation</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-white/70">Top Creator</span>
                    <span className="text-white font-semibold">42.3%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">Diversification</span>
                    <span className="text-yellow-400 font-semibold">Medium</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">Risk Level</span>
                    <span className="text-green-400 font-semibold">Low</span>
                  </div>
                </div>
              </GlassCard>
            </div>
          </GlassCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}