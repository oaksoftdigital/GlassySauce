import { useState } from "react";
import { X, ArrowUpDown } from "lucide-react";
import { EthereumIcon, FansIcon } from "@/components/ui/crypto-icons";

interface SwapModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SwapModal({ isOpen, onClose }: SwapModalProps) {
  const [payAmount, setPayAmount] = useState("0.0");
  const [receiveAmount, setReceiveAmount] = useState("0.0");
  const [payToken, setPayToken] = useState<"ETH" | "FANS">("ETH");
  const [receiveToken, setReceiveToken] = useState<"ETH" | "FANS">("FANS");

  const ethBalance = "0.005";
  const fansBalance = "173.0107";

  const handleSwapTokens = () => {
    const tempToken = payToken;
    setPayToken(receiveToken);
    setReceiveToken(tempToken);
    
    const tempAmount = payAmount;
    setPayAmount(receiveAmount);
    setReceiveAmount(tempAmount);
  };

  const handleMaxClick = () => {
    if (payToken === "ETH") {
      setPayAmount(ethBalance);
    } else {
      setPayAmount(fansBalance);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full mx-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="text-xl font-semibold text-gray-900">Swap for $FANS</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* You Pay Section */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-3 block">You pay</label>
            <div className="relative">
              <input
                type="number"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                placeholder="0.0"
                className="w-full px-4 py-4 text-2xl font-medium border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-20"
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                {payToken === "ETH" ? (
                  <EthereumIcon size={20} />
                ) : (
                  <FansIcon size={20} />
                )}
                <span className="text-sm font-medium text-gray-600">{payToken}</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-2 text-sm text-gray-500">
                {payToken === "ETH" ? (
                  <EthereumIcon size={16} />
                ) : (
                  <FansIcon size={16} />
                )}
                <span>{payToken === "ETH" ? ethBalance : fansBalance} available</span>
              </div>
              <button
                onClick={handleMaxClick}
                className="text-sm text-blue-500 hover:text-blue-600 font-medium"
              >
                Buy {payToken}
              </button>
            </div>
          </div>

          {/* Swap Button */}
          <div className="flex justify-center">
            <button
              onClick={handleSwapTokens}
              className="p-2 rounded-lg border border-gray-200 hover:border-gray-300 bg-white transition-colors"
            >
              <ArrowUpDown className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* You Receive Section */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-3 block">You receive</label>
            <div className="relative">
              <input
                type="number"
                value={receiveAmount}
                onChange={(e) => setReceiveAmount(e.target.value)}
                placeholder="0.0"
                className="w-full px-4 py-4 text-2xl font-medium border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-20"
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                {receiveToken === "ETH" ? (
                  <EthereumIcon size={20} />
                ) : (
                  <FansIcon size={20} />
                )}
                <span className="text-sm font-medium text-gray-600">{receiveToken}</span>
              </div>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-gray-500 mt-2">
              <FansIcon size={16} />
              <span>{receiveToken === "FANS" ? fansBalance : ethBalance} held now</span>
            </div>
          </div>

          {/* Transaction Summary */}
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Pay</span>
              <span className="font-medium">{payAmount || "0"} {payToken}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Receive</span>
              <span className="font-medium">{receiveAmount || "0"} ${receiveToken}</span>
            </div>
          </div>

          {/* Swap Button */}
          <button
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!payAmount || payAmount === "0.0" || payAmount === "0"}
          >
            Swap for ${receiveToken}
          </button>
        </div>
      </div>
    </div>
  );
}