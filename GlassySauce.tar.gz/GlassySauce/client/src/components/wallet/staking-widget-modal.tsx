import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { X, HelpCircle, ChevronDown } from "lucide-react";

interface StakingWidgetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function StakingWidgetModal({ isOpen, onClose }: StakingWidgetModalProps) {
  const [selectedNetwork, setSelectedNetwork] = useState("Ethereum");

  const stakingPositions = [
    {
      token: "ETH",
      amount: "768.00",
      rewards: "+56.7913",
      apr: "3.65%",
      icon: "🔷",
      color: "text-blue-400"
    },
    {
      token: "stETH",
      amount: "83.98",
      rewards: "+13.2935",
      apr: "3.31%",
      icon: "🔷",
      color: "text-blue-400"
    },
    {
      token: "USDT",
      amount: "811.91",
      rewards: "+97.76",
      apr: "12.66%",
      icon: "🟢",
      color: "text-green-400"
    },
    {
      token: "USDC",
      amount: "774.97",
      rewards: "+98.64",
      apr: "10.59%",
      icon: "🔵",
      color: "text-blue-400"
    },
    {
      token: "DAI",
      amount: "552.99",
      rewards: "+64.38",
      apr: "14.24%",
      icon: "🟡",
      color: "text-yellow-400"
    },
    {
      token: "AAVE",
      amount: "536.23",
      rewards: "+10.59",
      apr: "6.58%",
      icon: "👻",
      color: "text-purple-400"
    }
  ];

  const eligibleAssets = [
    { name: "MKR", amount: "201,291.11", apr: "12.94%", rewards: "+$260/y", icon: "🏛️" },
    { name: "DAI", amount: "12,901.38", apr: "8.82%", rewards: "+$1.1K/y", icon: "🟡" },
    { name: "ETH", amount: "14,122.72", apr: "3.98%", rewards: "+$1.7M/y", icon: "🔷" }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] bg-white text-gray-900 max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <div className="w-4 h-4 bg-blue-600 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                {selectedNetwork}
                <ChevronDown className="w-3 h-3" />
              </Button>
            </div>
            <span className="text-gray-500 text-sm">0xEA2n...ReWA2D5</span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <div className="space-y-6 mt-4">
          {/* Balance & Earned */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-gray-600 text-sm">Balance</span>
                <HelpCircle className="w-3 h-3 text-gray-400" />
              </div>
              <div className="text-2xl font-bold text-gray-900">$44,805,852.29</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-gray-600 text-sm">Earned</span>
                <HelpCircle className="w-3 h-3 text-gray-400" />
              </div>
              <div className="text-2xl font-bold text-green-600">+$208,967.76</div>
            </div>
          </div>

          {/* Earn Positions */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-gray-600 text-sm">Earn positions</span>
              <span className="text-gray-500 text-sm">$2,539,572.54</span>
              <HelpCircle className="w-3 h-3 text-gray-400" />
            </div>

            {/* Position Headers */}
            <div className="grid grid-cols-3 gap-4 mb-3 text-xs text-gray-500 uppercase font-medium">
              <div>POSITION</div>
              <div>REWARDS</div>
              <div>APR</div>
            </div>

            {/* Staking Positions */}
            <div className="space-y-2">
              {stakingPositions.map((position, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="text-lg">{position.icon}</div>
                    <div>
                      <div className="font-medium text-gray-900">{position.amount}</div>
                      <div className="text-sm text-gray-500">{position.token}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-green-600">{position.rewards}</div>
                    <div className="text-sm text-gray-500">{position.token}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-gray-900">{position.apr}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Eligible Assets */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-gray-600 text-sm">Your eligible assets</span>
              <span className="text-gray-500 text-sm">$42,266,279.75</span>
              <HelpCircle className="w-3 h-3 text-gray-400" />
            </div>

            {/* Asset Headers */}
            <div className="grid grid-cols-3 gap-4 mb-3 text-xs text-gray-500 uppercase font-medium">
              <div>ASSET</div>
              <div>APR</div>
              <div>EST. REWARDS</div>
            </div>

            {/* Assets List */}
            <div className="space-y-2">
              {eligibleAssets.map((asset, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="text-lg">{asset.icon}</div>
                    <div>
                      <div className="font-medium text-gray-900">{asset.amount}</div>
                      <div className="text-sm text-gray-500">{asset.name}</div>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium text-gray-900">{asset.apr}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-gray-900">{asset.rewards}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}