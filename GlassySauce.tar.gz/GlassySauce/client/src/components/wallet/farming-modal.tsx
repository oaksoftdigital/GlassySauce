import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { X, Star } from "lucide-react";

interface FarmingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function FarmingModal({ isOpen, onClose }: FarmingModalProps) {
  const [ethAmount, setEthAmount] = useState("");
  const [friendAmount, setFriendAmount] = useState("");

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <GlassCard className="w-full max-w-md p-6 relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Farm rewards</h2>
          <button
            onClick={onClose}
            className="text-white/60 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Description */}
        <p className="text-white/70 mb-6">
          Provide liquidity to the ETH/$FANS pool to earn rewards.
        </p>

        {/* Deposit Section */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-white mb-4">Deposit</h3>
          
          {/* ETH Input */}
          <div className="mb-4">
            <div className="bg-white/5 border border-white/10 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <input
                  type="text"
                  placeholder="0.0"
                  value={ethAmount}
                  onChange={(e) => setEthAmount(e.target.value)}
                  className="bg-transparent text-2xl font-bold text-white placeholder-white/40 outline-none flex-1"
                />
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-gradient-to-br from-[#627EEA] to-[#4B6CD4] rounded-full flex items-center justify-center">
                    <svg width="16" height="16" viewBox="0 0 32 32" className="text-white">
                      <path d="M16 2L8 16.5l8-3.5 8 3.5L16 2z" fill="currentColor" fillOpacity="0.8"/>
                      <path d="M16 21l-8-4.5L16 30l8-13.5L16 21z" fill="currentColor"/>
                    </svg>
                  </div>
                  <span className="text-white font-medium">ETH</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-white/60 text-sm">
                  <div className="w-3 h-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full"></div>
                  <span>0.005 available</span>
                </div>
                <GradientButton variant="glass" size="sm">
                  Buy ETH
                </GradientButton>
              </div>
            </div>
          </div>

          {/* AND Divider */}
          <div className="text-center text-white/60 text-sm my-4">and</div>

          {/* FRIEND Input */}
          <div className="mb-6">
            <div className="bg-white/5 border border-white/10 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <input
                  type="text"
                  placeholder="0.0"
                  value={friendAmount}
                  onChange={(e) => setFriendAmount(e.target.value)}
                  className="bg-transparent text-2xl font-bold text-white placeholder-white/40 outline-none flex-1"
                />
                <div className="flex items-center gap-2">
                  <span className="text-white font-medium">FRIEND</span>
                </div>
              </div>
              <div className="flex items-center gap-1 text-white/60 text-sm">
                <div className="w-3 h-3 bg-gradient-to-br from-cyan-400 to-cyan-500 rounded-full"></div>
                <span>173.01072 available</span>
              </div>
            </div>
          </div>
        </div>

        {/* LP Rewards Info */}
        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <Star className="w-5 h-5 text-yellow-400 mt-0.5" />
            <div>
              <h4 className="text-yellow-400 font-semibold mb-2">LP rewards</h4>
              <p className="text-white/70 text-sm">
                LPs get to share 1.5% of all FRIEND-ETH swaps (collected to your farm automatically), 
                1.5% of all Club key swaps, and 12M in $FRIEND rewards over 12 months.
              </p>
            </div>
          </div>
        </div>

        {/* Approve Button */}
        <GradientButton 
          variant="saucy" 
          className="w-full h-12 text-lg font-semibold"
          onClick={() => {
            // Handle farming approval
            alert('Farming approval initiated!');
            onClose();
          }}
        >
          Approve spending $FRIEND
        </GradientButton>
      </GlassCard>
    </div>
  );
}