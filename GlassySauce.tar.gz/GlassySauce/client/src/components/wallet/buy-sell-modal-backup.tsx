import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { X, ShoppingCart, TrendingDown, ArrowUpDown } from "lucide-react";
import { FansIcon, EthereumIcon } from "@/components/ui/crypto-icons";

interface BuySellModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BuySellModal({ isOpen, onClose }: BuySellModalProps) {
  const [buyAmount, setBuyAmount] = useState("");
  const [sellAmount, setSellAmount] = useState("");
  const [activeTab, setActiveTab] = useState("buy");

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <GlassCard className="w-full max-w-md p-6 relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Swap for $FANS</h2>
          <button
            onClick={onClose}
            className="text-white/60 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="buy" className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              Buy
            </TabsTrigger>
            <TabsTrigger value="sell" className="flex items-center gap-2">
              <TrendingDown className="w-4 h-4" />
              Sell
            </TabsTrigger>
          </TabsList>

          <TabsContent value="buy" className="space-y-4">
            {/* You Pay Section */}
            <div>
              <label className="text-white/70 text-sm mb-3 block">You pay</label>
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <input
                    type="text"
                    placeholder="0.0"
                    value={buyAmount}
                    onChange={(e) => setBuyAmount(e.target.value)}
                    className="bg-transparent text-2xl font-bold text-white placeholder-white/40 outline-none flex-1"
                  />
                  <div className="flex items-center gap-2">
                    <EthereumIcon size={24} />
                    <span className="text-white font-medium">ETH</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-white/60 text-sm">
                    <EthereumIcon size={16} />
                    <span>0.005 available</span>
                  </div>
                  <button 
                    onClick={() => setBuyAmount("0.005")}
                    className="text-cyan-400 hover:text-cyan-300 text-sm"
                  >
                    Buy ETH
                  </button>
                </div>
              </div>
            </div>

            {/* Swap Arrow */}
            <div className="flex justify-center">
              <div className="p-2 rounded-lg border border-white/10 bg-white/5">
                <ArrowUpDown className="w-5 h-5 text-white/60" />
              </div>
            </div>

            {/* You Receive Section */}
            <div>
              <label className="text-white/70 text-sm mb-3 block">You receive</label>
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl font-bold text-white">
                    {buyAmount ? (parseFloat(buyAmount) * 33.33).toFixed(2) : "0.0"}
                  </span>
                  <div className="flex items-center gap-2">
                    <FansIcon size={24} />
                    <span className="text-white font-medium">FANS</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-white/60 text-sm">
                  <FansIcon size={16} />
                  <span>173.0107 held now</span>
                </div>
              </div>
            </div>

            {/* Transaction Summary */}
            <div className="space-y-2 text-sm bg-white/5 border border-white/10 rounded-lg p-4">
              <div className="flex justify-between">
                <span className="text-white/70">Pay</span>
                <span className="text-white font-medium">{buyAmount || "0"} ETH</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Receive</span>
                <span className="text-white font-medium">
                  {buyAmount ? (parseFloat(buyAmount) * 33.33).toFixed(2) : "0"} $FANS
                </span>
              </div>
            </div>

            {/* Swap Button */}
            <GradientButton 
              variant="saucy" 
              className="w-full h-12 text-lg font-semibold"
              onClick={() => {
                alert(`Swapping ${buyAmount} ETH for $FANS tokens`);
                onClose();
              }}
            >
              Swap for $FANS
            </GradientButton>
          </TabsContent>

          <TabsContent value="sell" className="space-y-4">
            {/* You Pay Section */}
            <div>
              <label className="text-white/70 text-sm mb-3 block">You pay</label>
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <input
                    type="text"
                    placeholder="0.0"
                    value={sellAmount}
                    onChange={(e) => setSellAmount(e.target.value)}
                    className="bg-transparent text-2xl font-bold text-white placeholder-white/40 outline-none flex-1"
                  />
                  <div className="flex items-center gap-2">
                    <FansIcon size={24} />
                    <span className="text-white font-medium">FANS</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-white/60 text-sm">
                    <FansIcon size={16} />
                    <span>173.0107 available</span>
                  </div>
                  <button 
                    onClick={() => setSellAmount("173.0107")}
                    className="text-cyan-400 hover:text-cyan-300 text-sm"
                  >
                    Buy FANS
                  </button>
                </div>
              </div>
            </div>

            {/* Swap Arrow */}
            <div className="flex justify-center">
              <div className="p-2 rounded-lg border border-white/10 bg-white/5">
                <ArrowUpDown className="w-5 h-5 text-white/60" />
              </div>
            </div>

            {/* You Receive Section */}
            <div>
              <label className="text-white/70 text-sm mb-3 block">You receive</label>
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl font-bold text-white">
                    {sellAmount ? (parseFloat(sellAmount) * 0.03).toFixed(4) : "0.0"}
                  </span>
                  <div className="flex items-center gap-2">
                    <EthereumIcon size={24} />
                    <span className="text-white font-medium">ETH</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-white/60 text-sm">
                  <EthereumIcon size={16} />
                  <span>0.005 held now</span>
                </div>
              </div>
            </div>

            {/* Transaction Summary */}
            <div className="space-y-2 text-sm bg-white/5 border border-white/10 rounded-lg p-4">
              <div className="flex justify-between">
                <span className="text-white/70">Pay</span>
                <span className="text-white font-medium">{sellAmount || "0"} $FANS</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Receive</span>
                <span className="text-white font-medium">
                  {sellAmount ? (parseFloat(sellAmount) * 0.03).toFixed(4) : "0"} ETH
                </span>
              </div>
            </div>

            {/* Swap Button */}
            <GradientButton 
              variant="saucy" 
              className="w-full h-12 text-lg font-semibold"
              onClick={() => {
                alert(`Swapping ${sellAmount} $FANS for ETH`);
                onClose();
              }}
            >
              Swap for ETH
            </GradientButton>
          </TabsContent>
        </Tabs>
      </GlassCard>
    </div>
  );
}