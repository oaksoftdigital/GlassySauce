import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { GradientButton } from "@/components/ui/gradient-button";
import { X, Gift, Trophy, TrendingUp } from "lucide-react";
import { FansIcon, EthereumIcon } from "@/components/ui/crypto-icons";

interface ClaimRewardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  rewardType: "farm" | "club";
}

export function ClaimRewardsModal({ isOpen, onClose, rewardType }: ClaimRewardsModalProps) {
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const rewardData = {
    farm: {
      title: "Farm Rewards",
      icon: <Gift className="w-8 h-8" />,
      amount: "0.00",
      token: "$FRIEND",
      description: "Rewards from liquidity provision in the ETH/$FRIEND pool",
      details: [
        "LP rewards from trading fees",
        "Bonus rewards from farming program",
        "Auto-compounded earnings"
      ]
    },
    club: {
      title: "Club Rewards",
      icon: <Trophy className="w-8 h-8" />,
      amount: "14.00645",
      token: "$FRIEND",
      description: "Rewards from club key trading activity",
      details: [
        "Key trading fee share",
        "Club participation rewards",
        "Community bonus rewards"
      ]
    }
  };

  const data = rewardData[rewardType];

  const handleClaim = async () => {
    setIsLoading(true);
    
    // Simulate claiming process
    setTimeout(() => {
      setIsLoading(false);
      alert(`Successfully claimed ${data.amount} ${data.token} rewards!`);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <GlassCard className="w-full max-w-md p-6 relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-white">Rewards</h2>
          <button
            onClick={onClose}
            className="text-white/60 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Balance Information */}
        <div className="space-y-4 mb-8">
          <div className="flex items-center justify-between">
            <span className="text-white/70">Balance</span>
            <span className="text-white font-medium">173.01 $FANS</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-white/70">Farming</span>
            <span className="text-white font-medium">0 $FANS and 0 ETH</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-white/70">Unclaimed rewards</span>
            <span className="text-white font-medium">0</span>
          </div>
        </div>

        {/* Claimable Amount Display */}
        <div className="bg-white/5 border border-white/10 rounded-lg p-8 mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-cyan-500 rounded-full flex items-center justify-center">
              <FansIcon size={24} className="text-white" />
            </div>
            <div className="text-6xl font-bold text-white">0</div>
          </div>
          <div className="text-white/70 text-lg">Claimable $FANS</div>
        </div>

        {/* Claim Button */}
        <GradientButton 
          variant="saucy" 
          className="w-full h-12 text-lg font-semibold"
          onClick={handleClaim}
          disabled={isLoading || true} // Always disabled since claimable is 0
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              Claiming...
            </div>
          ) : (
            "Claim $FANS"
          )}
        </GradientButton>
      </GlassCard>
    </div>
  );
}