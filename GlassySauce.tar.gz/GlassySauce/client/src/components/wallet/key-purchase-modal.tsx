import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, Key, MessageCircle, TrendingUp, Users } from "lucide-react";

interface KeyPurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function KeyPurchaseModal({ isOpen, onClose }: KeyPurchaseModalProps) {
  const [selectedCreator, setSelectedCreator] = useState<string>("");
  const [keyQuantity, setKeyQuantity] = useState("1");
  const [isLoading, setIsLoading] = useState(false);

  const featuredCreators = [
    {
      id: "bella-thorne",
      name: "Bella Thorne",
      username: "@bellathorne",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616c88d5bcb?w=64&h=64&fit=crop&crop=face",
      keyPrice: "0.024 ETH",
      holders: "1,247",
      change: "+12.4%"
    },
    {
      id: "amouranth",
      name: "Amouranth",
      username: "@amouranth",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop&crop=face",
      keyPrice: "0.018 ETH",
      holders: "892",
      change: "+8.7%"
    },
    {
      id: "mia-khalifa",
      name: "Mia Khalifa",
      username: "@miakhalifa",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop&crop=face",
      keyPrice: "0.032 ETH",
      holders: "2,156",
      change: "+15.2%"
    }
  ];

  const handlePurchase = async () => {
    if (!selectedCreator) return;
    
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      onClose();
    } catch (error) {
      console.error("Key purchase failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="w-5 h-5 text-blue-500" />
            Purchase Creator Keys
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Key Benefits */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-2">Key Benefits</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-blue-600" />
                <span className="text-blue-800">Private Chat Access</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-600" />
                <span className="text-blue-800">Price Appreciation</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                <span className="text-blue-800">Exclusive Community</span>
              </div>
            </div>
          </div>

          {/* Creator Selection */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-3 block">
              Select Creator
            </Label>
            <div className="grid grid-cols-1 gap-3">
              {featuredCreators.map((creator) => (
                <div
                  key={creator.id}
                  className={`p-4 rounded-lg border cursor-pointer transition-all ${
                    selectedCreator === creator.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedCreator(creator.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={creator.avatar}
                        alt={creator.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div>
                        <h4 className="font-medium text-gray-900">{creator.name}</h4>
                        <p className="text-sm text-gray-600">{creator.username}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">{creator.keyPrice}</p>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-gray-600">{creator.holders} holders</span>
                        <span className="text-green-600">{creator.change}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Purchase Details */}
          {selectedCreator && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="keyQuantity" className="text-sm font-medium text-gray-700">
                  Number of Keys
                </Label>
                <Input
                  id="keyQuantity"
                  type="number"
                  min="1"
                  value={keyQuantity}
                  onChange={(e) => setKeyQuantity(e.target.value)}
                  className="mt-1"
                />
              </div>

              {/* Price Calculation */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Keys ({keyQuantity})</span>
                  <span className="font-medium">
                    {(parseFloat(featuredCreators.find(c => c.id === selectedCreator)?.keyPrice.split(' ')[0] || '0') * parseInt(keyQuantity)).toFixed(3)} ETH
                  </span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Platform Fee (5%)</span>
                  <span className="font-medium">
                    {(parseFloat(featuredCreators.find(c => c.id === selectedCreator)?.keyPrice.split(' ')[0] || '0') * parseInt(keyQuantity) * 0.05).toFixed(4)} ETH
                  </span>
                </div>
                <div className="border-t pt-2">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-gray-900">Total</span>
                    <span className="font-bold text-lg">
                      {(parseFloat(featuredCreators.find(c => c.id === selectedCreator)?.keyPrice.split(' ')[0] || '0') * parseInt(keyQuantity) * 1.05).toFixed(4)} ETH
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              onClick={handlePurchase}
              disabled={!selectedCreator || isLoading}
              className="bg-blue-500 hover:bg-blue-600"
            >
              {isLoading ? "Processing..." : "Purchase Keys"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}