import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowUpDown, Settings, Wallet, X } from "lucide-react";

interface TradingWidgetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TradingWidgetModal({ isOpen, onClose }: TradingWidgetModalProps) {
  const [amount, setAmount] = useState("0");
  const [fromToken, setFromToken] = useState("ETH");
  const [toToken, setToToken] = useState("USDT");

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] bg-[#0F1419] border-white/10 text-white">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-2xl font-bold text-white">Cross Chain Exchange</DialogTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <div className="space-y-6 mt-4">
          {/* Connect Wallet Button */}
          <div className="flex justify-center">
            <Button className="bg-gradient-to-r from-teal-400 to-purple-500 hover:from-teal-500 hover:to-purple-600 text-white px-8 py-2 rounded-full flex items-center gap-2">
              <Wallet className="w-4 h-4" />
              Connect wallet
            </Button>
          </div>

          {/* Exchange Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold text-white">Exchange</h3>
              <Settings className="w-5 h-5 text-white/60" />
            </div>

            {/* From Token */}
            <div className="bg-[#1A2332] rounded-lg p-4 border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/70 text-sm">From</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 bg-[#627EEA] rounded-full flex items-center justify-center relative">
                    <svg width="20" height="20" viewBox="0 0 32 32" className="text-white">
                      <path d="M16 2L8 16.5l8-3.5 8 3.5L16 2z" fill="currentColor" fillOpacity="0.8"/>
                      <path d="M16 21l-8-4.5L16 30l8-13.5L16 21z" fill="currentColor"/>
                    </svg>
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#627EEA] rounded-full border-2 border-[#0F1419] flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                  </div>
                  <div>
                    <div className="text-white font-medium">ETH</div>
                    <div className="text-white/60 text-sm">Ethereum</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Swap Arrow */}
            <div className="flex justify-center">
              <div className="bg-[#1A2332] border border-white/10 rounded-full p-2">
                <ArrowUpDown className="w-4 h-4 text-white/60" />
              </div>
            </div>

            {/* To Token */}
            <div className="bg-[#1A2332] rounded-lg p-4 border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/70 text-sm">To</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 bg-[#26A17B] rounded-full flex items-center justify-center relative">
                    <svg width="20" height="20" viewBox="0 0 32 32" className="text-white">
                      <circle cx="16" cy="16" r="14" fill="currentColor"/>
                      <path d="M16 4C9.373 4 4 9.373 4 16s5.373 12 12 12 12-5.373 12-12S22.627 4 16 4zm0 21c-4.962 0-9-4.037-9-9s4.038-9 9-9 9 4.037 9 9-4.038 9-9 9z" fill="white"/>
                      <path d="M16 8v8h8" stroke="white" strokeWidth="2" fill="none"/>
                    </svg>
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#627EEA] rounded-full border-2 border-[#0F1419] flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                  </div>
                  <div>
                    <div className="text-white font-medium">USDT</div>
                    <div className="text-white/60 text-sm">Ethereum</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Send Amount */}
            <div className="bg-[#1A2332] rounded-lg p-4 border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/70 text-sm">Send</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 bg-[#627EEA] rounded-full flex items-center justify-center relative">
                    <svg width="20" height="20" viewBox="0 0 32 32" className="text-white">
                      <path d="M16 2L8 16.5l8-3.5 8 3.5L16 2z" fill="currentColor" fillOpacity="0.8"/>
                      <path d="M16 21l-8-4.5L16 30l8-13.5L16 21z" fill="currentColor"/>
                    </svg>
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#627EEA] rounded-full border-2 border-[#0F1419] flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="text-2xl font-bold text-white">0</div>
                  <div className="text-white/60 text-sm">$0.00</div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button className="flex-1 bg-gradient-to-r from-teal-400 to-purple-500 hover:from-teal-500 hover:to-purple-600 text-white py-3 rounded-lg font-medium">
                Connect wallet
              </Button>
              <Button className="bg-[#1A2332] border border-white/10 hover:bg-white/5 text-white p-3 rounded-lg">
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}