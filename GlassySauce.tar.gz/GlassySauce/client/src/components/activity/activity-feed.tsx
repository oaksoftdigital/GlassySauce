import { GlassCard } from "@/components/ui/glass-card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  TrendingUp, 
  TrendingDown, 
  MessageCircle, 
  Users, 
  Crown,
  Heart,
  Star,
  Zap,
  DollarSign
} from "lucide-react";

export function ActivityFeed() {
  const activities = [
    {
      id: 1,
      type: 'trade',
      user: { name: 'Alex', avatar: null },
      action: 'bought',
      target: 'Sophia Rose',
      amount: '25 tokens',
      value: '$127.50',
      time: '2 min ago',
      icon: TrendingUp,
      color: 'text-green-400',
      bgColor: 'bg-green-500/20'
    },
    {
      id: 2,
      type: 'social',
      user: { name: 'Emma', avatar: null },
      action: 'joined',
      target: 'Ava Chen community',
      time: '5 min ago',
      icon: Users,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    },
    {
      id: 3,
      type: 'milestone',
      user: { name: 'Luna Martinez', avatar: null },
      action: 'reached',
      target: '500 token holders',
      time: '8 min ago',
      icon: Crown,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-500/20'
    },
    {
      id: 4,
      type: 'trade',
      user: { name: 'Ryan', avatar: null },
      action: 'sold',
      target: 'Isabella Khan',
      amount: '10 tokens',
      value: '$48.20',
      time: '12 min ago',
      icon: TrendingDown,
      color: 'text-red-400',
      bgColor: 'bg-red-500/20'
    },
    {
      id: 5,
      type: 'social',
      user: { name: 'Maya', avatar: null },
      action: 'liked',
      target: 'Sophia Rose\'s message',
      time: '15 min ago',
      icon: Heart,
      color: 'text-pink-400',
      bgColor: 'bg-pink-500/20'
    },
    {
      id: 6,
      type: 'achievement',
      user: { name: 'Zoe', avatar: null },
      action: 'unlocked',
      target: 'VIP Creator status',
      time: '20 min ago',
      icon: Star,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20'
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Live Activity</h2>
        <Badge className="bg-gradient-to-r from-pink-500 to-purple-500">
          <Zap className="w-3 h-3 mr-1" />
          Live
        </Badge>
      </div>

      <div className="space-y-4">
        {activities.map((activity) => {
          const Icon = activity.icon;
          return (
            <GlassCard key={activity.id} className="p-4 hover:bg-white/5 transition-all">
              <div className="flex items-start space-x-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${activity.bgColor}`}>
                  <Icon className={`w-5 h-5 ${activity.color}`} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <Avatar className="w-6 h-6">
                      {activity.user.avatar ? (
                        <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
                      ) : (
                        <AvatarFallback className="text-xs bg-gradient-to-r from-pink-500 to-purple-500">
                          {activity.user.name[0]}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    <span className="text-white font-medium text-sm">{activity.user.name}</span>
                    <span className="text-white/60 text-sm">{activity.action}</span>
                    <span className="text-white font-medium text-sm">{activity.target}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {activity.amount && (
                        <Badge variant="secondary" className="text-xs bg-white/10">
                          {activity.amount}
                        </Badge>
                      )}
                      {activity.value && (
                        <Badge variant="secondary" className="text-xs bg-white/10">
                          {activity.value}
                        </Badge>
                      )}
                    </div>
                    <span className="text-white/40 text-xs">{activity.time}</span>
                  </div>
                </div>
              </div>
            </GlassCard>
          );
        })}
      </div>

      <div className="text-center">
        <button className="text-white/60 hover:text-white text-sm transition-colors">
          View more activity
        </button>
      </div>
    </div>
  );
}