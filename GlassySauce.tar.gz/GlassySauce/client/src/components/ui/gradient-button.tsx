import { cn } from "@/lib/utils";
import { forwardRef } from "react";

interface GradientButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "saucy" | "coral" | "purple" | "glass";
  size?: "sm" | "md" | "lg";
  glow?: boolean;
}

const GradientButton = forwardRef<HTMLButtonElement, GradientButtonProps>(
  ({ className, variant = "saucy", size = "md", glow = false, ...props }, ref) => {
    const baseClasses = "font-semibold rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed";
    
    const variants = {
      saucy: "chart-gradient text-white hover:opacity-90 shadow-lg hover:shadow-xl",
      coral: "bg-gradient-to-r from-slate-700 to-slate-800 text-white hover:from-slate-800 hover:to-slate-900",
      purple: "chart-gradient text-white hover:opacity-90 shadow-lg hover:shadow-xl",
      glass: "bg-slate-800/30 backdrop-blur-xl border border-white/10 text-white hover:bg-slate-700/40",
    };
    
    const sizes = {
      sm: "px-4 py-2 text-sm",
      md: "px-6 py-3 text-base",
      lg: "px-8 py-4 text-lg",
    };
    
    return (
      <button
        ref={ref}
        className={cn(
          baseClasses,
          variants[variant],
          sizes[size],
          glow && "pulse-glow",
          className
        )}
        {...props}
      />
    );
  }
);

GradientButton.displayName = "GradientButton";

export { GradientButton };
