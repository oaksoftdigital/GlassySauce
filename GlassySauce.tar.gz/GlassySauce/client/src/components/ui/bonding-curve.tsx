interface BondingCurveProps {
  type: "Casual" | "Standard" | "Exclusive";
  width?: number;
  height?: number;
  strokeWidth?: number;
  className?: string;
}

export function BondingCurve({ 
  type, 
  width = 80, 
  height = 48, 
  strokeWidth = 3,
  className = "" 
}: BondingCurveProps) {
  const getColor = (curveType: string) => {
    switch (curveType) {
      case "Casual": return "#10b981";
      case "Standard": return "#8b5cf6";
      case "Exclusive": return "#f59e0b";
      default: return "#8b5cf6";
    }
  };

  const getPath = (curveType: string) => {
    const w = width;
    const h = height;
    
    switch (curveType) {
      case "Casual":
        // Smooth gentle exponential curve like friend.tech
        return `M 10 ${h-6} C ${w*0.3} ${h-8}, ${w*0.6} ${h-12}, ${w-10} ${h-18}`;
      
      case "Standard":
        // Smooth moderate exponential curve like friend.tech
        return `M 10 ${h-4} C ${w*0.25} ${h-6}, ${w*0.5} ${h-15}, ${w-10} ${h-35}`;
      
      case "Exclusive":
        // Smooth steep exponential curve like friend.tech
        return `M 10 ${h-2} C ${w*0.2} ${h-3}, ${w*0.45} ${h-8}, ${w-10} ${h-42}`;
      
      default:
        return `M 5 ${h-6} Q ${w*0.31} ${h-16} ${w*0.56} ${h-26} Q ${w*0.75} ${h-33} ${w*0.9375} ${h-40}`;
    }
  };

  return (
    <svg 
      width={width} 
      height={height} 
      viewBox={`0 0 ${width} ${height}`} 
      className={`overflow-visible ${className}`}
    >
      <path
        d={getPath(type)}
        stroke={getColor(type)}
        strokeWidth={strokeWidth}
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}