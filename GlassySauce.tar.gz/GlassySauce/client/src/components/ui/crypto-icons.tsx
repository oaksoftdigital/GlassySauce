import React from "react";

interface CryptoIconProps {
  className?: string;
  size?: number;
}

export function EthereumIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <circle cx="16" cy="16" r="16" fill="#627eea" />
      <path 
        d="M16.498 4v8.87l7.497 3.35-7.497-12.22z" 
        fill="#fff" 
        fillOpacity="0.602"
      />
      <path d="M16.498 4L9 16.22l7.498-3.35V4z" fill="#fff" />
      <path 
        d="M16.498 21.968v6.027L24 17.616l-7.502 4.352z" 
        fill="#fff" 
        fillOpacity="0.602"
      />
      <path d="M16.498 27.995v-6.028L9 17.616l7.498 10.38z" fill="#fff" />
      <path 
        d="M16.498 20.573l7.497-4.353-7.497-3.348v7.701z" 
        fill="#fff" 
        fillOpacity="0.2"
      />
      <path d="M9 16.22l7.498 4.353v-7.701L9 16.22z" fill="#fff" fillOpacity="0.602" />
    </svg>
  );
}

export function FansIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <defs>
        <linearGradient id="fansGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FF1B8D" />
          <stop offset="100%" stopColor="#8B5CF6" />
        </linearGradient>
      </defs>
      <circle cx="16" cy="16" r="16" fill="url(#fansGradient)" />
      <text 
        x="16" 
        y="22" 
        textAnchor="middle" 
        fill="white" 
        fontSize="18" 
        fontWeight="bold" 
        fontFamily="system-ui"
      >
        F
      </text>
    </svg>
  );
}

export function BaseIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <circle cx="16" cy="16" r="16" fill="#0052FF" />
      <circle cx="16" cy="16" r="12" fill="white" />
      <circle cx="16" cy="16" r="8" fill="#0052FF" />
      <path 
        d="M8 16h16" 
        stroke="white" 
        strokeWidth="2" 
        strokeLinecap="round"
      />
    </svg>
  );
}

export function BitcoinIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <defs>
        <linearGradient id="btcGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F7931A" />
          <stop offset="100%" stopColor="#F79100" />
        </linearGradient>
      </defs>
      <circle cx="16" cy="16" r="16" fill="url(#btcGradient)" />
      <path 
        d="M11.734 14.171c.092-.306.374-.52.688-.52h2.995c.78 0 1.412.632 1.412 1.412 0 .78-.632 1.412-1.412 1.412h-2.995c-.314 0-.596-.214-.688-.52v-1.784zm0-3.659c.092-.306.374-.52.688-.52h2.662c.685 0 1.24.555 1.24 1.24 0 .685-.555 1.24-1.24 1.24h-2.662c-.314 0-.596-.214-.688-.52v-1.44zm7.495 1.44c0-1.37-.555-2.611-1.453-3.51-.898-.898-2.14-1.453-3.51-1.453h-3.35c-.685 0-1.24.555-1.24 1.24v9.544c0 .685.555 1.24 1.24 1.24h3.683c1.37 0 2.611-.555 3.51-1.453.898-.898 1.453-2.14 1.453-3.51 0-.78-.205-1.52-.566-2.155.361-.635.566-1.375.566-2.155z" 
        fill="#fff"
      />
    </svg>
  );
}

export function UsdcIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <circle cx="16" cy="16" r="16" fill="#2775CA" />
      <path 
        d="M16 7C11.029 7 7 11.029 7 16s4.029 9 9 9 9-4.029 9-9-4.029-9-9-9zm4.5 14.5h-3v1.5h-3v-1.5h-1.5v-3h1.5v-3h-1.5v-3h1.5V11h3v1.5h3v3h-1.5v3h1.5v3z" 
        fill="#fff"
      />
    </svg>
  );
}

export function TwitterIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <circle cx="16" cy="16" r="16" fill="#000000" />
      <path 
        d="M13.032 15.25L8.75 9.5h-1.5L12.5 16.5L7.25 22.5h1.5l4.282-5.75L18.25 22.5h1.5l-5.25-7-4.75-6.25h-1.5zm8.218 6.75h-1.5L9.75 10h1.5l10 12z" 
        fill="#fff"
      />
    </svg>
  );
}

export function InstagramIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <defs>
        <linearGradient id="igGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#833AB4" />
          <stop offset="30%" stopColor="#C13584" />
          <stop offset="60%" stopColor="#E1306C" />
          <stop offset="100%" stopColor="#F56040" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="8" fill="url(#igGradient)" />
      <rect x="8" y="8" width="16" height="16" rx="4" fill="none" stroke="white" strokeWidth="2" />
      <circle cx="16" cy="16" r="4" fill="none" stroke="white" strokeWidth="2" />
      <circle cx="21" cy="11" r="1.5" fill="white" />
    </svg>
  );
}

export function OnlyFansIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <circle cx="16" cy="16" r="16" fill="#0084FF" />
      <text 
        x="16" 
        y="12" 
        textAnchor="middle" 
        fill="white" 
        fontSize="8" 
        fontWeight="bold" 
        fontFamily="system-ui"
      >
        OF
      </text>
    </svg>
  );
}

export function UsdtIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <circle cx="16" cy="16" r="16" fill="#26A17B" />
      <path 
        d="M17.922 17.383v-.002c-.11.008-.677.042-1.942.042-1.01 0-1.721-.03-1.971-.042v.002c-3.888-.171-6.79-.848-6.79-1.658 0-.809 2.902-1.486 6.79-1.66v2.644c.254.018.982.061 1.988.061 1.207 0 1.812-.05 1.925-.06v-2.643c3.88.173 6.775.85 6.775 1.658 0 .81-2.895 1.485-6.775 1.658z" 
        fill="#fff"
      />
      <path 
        d="M15.98 21.987c-3.94 0-7.135-.616-7.135-1.378 0-.762 3.195-1.378 7.135-1.378s7.135.616 7.135 1.378c0 .762-3.195 1.378-7.135 1.378z" 
        fill="#fff"
      />
      <path 
        d="M18.374 9.409c0-.042-.003-.084-.003-.125 0-1.048-.85-1.897-1.897-1.897s-1.897.849-1.897 1.897c0 .041-.003.083-.003.125H9.409v2.364h2.066c.235.897.897 1.559 1.794 1.794v2.066h5.462v-2.066c.897-.235 1.559-.897 1.794-1.794h2.066V9.409h-5.217z" 
        fill="#fff"
      />
    </svg>
  );
}

export function DaiIcon({ className = "", size = 24 }: CryptoIconProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 32 32" 
      className={className}
    >
      <circle cx="16" cy="16" r="16" fill="#F5A623" />
      <path 
        d="M9.5 14.5v3h13v-3h-13zm13 0h-13v-3h13v3zm0 6h-13v3h13v-3z" 
        fill="#fff"
      />
      <path 
        d="M16 6.5c-5.25 0-9.5 4.25-9.5 9.5s4.25 9.5 9.5 9.5 9.5-4.25 9.5-9.5-4.25-9.5-9.5-9.5zm6.5 13h-13v-7h13v7z" 
        fill="#fff"
      />
    </svg>
  );
}