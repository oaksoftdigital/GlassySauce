import { useState, useEffect } from 'react';
import { useAccount, useBalance, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { parseEther, formatEther } from 'viem';
import { CONTRACT_ADDRESSES, TOKENS, formatTokenAmount, parseTokenAmount } from '@/lib/blockchain';
import { FANS_TOKEN_ABI, BONDING_CURVE_ABI, ERC20_ABI } from '@/lib/contracts/abis';
import { useToast } from '@/hooks/use-toast';

// Hook for wallet connection and basic info
export function useWallet() {
  const { address, isConnected, chainId } = useAccount();
  const { toast } = useToast();
  
  const { data: ethBalance } = useBalance({
    address,
  });

  const { data: fansBalance } = useBalance({
    address,
    token: CONTRACT_ADDRESSES.FANS_TOKEN as `0x${string}`,
  });

  return {
    address,
    isConnected,
    chainId,
    ethBalance: ethBalance ? formatEther(ethBalance.value) : '0',
    fansBalance: fansBalance ? formatTokenAmount(fansBalance.value) : '0',
  };
}

// Hook for FANS token operations
export function useFansToken() {
  const { address } = useAccount();
  const { toast } = useToast();
  const { writeContract, data: hash, isPending } = useWriteContract();
  
  const { isLoading: isConfirming, isSuccess: isConfirmed } = useWaitForTransactionReceipt({
    hash,
  });

  // Get staked balance
  const { data: stakedBalance } = useReadContract({
    address: CONTRACT_ADDRESSES.FANS_TOKEN as `0x${string}`,
    abi: FANS_TOKEN_ABI,
    functionName: 'stakedBalance',
    args: address ? [address] : undefined,
  });

  // Get pending rewards
  const { data: pendingRewards } = useReadContract({
    address: CONTRACT_ADDRESSES.FANS_TOKEN as `0x${string}`,
    abi: FANS_TOKEN_ABI,
    functionName: 'getRewards',
    args: address ? [address] : undefined,
  });

  const stake = async (amount: string) => {
    try {
      const parsedAmount = parseTokenAmount(amount);
      writeContract({
        address: CONTRACT_ADDRESSES.FANS_TOKEN as `0x${string}`,
        abi: FANS_TOKEN_ABI,
        functionName: 'stake',
        args: [parsedAmount],
      });
    } catch (error) {
      toast({
        title: 'Staking Failed',
        description: 'Failed to stake FANS tokens. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const unstake = async (amount: string) => {
    try {
      const parsedAmount = parseTokenAmount(amount);
      writeContract({
        address: CONTRACT_ADDRESSES.FANS_TOKEN as `0x${string}`,
        abi: FANS_TOKEN_ABI,
        functionName: 'unstake',
        args: [parsedAmount],
      });
    } catch (error) {
      toast({
        title: 'Unstaking Failed',
        description: 'Failed to unstake FANS tokens. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const claimRewards = async () => {
    try {
      writeContract({
        address: CONTRACT_ADDRESSES.FANS_TOKEN as `0x${string}`,
        abi: FANS_TOKEN_ABI,
        functionName: 'claimRewards',
      });
    } catch (error) {
      toast({
        title: 'Claim Failed',
        description: 'Failed to claim rewards. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return {
    stakedBalance: stakedBalance ? formatTokenAmount(stakedBalance as bigint) : '0',
    pendingRewards: pendingRewards ? formatTokenAmount(pendingRewards as bigint) : '0',
    stake,
    unstake,
    claimRewards,
    isPending,
    isConfirming,
    isConfirmed,
  };
}

// Hook for bonding curve operations
export function useBondingCurve(creatorAddress?: string) {
  const { address } = useAccount();
  const { toast } = useToast();
  const { writeContract, data: hash, isPending } = useWriteContract();
  
  const { isLoading: isConfirming, isSuccess: isConfirmed } = useWaitForTransactionReceipt({
    hash,
  });

  // Get key supply for creator
  const { data: keySupply, refetch: refetchSupply } = useReadContract({
    address: CONTRACT_ADDRESSES.BONDING_CURVE as `0x${string}`,
    abi: BONDING_CURVE_ABI,
    functionName: 'getKeySupply',
    args: creatorAddress ? [creatorAddress as `0x${string}`] : undefined,
  });

  // Get user's key balance for creator
  const { data: keyBalance, refetch: refetchBalance } = useReadContract({
    address: CONTRACT_ADDRESSES.BONDING_CURVE as `0x${string}`,
    abi: BONDING_CURVE_ABI,
    functionName: 'getKeyBalance',
    args: creatorAddress && address ? [creatorAddress as `0x${string}`, address] : undefined,
  });

  // Get buy price for amount
  const getBuyPrice = async (amount: string): Promise<string> => {
    if (!creatorAddress) return '0';
    
    try {
      const parsedAmount = parseTokenAmount(amount);
      const { data } = await useReadContract({
        address: CONTRACT_ADDRESSES.BONDING_CURVE as `0x${string}`,
        abi: BONDING_CURVE_ABI,
        functionName: 'getBuyPrice',
        args: [creatorAddress as `0x${string}`, parsedAmount],
      });
      
      return data ? formatEther(data as bigint) : '0';
    } catch (error) {
      return '0';
    }
  };

  // Get sell price for amount
  const getSellPrice = async (amount: string): Promise<string> => {
    if (!creatorAddress) return '0';
    
    try {
      const parsedAmount = parseTokenAmount(amount);
      const { data } = await useReadContract({
        address: CONTRACT_ADDRESSES.BONDING_CURVE as `0x${string}`,
        abi: BONDING_CURVE_ABI,
        functionName: 'getSellPrice',
        args: [creatorAddress as `0x${string}`, parsedAmount],
      });
      
      return data ? formatEther(data as bigint) : '0';
    } catch (error) {
      return '0';
    }
  };

  const buyKeys = async (amount: string, ethAmount: string) => {
    if (!creatorAddress) return;
    
    try {
      const parsedAmount = parseTokenAmount(amount);
      const ethValue = parseEther(ethAmount);
      
      writeContract({
        address: CONTRACT_ADDRESSES.BONDING_CURVE as `0x${string}`,
        abi: BONDING_CURVE_ABI,
        functionName: 'buyKeys',
        args: [creatorAddress as `0x${string}`, parsedAmount],
        value: ethValue,
      });
      
      toast({
        title: 'Purchase Initiated',
        description: `Buying ${amount} creator keys...`,
      });
    } catch (error) {
      toast({
        title: 'Purchase Failed',
        description: 'Failed to buy creator keys. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const sellKeys = async (amount: string) => {
    if (!creatorAddress) return;
    
    try {
      const parsedAmount = parseTokenAmount(amount);
      
      writeContract({
        address: CONTRACT_ADDRESSES.BONDING_CURVE as `0x${string}`,
        abi: BONDING_CURVE_ABI,
        functionName: 'sellKeys',
        args: [creatorAddress as `0x${string}`, parsedAmount],
      });
      
      toast({
        title: 'Sale Initiated',
        description: `Selling ${amount} creator keys...`,
      });
    } catch (error) {
      toast({
        title: 'Sale Failed',
        description: 'Failed to sell creator keys. Please try again.',
        variant: 'destructive',
      });
    }
  };

  useEffect(() => {
    if (isConfirmed) {
      refetchSupply();
      refetchBalance();
      toast({
        title: 'Transaction Confirmed',
        description: 'Your transaction has been completed successfully.',
      });
    }
  }, [isConfirmed, refetchSupply, refetchBalance, toast]);

  return {
    keySupply: keySupply ? formatTokenAmount(keySupply as bigint) : '0',
    keyBalance: keyBalance ? formatTokenAmount(keyBalance as bigint) : '0',
    getBuyPrice,
    getSellPrice,
    buyKeys,
    sellKeys,
    isPending,
    isConfirming,
    isConfirmed,
  };
}

// Hook for creator registration and management
export function useCreatorOperations() {
  const { address } = useAccount();
  const { toast } = useToast();
  const { writeContract, data: hash, isPending } = useWriteContract();
  
  const { data: isRegistered } = useReadContract({
    address: CONTRACT_ADDRESSES.CREATOR_KEYS as `0x${string}`,
    abi: BONDING_CURVE_ABI,
    functionName: 'isRegisteredCreator',
    args: address ? [address] : undefined,
  });

  const registerAsCreator = async (name: string, symbol: string) => {
    try {
      writeContract({
        address: CONTRACT_ADDRESSES.CREATOR_KEYS as `0x${string}`,
        abi: BONDING_CURVE_ABI,
        functionName: 'createCreatorToken',
        args: [name, symbol],
      });
      
      toast({
        title: 'Registration Initiated',
        description: 'Creating your creator profile...',
      });
    } catch (error) {
      toast({
        title: 'Registration Failed',
        description: 'Failed to register as creator. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return {
    isRegistered: Boolean(isRegistered),
    registerAsCreator,
    isPending,
  };
}

// Hook for price calculations and bonding curve math
export function useBondingCurveCalculations() {
  const calculatePrice = (supply: number, amount: number = 1): number => {
    // Bonding curve formula: price = (supply^2) / 16000
    // This creates an exponential curve similar to friend.tech
    const basePrice = 0.0001; // Base price in ETH
    const currentSupply = supply;
    const newSupply = supply + amount;
    
    const sum1 = (currentSupply * (currentSupply + 1) * (2 * currentSupply + 1)) / 6;
    const sum2 = (newSupply * (newSupply + 1) * (2 * newSupply + 1)) / 6;
    
    return basePrice * (sum2 - sum1) / 16000;
  };

  const calculateSupplyFromPrice = (targetPrice: number): number => {
    // Inverse calculation to find supply for a given price
    const basePrice = 0.0001;
    return Math.sqrt(targetPrice * 16000 / basePrice);
  };

  const getTradePreview = (supply: number, amount: number, isBuy: boolean) => {
    if (isBuy) {
      const price = calculatePrice(supply, amount);
      const protocolFee = price * 0.05; // 5% protocol fee
      const creatorFee = price * 0.05; // 5% creator fee
      const total = price + protocolFee + creatorFee;
      
      return {
        price,
        protocolFee,
        creatorFee,
        total,
        priceAfter: calculatePrice(supply + amount, 1),
      };
    } else {
      const price = calculatePrice(supply - amount, amount);
      const protocolFee = price * 0.05;
      const creatorFee = price * 0.05;
      const total = price - protocolFee - creatorFee;
      
      return {
        price,
        protocolFee,
        creatorFee,
        total,
        priceAfter: calculatePrice(supply - amount, 1),
      };
    }
  };

  return {
    calculatePrice,
    calculateSupplyFromPrice,
    getTradePreview,
  };
}