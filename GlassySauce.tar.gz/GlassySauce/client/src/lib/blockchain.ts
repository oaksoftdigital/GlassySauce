import { createConfig, http } from 'wagmi';
import { pulsechain } from 'wagmi/chains';
import { injected, metaMask, walletConnect } from 'wagmi/connectors';

// PulseChain configuration
export const pulsechainConfig = {
  id: 369,
  name: 'PulseChain',
  network: 'pulsechain',
  nativeCurrency: {
    decimals: 18,
    name: 'Pulse',
    symbol: 'PLS',
  },
  rpcUrls: {
    public: { http: ['https://rpc.pulsechain.com'] },
    default: { http: ['https://rpc.pulsechain.com'] },
  },
  blockExplorers: {
    default: { name: 'PulseScan', url: 'https://scan.pulsechain.com' },
  },
} as const;

// Custom PulseChain testnet configuration
export const pulsechainTestnet = {
  id: 943,
  name: 'PulseChain Testnet',
  network: 'pulsechain-testnet',
  nativeCurrency: {
    decimals: 18,
    name: 'Test Pulse',
    symbol: 'tPLS',
  },
  rpcUrls: {
    public: { http: ['https://rpc.v4.testnet.pulsechain.com'] },
    default: { http: ['https://rpc.v4.testnet.pulsechain.com'] },
  },
  blockExplorers: {
    default: { name: 'PulseScan Testnet', url: 'https://scan.v4.testnet.pulsechain.com' },
  },
} as const;

// Wagmi configuration
export const config = createConfig({
  chains: [pulsechainConfig, pulsechainTestnet],
  transports: {
    [pulsechainConfig.id]: http(),
    [pulsechainTestnet.id]: http(),
  },
  connectors: [
    injected(),
    metaMask(),
    walletConnect({ projectId: process.env.VITE_WALLETCONNECT_PROJECT_ID || 'fans-tech-project' }),
  ],
});

// Contract addresses
export const CONTRACT_ADDRESSES = {
  FANS_TOKEN: '0x1234567890123456789012345678901234567890', // Placeholder - will be deployed
  BONDING_CURVE: '0x2345678901234567890123456789012345678901', // Placeholder - will be deployed
  CREATOR_KEYS: '0x3456789012345678901234567890123456789012', // Placeholder - will be deployed
  STAKING: '0x4567890123456789012345678901234567890123', // Placeholder - will be deployed
} as const;

// Token configurations
export const TOKENS = {
  PLS: {
    address: '0x0000000000000000000000000000000000000000', // Native token
    symbol: 'PLS',
    name: 'Pulse',
    decimals: 18,
    logo: '/icons/pls.svg',
  },
  FANS: {
    address: CONTRACT_ADDRESSES.FANS_TOKEN,
    symbol: 'FANS',
    name: 'Fans Token',
    decimals: 18,
    logo: '/icons/fans.svg',
  },
  HEX: {
    address: '0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39', // HEX on PulseChain
    symbol: 'HEX',
    name: 'HEX',
    decimals: 8,
    logo: '/icons/hex.svg',
  },
} as const;

// Utility functions
export const formatTokenAmount = (amount: bigint, decimals: number = 18): string => {
  const divisor = BigInt(10 ** decimals);
  const wholePart = amount / divisor;
  const fractionalPart = amount % divisor;
  
  if (fractionalPart === 0n) {
    return wholePart.toString();
  }
  
  const fractionalStr = fractionalPart.toString().padStart(decimals, '0');
  const trimmedFractional = fractionalStr.replace(/0+$/, '');
  
  return trimmedFractional ? `${wholePart}.${trimmedFractional}` : wholePart.toString();
};

export const parseTokenAmount = (amount: string, decimals: number = 18): bigint => {
  const [wholePart, fractionalPart = ''] = amount.split('.');
  const paddedFractional = fractionalPart.padEnd(decimals, '0').slice(0, decimals);
  return BigInt(wholePart + paddedFractional);
};

export const shortenAddress = (address: string): string => {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
};

export const isValidAddress = (address: string): boolean => {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
};