// Comprehensive multi-chain token list for cross-chain DEX
export interface Token {
  address: string;
  symbol: string;
  name: string;
  decimals: number;
  logoURI: string;
  chainId: number;
  chainName: string;
  isNative?: boolean;
  isPopular?: boolean;
  category?: 'stablecoin' | 'defi' | 'meme' | 'gaming' | 'ai' | 'layer1' | 'layer2';
}

export interface Chain {
  id: number;
  name: string;
  symbol: string;
  logoURI: string;
  rpcUrl: string;
  explorerUrl: string;
}

export const SUPPORTED_CHAINS: Chain[] = [
  {
    id: 1,
    name: 'Ethereum',
    symbol: 'ETH',
    logoURI: '/icons/ethereum.svg',
    rpcUrl: 'https://eth-mainnet.g.alchemy.com/v2/demo',
    explorerUrl: 'https://etherscan.io',
  },
  {
    id: 56,
    name: 'BNB Smart Chain',
    symbol: 'BNB',
    logoURI: '/icons/bnb.svg',
    rpcUrl: 'https://bsc-dataseed.binance.org',
    explorerUrl: 'https://bscscan.com',
  },
  {
    id: 137,
    name: 'Polygon',
    symbol: 'MATIC',
    logoURI: '/icons/polygon.svg',
    rpcUrl: 'https://polygon-rpc.com',
    explorerUrl: 'https://polygonscan.com',
  },
  {
    id: 42161,
    name: 'Arbitrum',
    symbol: 'ARB',
    logoURI: '/icons/arbitrum.svg',
    rpcUrl: 'https://arb1.arbitrum.io/rpc',
    explorerUrl: 'https://arbiscan.io',
  },
  {
    id: 10,
    name: 'Optimism',
    symbol: 'OP',
    logoURI: '/icons/optimism.svg',
    rpcUrl: 'https://mainnet.optimism.io',
    explorerUrl: 'https://optimistic.etherscan.io',
  },
  {
    id: 43114,
    name: 'Avalanche',
    symbol: 'AVAX',
    logoURI: '/icons/avalanche.svg',
    rpcUrl: 'https://api.avax.network/ext/bc/C/rpc',
    explorerUrl: 'https://snowtrace.io',
  },
  {
    id: 250,
    name: 'Fantom',
    symbol: 'FTM',
    logoURI: '/icons/fantom.svg',
    rpcUrl: 'https://rpc.ftm.tools',
    explorerUrl: 'https://ftmscan.com',
  },
  {
    id: 369,
    name: 'PulseChain',
    symbol: 'PLS',
    logoURI: '/icons/pulsechain.svg',
    rpcUrl: 'https://rpc.pulsechain.com',
    explorerUrl: 'https://scan.pulsechain.com',
  },
  {
    id: 8453,
    name: 'Base',
    symbol: 'BASE',
    logoURI: '/icons/base.svg',
    rpcUrl: 'https://mainnet.base.org',
    explorerUrl: 'https://basescan.org',
  },
  {
    id: 25,
    name: 'Cronos',
    symbol: 'CRO',
    logoURI: '/icons/cronos.svg',
    rpcUrl: 'https://evm.cronos.org',
    explorerUrl: 'https://cronoscan.com',
  },
];

export const MULTI_CHAIN_TOKENS: Token[] = [
  // Ethereum Mainnet - Native & Top Tokens
  {
    address: '0x0000000000000000000000000000000000000000',
    symbol: 'ETH',
    name: 'Ethereum',
    decimals: 18,
    logoURI: '/icons/ethereum.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isNative: true,
    isPopular: true,
    category: 'layer1',
  },
  {
    address: '0xA0b86a33E6411a3c38EF47b2DC1b50c79E38A30F',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    logoURI: '/icons/usdc.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'stablecoin',
  },
  {
    address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    symbol: 'USDT',
    name: 'Tether USD',
    decimals: 6,
    logoURI: '/icons/usdt.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'stablecoin',
  },
  {
    address: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
    symbol: 'WBTC',
    name: 'Wrapped Bitcoin',
    decimals: 8,
    logoURI: '/icons/wbtc.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'layer1',
  },
  {
    address: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
    symbol: 'DAI',
    name: 'Dai Stablecoin',
    decimals: 18,
    logoURI: '/icons/dai.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'stablecoin',
  },
  {
    address: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
    symbol: 'UNI',
    name: 'Uniswap',
    decimals: 18,
    logoURI: '/icons/uni.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'defi',
  },
  {
    address: '0x514910771AF9Ca656af840dff83E8264EcF986CA',
    symbol: 'LINK',
    name: 'Chainlink',
    decimals: 18,
    logoURI: '/icons/link.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'defi',
  },
  {
    address: '0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9',
    symbol: 'AAVE',
    name: 'Aave',
    decimals: 18,
    logoURI: '/icons/aave.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'defi',
  },
  {
    address: '0x95aD61b0a150d79219dCF64E1E6Cc01f0B64C4cE',
    symbol: 'SHIB',
    name: 'Shiba Inu',
    decimals: 18,
    logoURI: '/icons/shib.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'meme',
  },
  {
    address: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    symbol: 'WETH',
    name: 'Wrapped Ethereum',
    decimals: 18,
    logoURI: '/icons/weth.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'layer1',
  },

  // BNB Smart Chain
  {
    address: '0x0000000000000000000000000000000000000000',
    symbol: 'BNB',
    name: 'BNB',
    decimals: 18,
    logoURI: '/icons/bnb.svg',
    chainId: 56,
    chainName: 'BNB Smart Chain',
    isNative: true,
    isPopular: true,
    category: 'layer1',
  },
  {
    address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 18,
    logoURI: '/icons/usdc.svg',
    chainId: 56,
    chainName: 'BNB Smart Chain',
    isPopular: true,
    category: 'stablecoin',
  },
  {
    address: '0x55d398326f99059fF775485246999027B3197955',
    symbol: 'USDT',
    name: 'Tether USD',
    decimals: 18,
    logoURI: '/icons/usdt.svg',
    chainId: 56,
    chainName: 'BNB Smart Chain',
    isPopular: true,
    category: 'stablecoin',
  },
  {
    address: '0x2170Ed0880ac9A755fd29B2688956BD959F933F8',
    symbol: 'ETH',
    name: 'Ethereum Token',
    decimals: 18,
    logoURI: '/icons/ethereum.svg',
    chainId: 56,
    chainName: 'BNB Smart Chain',
    isPopular: true,
    category: 'layer1',
  },
  {
    address: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c',
    symbol: 'BTCB',
    name: 'Bitcoin BEP2',
    decimals: 18,
    logoURI: '/icons/btc.svg',
    chainId: 56,
    chainName: 'BNB Smart Chain',
    isPopular: true,
    category: 'layer1',
  },

  // Polygon
  {
    address: '0x0000000000000000000000000000000000000000',
    symbol: 'MATIC',
    name: 'Polygon',
    decimals: 18,
    logoURI: '/icons/polygon.svg',
    chainId: 137,
    chainName: 'Polygon',
    isNative: true,
    isPopular: true,
    category: 'layer2',
  },
  {
    address: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    logoURI: '/icons/usdc.svg',
    chainId: 137,
    chainName: 'Polygon',
    isPopular: true,
    category: 'stablecoin',
  },
  {
    address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
    symbol: 'USDT',
    name: 'Tether USD',
    decimals: 6,
    logoURI: '/icons/usdt.svg',
    chainId: 137,
    chainName: 'Polygon',
    isPopular: true,
    category: 'stablecoin',
  },
  {
    address: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    symbol: 'WETH',
    name: 'Wrapped Ethereum',
    decimals: 18,
    logoURI: '/icons/weth.svg',
    chainId: 137,
    chainName: 'Polygon',
    isPopular: true,
    category: 'layer1',
  },

  // Arbitrum
  {
    address: '0x0000000000000000000000000000000000000000',
    symbol: 'ETH',
    name: 'Ethereum',
    decimals: 18,
    logoURI: '/icons/ethereum.svg',
    chainId: 42161,
    chainName: 'Arbitrum',
    isNative: true,
    isPopular: true,
    category: 'layer1',
  },
  {
    address: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    logoURI: '/icons/usdc.svg',
    chainId: 42161,
    chainName: 'Arbitrum',
    isPopular: true,
    category: 'stablecoin',
  },
  {
    address: '0x912CE59144191C1204E64559FE8253a0e49E6548',
    symbol: 'ARB',
    name: 'Arbitrum',
    decimals: 18,
    logoURI: '/icons/arbitrum.svg',
    chainId: 42161,
    chainName: 'Arbitrum',
    isPopular: true,
    category: 'layer2',
  },

  // Base
  {
    address: '0x0000000000000000000000000000000000000000',
    symbol: 'ETH',
    name: 'Ethereum',
    decimals: 18,
    logoURI: '/icons/ethereum.svg',
    chainId: 8453,
    chainName: 'Base',
    isNative: true,
    isPopular: true,
    category: 'layer1',
  },
  {
    address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    logoURI: '/icons/usdc.svg',
    chainId: 8453,
    chainName: 'Base',
    isPopular: true,
    category: 'stablecoin',
  },

  // Avalanche
  {
    address: '0x0000000000000000000000000000000000000000',
    symbol: 'AVAX',
    name: 'Avalanche',
    decimals: 18,
    logoURI: '/icons/avalanche.svg',
    chainId: 43114,
    chainName: 'Avalanche',
    isNative: true,
    isPopular: true,
    category: 'layer1',
  },
  {
    address: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    logoURI: '/icons/usdc.svg',
    chainId: 43114,
    chainName: 'Avalanche',
    isPopular: true,
    category: 'stablecoin',
  },

  // PulseChain
  {
    address: '0x0000000000000000000000000000000000000000',
    symbol: 'PLS',
    name: 'Pulse',
    decimals: 18,
    logoURI: '/icons/pulsechain.svg',
    chainId: 369,
    chainName: 'PulseChain',
    isNative: true,
    isPopular: true,
    category: 'layer1',
  },
  {
    address: '0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39',
    symbol: 'HEX',
    name: 'HEX',
    decimals: 8,
    logoURI: '/icons/hex.svg',
    chainId: 369,
    chainName: 'PulseChain',
    isPopular: true,
    category: 'defi',
  },
  {
    address: '0x8a810ea8B121d08342E9e7696f4a9915cBE494B7',
    symbol: 'PLSX',
    name: 'PulseX',
    decimals: 18,
    logoURI: '/icons/plsx.svg',
    chainId: 369,
    chainName: 'PulseChain',
    isPopular: true,
    category: 'defi',
  },

  // FANS Token (Available on multiple chains)
  {
    address: '0x1234567890123456789012345678901234567890',
    symbol: 'FANS',
    name: 'Fans Token',
    decimals: 18,
    logoURI: '/icons/fans.svg',
    chainId: 1,
    chainName: 'Ethereum',
    isPopular: true,
    category: 'defi',
  },
  {
    address: '0x1234567890123456789012345678901234567891',
    symbol: 'FANS',
    name: 'Fans Token',
    decimals: 18,
    logoURI: '/icons/fans.svg',
    chainId: 56,
    chainName: 'BNB Smart Chain',
    isPopular: true,
    category: 'defi',
  },
  {
    address: '0x1234567890123456789012345678901234567892',
    symbol: 'FANS',
    name: 'Fans Token',
    decimals: 18,
    logoURI: '/icons/fans.svg',
    chainId: 137,
    chainName: 'Polygon',
    isPopular: true,
    category: 'defi',
  },
  // Major PulseChain tokens
  {
    address: '0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39',
    symbol: 'HEX',
    name: 'HEX',
    decimals: 8,
    logoURI: '/icons/hex.svg',
    isPopular: true,
  },
  {
    address: '0x15D38573d2feeb82e7ad5187aB8c1D52810B1f07',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    logoURI: '/icons/usdc.svg',
    isPopular: true,
  },
  {
    address: '0x832eb3Cd0BDbe8E8a12B24C1b361C73bB7Ce4E7f',
    symbol: 'USDT',
    name: 'Tether USD',
    decimals: 6,
    logoURI: '/icons/usdt.svg',
    isPopular: true,
  },
  {
    address: '0x02DcdD04e3F455D838cd1249292C58f3B79e3C3C',
    symbol: 'WETH',
    name: 'Wrapped Ethereum',
    decimals: 18,
    logoURI: '/icons/weth.svg',
    isPopular: true,
  },
  {
    address: '0x5066c68cAe3B9bdCdB5E2b1182fe5E4bA5d2B7Ca',
    symbol: 'WBTC',
    name: 'Wrapped Bitcoin',
    decimals: 8,
    logoURI: '/icons/wbtc.svg',
    isPopular: true,
  },
  // FANS token
  {
    address: '0x1234567890123456789012345678901234567890',
    symbol: 'FANS',
    name: 'Fans Token',
    decimals: 18,
    logoURI: '/icons/fans.svg',
    isPopular: true,
  },
  // Additional PulseChain ecosystem tokens
  {
    address: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
    symbol: 'DAI',
    name: 'Dai Stablecoin',
    decimals: 18,
    logoURI: '/icons/dai.svg',
    isPopular: true,
  },
  {
    address: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
    symbol: 'UNI',
    name: 'Uniswap',
    decimals: 18,
    logoURI: '/icons/uni.svg',
  },
  {
    address: '0x514910771AF9Ca656af840dff83E8264EcF986CA',
    symbol: 'LINK',
    name: 'Chainlink',
    decimals: 18,
    logoURI: '/icons/link.svg',
  },
  {
    address: '0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9',
    symbol: 'AAVE',
    name: 'Aave',
    decimals: 18,
    logoURI: '/icons/aave.svg',
  },
  {
    address: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    symbol: 'COMP',
    name: 'Compound',
    decimals: 18,
    logoURI: '/icons/comp.svg',
  },
  {
    address: '0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2',
    symbol: 'MKR',
    name: 'Maker',
    decimals: 18,
    logoURI: '/icons/mkr.svg',
  },
  {
    address: '0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e',
    symbol: 'YFI',
    name: 'yearn.finance',
    decimals: 18,
    logoURI: '/icons/yfi.svg',
  },
  {
    address: '0x6B3595068778DD592e39A122f4f5a5cF09C90fE2',
    symbol: 'SUSHI',
    name: 'SushiToken',
    decimals: 18,
    logoURI: '/icons/sushi.svg',
  },
  {
    address: '0x1985365e9f78359a9B6AD760e32412f4a445E862',
    symbol: 'REP',
    name: 'Augur',
    decimals: 18,
    logoURI: '/icons/rep.svg',
  },
  // PulseChain specific tokens
  {
    address: '0x8a810ea8B121d08342E9e7696f4a9915cBE494B7',
    symbol: 'PLSX',
    name: 'PulseX',
    decimals: 18,
    logoURI: '/icons/plsx.svg',
    isPopular: true,
  },
  {
    address: '0x2fa878Ab3F87CC1C9737Fc071108F904c0B0C95d',
    symbol: 'INC',
    name: 'Incentive',
    decimals: 18,
    logoURI: '/icons/inc.svg',
  },
  {
    address: '0x57fE70b5B1A2c989b8b8c88c3e8b3c3e1e1e1e1e',
    symbol: 'LOAN',
    name: 'LOAN Token',
    decimals: 8,
    logoURI: '/icons/loan.svg',
  },
  {
    address: '0x95aD61b0a150d79219dCF64E1E6Cc01f0B64C4cE',
    symbol: 'SHIB',
    name: 'Shiba Inu',
    decimals: 18,
    logoURI: '/icons/shib.svg',
  },
  {
    address: '0x4Fabb145d64652a948d72533023f6E7A623C7C53',
    symbol: 'BUSD',
    name: 'Binance USD',
    decimals: 18,
    logoURI: '/icons/busd.svg',
  },
];

// Add thousands more tokens to reach 3000+ pairs
// This would normally be loaded from CoinGecko, DeFiLlama, or similar APIs
export const generateExtendedTokenList = (): Token[] => {
  const baseTokens = [...MULTI_CHAIN_TOKENS];
  
  // Add more popular tokens across all chains
  const additionalTokens = [
    // More Ethereum tokens
    'APE', 'CRV', 'ENS', 'LOOKS', 'BLUR', '1INCH', 'SUSHI', 'BAL', 'SAND', 'MANA',
    'LRC', 'IMX', 'GALA', 'CHZ', 'BAT', 'ZRX', 'KNC', '0X', 'REP', 'REN',
    // Meme tokens
    'DOGE', 'PEPE', 'FLOKI', 'BONK', 'WIF', 'POPCAT', 'MEW', 'BRETT', 'ANDY',
    // Gaming tokens
    'AXS', 'SLP', 'RONIN', 'PIXEL', 'GHST', 'YGG', 'PRIME', 'MAGIC', 'TLM',
    // AI tokens
    'FET', 'AGIX', 'OCEAN', 'RLC', 'NMR', 'CTXC', 'AIOZ', 'PHB', 'RNDR',
  ];

  // Generate tokens for each chain
  SUPPORTED_CHAINS.forEach(chain => {
    additionalTokens.forEach((symbol, index) => {
      baseTokens.push({
        address: `0x${(index + 1000).toString(16).padStart(40, '0')}`,
        symbol,
        name: `${symbol} Token`,
        decimals: 18,
        logoURI: `/icons/${symbol.toLowerCase()}.svg`,
        chainId: chain.id,
        chainName: chain.name,
        isPopular: index < 20,
        category: symbol.includes('AI') ? 'ai' : 
                 ['DOGE', 'PEPE', 'SHIB'].includes(symbol) ? 'meme' :
                 ['AXS', 'GALA', 'SAND'].includes(symbol) ? 'gaming' : 'defi',
      });
    });
  });

  return baseTokens;
};

// Helper functions
export const getTokenByAddress = (address: string, chainId?: number): Token | undefined => {
  const tokens = generateExtendedTokenList();
  return tokens.find(token => 
    token.address.toLowerCase() === address.toLowerCase() &&
    (!chainId || token.chainId === chainId)
  );
};

export const getTokenBySymbol = (symbol: string, chainId?: number): Token | undefined => {
  const tokens = generateExtendedTokenList();
  return tokens.find(token => 
    token.symbol.toLowerCase() === symbol.toLowerCase() &&
    (!chainId || token.chainId === chainId)
  );
};

export const getTokensByChain = (chainId: number): Token[] => {
  const tokens = generateExtendedTokenList();
  return tokens.filter(token => token.chainId === chainId);
};

export const getPopularTokens = (chainId?: number): Token[] => {
  const tokens = generateExtendedTokenList();
  return tokens.filter(token => 
    token.isPopular && (!chainId || token.chainId === chainId)
  );
};

export const searchTokens = (query: string, chainId?: number): Token[] => {
  const lowercaseQuery = query.toLowerCase();
  const tokens = generateExtendedTokenList();
  return tokens.filter(token => 
    (token.symbol.toLowerCase().includes(lowercaseQuery) ||
     token.name.toLowerCase().includes(lowercaseQuery) ||
     token.address.toLowerCase().includes(lowercaseQuery)) &&
    (!chainId || token.chainId === chainId)
  );
};

export const getTokensByCategory = (category: string, chainId?: number): Token[] => {
  const tokens = generateExtendedTokenList();
  return tokens.filter(token => 
    token.category === category && (!chainId || token.chainId === chainId)
  );
};

// Default trading pairs
export const DEFAULT_TRADING_PAIRS = [
  { base: 'FANS', quote: 'PLS' },
  { base: 'FANS', quote: 'USDC' },
  { base: 'FANS', quote: 'HEX' },
  { base: 'PLS', quote: 'USDC' },
  { base: 'HEX', quote: 'PLS' },
  { base: 'WETH', quote: 'USDC' },
  { base: 'WBTC', quote: 'USDC' },
  { base: 'PLSX', quote: 'PLS' },
];

// Token price data (mock for now - in production would come from DEX APIs)
export const getTokenPrice = (tokenSymbol: string): number => {
  const prices: Record<string, number> = {
    'PLS': 0.0001,
    'HEX': 0.025,
    'USDC': 1.00,
    'USDT': 1.00,
    'WETH': 2500,
    'WBTC': 45000,
    'FANS': 0.15,
    'DAI': 1.00,
    'UNI': 6.50,
    'LINK': 14.20,
    'AAVE': 85.00,
    'COMP': 45.00,
    'MKR': 1200,
    'YFI': 8500,
    'SUSHI': 1.20,
    'PLSX': 0.00005,
    'SHIB': 0.000008,
    'BUSD': 1.00,
  };
  
  return prices[tokenSymbol] || 0;
};