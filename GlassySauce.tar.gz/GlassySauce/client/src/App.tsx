import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarNavigation } from "@/components/layout/sidebar-navigation";
import Home from "@/pages/home";
import Discover from "@/pages/discover";

import Wallet from "@/pages/wallet";
import WalletTracker from "@/pages/wallet-tracker";
import Chat from "@/pages/chat";
import Bridge from "@/pages/bridge";
import Post from "@/pages/post";
import Staking from "@/pages/staking";
import Loans from "@/pages/loans";

import Notifications from "@/pages/notifications";
import Referrals from "@/pages/referrals";
import Bookmarks from "@/pages/bookmarks";
import Profile from "@/pages/profile";
import CreatorProfile from "@/pages/creator-profile";
import ClubProfile from "@/pages/club-profile";
import Clubs from "@/pages/clubs";
import Account from "@/pages/account";
import Advertising from "@/pages/advertising";
import Alpha from "@/pages/alpha";
import Campaigns from "@/pages/campaigns";

import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex min-h-screen">
      <SidebarNavigation />
      <div className="flex-1 lg:ml-48">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/discover" component={Discover} />
          <Route path="/clubs" component={Clubs} />
          <Route path="/wallet" component={Wallet} />
          <Route path="/wallet-tracker" component={WalletTracker} />
          <Route path="/chat" component={Chat} />
          <Route path="/bridge" component={Bridge} />
          <Route path="/post" component={Post} />
          <Route path="/staking" component={Staking} />
          <Route path="/loans" component={Loans} />

          <Route path="/advertising" component={Advertising} />
          <Route path="/alpha" component={Alpha} />
          <Route path="/campaigns" component={Campaigns} />

          <Route path="/notifications" component={Notifications} />
          <Route path="/referrals" component={Referrals} />
          <Route path="/bookmarks" component={Bookmarks} />
          <Route path="/profile/:userId" component={Profile} />
          <Route path="/creator/:userId" component={CreatorProfile} />
          <Route path="/club/:clubId" component={ClubProfile} />
          <Route path="/account" component={Account} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
